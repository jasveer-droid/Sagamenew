# v11 City Choices - current integration contract

This header supersedes historical v10 notes below. See README.md and CITY_CHOICES.md.

- Do not add real-money gambling, bank APIs, payments or real product sellers.
- MZNightlife is shared by browser and co-op server; do not implement separate payout/loan logic in the UI. RNG uses crypto.getRandomValues rejection sampling.
- New business purchases MUST pass completePurchase after an approved in-person bank application. Loans pay the opening agreement directly; never credit withdrawable loan money. Existing ownership remains valid.
- Casino stakes always deduct actual cash, even with developer purchase waivers. Return includes stake. Blackjack shoe/cursor persist on the server, but publicTeam redacts future cards and the hidden hole card. Leave auto-stands; transient disconnect retains the hand.
- Keep split/double stake budget checks, exact outcomes, receipt ordering and write-before-response. No retries may reroll or pay twice.
- Garages save per-car engine/component unlocks, six panel groups and four wheel flags. Missing essential parts block mounting AND the car movement solver. Do not market this as BeamNG soft-body physics.
- New retail units are separate from crafted sales packs. Flower input grams -> integer half-gram packs. Bounds/affordability precede changes.
- cityLife is schema11 save data and a TEAM_KEY. Do not break v1-v10 migration, solo/co-op separation or newer-tab guard.
- Add all new modules to index.html, build.mjs, service-worker cache and server VM as appropriate. Rebuild before testing; do not edit standalone HTML only.
- Current browser entrypoints: v11_browser.py, v11_coop_browser.py, browser_smoke.py, safety_smoke.py, native_launch.py. npm test is the complete current Node suite. Older extra browser scripts have historical feature expectations.
- All actual device/network limitations must stay visible in TEST_REPORT.md; never invent a passed count or physical-phone test.

## Historical project handoff (v10 and earlier)

# Roadcraft v10 - coding handoff

Plain HTML/CSS/JavaScript, original custom WebGL; no runtime npm dependencies.
Current app/save version: 10.0.0 / schema 10. Use README.md and TEST_REPORT.md as the
source of current scope. Never claim no bugs, hardware certification, photorealism,
full ragdoll/crash simulation or a publicly hosted multiplayer service.

## Roadcraft modules and invariants

- `mobility.js`: thirteen rides, ten of them cars. Keep all known IDs stable.
- `vehicle-dynamics.js`: surface data, zone sanitization, condition, bounded crush,
  spring-response helpers and 63-node anchored visual cages. Not a full vehicle
  soft-body solver. Cages skin graphics; `travel.js` keeps a rigid contact hull.
- `travel.js`: 120 Hz maximum substep; OBB solid checks, simplified tyre grip,
  inertia, braking/reverse and sprung pose. Always preserve finite caps.
- `car-world.js`: distinct composite car models, actual wheel motion, material
  groups, skinning, contact shadow and bounded temporary skid buffers.
- `engine.js`/`visuals.js`: composite drawing, shader material finish, procedural
  highlights/wet sheen/night beam. Restore shader and depth writes after effects.
- `travel-panels.js`: ten-car showroom and drivingSetup/service UI; retain small
  screen scrolling. No forced dependence on a desktop input mode.
- `rides.damage[id]`: four bounded damage zones saved for owned cars. Do not clear
  dents on mount/dismount. Delete a shell's GPU buffers when repairing/rebuilding.
- R180 repairs require ownership, damage, zero/low speed and funds; driver health
  is separate. In co-op use the server command, never a second local debit.
- Co-op car ownership is shared; zone damage is personal. Do not claim that the
  server simulates or validates all vehicle physics. Pose IDs/speed allow the new
  catalogue. Server receipts preserve retry-idempotent repairs/purchases.
- `ROADCRAFT.md` records scope; never rename this a BeamNG engine or full physics.
- New tests: `v10.test.cjs`, `v10-coop.test.cjs`, `v10_browser.py`.

## Everyday Life modules and invariants

- `commerce-data.js`: 20 workplace IDs, locations, prices and three-step job cards.
- `commerce.js`: deterministic rules, integer game rands, validation, reserved
  inventory, current/savings/till transfers, one work ticket, payment-once tokens,
  staff sales and explicit paid-day costs. Shared by solo and co-op; never fork
  the money rules into the UI. Preserve strict known-ID validation.
- `commerce-world.js`: real open-door workspaces, branch, ATM and employers.
- `commerce-panels.js`: phone/standalone banking, portfolios, jobs and work cards.
  `#commerceFinish` belongs in the fixed modal footer; text remains scrollable.
- `state.enterprise` is migrated/validated by storage and sent in TEAM_KEYS on
  the room server. `tools/coop.mjs` pose bounds match the expanded world.
- Wages enter Current; costs debit Current; customers credit each business till;
  till collection moves the existing balance. Original shops still use cash.
- Daily costs paid explicitly; no closed-shop charges, overdrafts or offline
  earnings. One shift per employer per game day. Staff share actual stocked units.
- One co-op work ticket is shared across both teammates. Wrong or repeated tokens
  never consume stock/pay again. All co-op commerce commands use sequenced receipts.
- No external financial service, real player payment details, account passwords
  or P2P transfer system. Developer cheats waive costs only in solo; transfers
  always require real in-game funds. Do not represent the client code as secure.
- New test files: v9.test.cjs, v9-coop.test.cjs, v9_browser.py and
  v9_coop_browser.py. Native browser navigation is policy-blocked in this execution
  environment; the bridge/storage fixtures are test-only and never ship enabled.
- World rendering under menus is throttled independently from simulation/UI.
  Never throttle work timers, co-op polling or input as a side effect.

## Retained v8 modules

- `src/camera.js`: pure orbit state and collision-shortened following boom.
  Looking MUST NOT modify `rideMotion.heading`. `lookBy()` routes car input here;
  on-foot and light-ride looking stays unchanged. C/reset retains distance.
- `src/people.js`: pure crowd rules and articulated mesh rendering. Stable local
  seeds, walking/greeting/idle/phone modes, danger sidesteps, non-fatal health,
  falling/down/rising/shaken progression, immunity and first-aid single use.
  Use the world's collision functions. Do not permanently remove story NPCs.
- `src/activities.js`: deterministic rules used by both solo and the Node room
  server. Validate range and prerequisites; award completion once only. Count
  fields are integers, cooldowns preserve fractional simulation seconds.
- `src/outdoor-world.js`: batch the two southern districts, props, contacts,
  traffic and paths; draw small dynamic props after selecting the colour shader.
- `src/outdoor-panels.js`: scrollable activity/care/camera instruction panels.
- `src/neighbourhood.js`: seven districts, forty customers, expanded bounds and
  shared server customer anchors. Arjun is on the pavement at (29,168), not
  inside South Bay Studios. Keep all contacts and activity approaches reachable.

## Preserve these systems

`src/travel.js` handles jump, car tyre/grip/steering and solid OBB collisions.
World bounds are x[-270,124], z[-130,190]; update server pose validation with any
future expansion. `src/atlas.js` provides names/search/track; `world.getPoint`
accepts all current `roadN` IDs. `src/storage.js` migrates saves 1 through 10;
preserve money/vehicles and the version-independent key. `src/device.js` must
recognise schema 10 when protecting against a newer tab.

The shared server owns business transactions AND `team.outdoors`. Never perform
solo payouts while in a room. Send an ordered `coop.send` command; preserve its
sequence through retry and reconnect. Do not enable developer money in a room.
Never overwrite the solo save with a room snapshot. `tools/coop-rules.mjs` loads
the same activity rules and authorises proximity; rewards do not trust a client
cash amount. Basketball is a trusted-client score with rate/proximity checks,
not an anti-cheat competitive leaderboard and not a money source.

Crowd presentation/injury remains local, like personal police and health.
Co-op customer idle poses retain canonical locations for server trade checks;
do not market this as one authoritative shared crowd simulation.

Fictional Glowleaf and all growing/crafting rules must stay invented game rules.
No real controlled-substance cultivation instructions are required.

## Mobile and graphics

Keep joystick pointer ownership separate from world-look pointer ownership.
Cancels, rotations and lost capture clear input. Speedometer camera actions must
remain above the bottom navigation in landscape, not underneath it. Use measured
visible viewport/safe-area variables, and maintain fixed modal headers/footers
with scrollable bodies. Preserve small-screen phone shells and transparent
control hit areas. Test actual elementFromPoint hit targets, not just rectangles.

All meshes use the original renderer; restore colour shader before colour props
following textured signs. Camera collision cannot hide the renderer behind walls.
Animated arms are separate from torso meshes to avoid duplicates.

## Build and verify

`npm run build`, `npm test`, `node --test tests/analytics.test.cjs`.
Browser suites: browser_smoke.py, safety_smoke.py, v4_browser.py, mobile_fit.py,
v5_browser.py, v6_browser.py, v7_browser.py and v8_browser.py. v7 includes two
real browser clients to a real local room API via a test-only HTTP Fetch bridge.
The delivered game MUST NOT contain that bridge or enabled MZ_TEST_MODE/storage
adapters. Tests use fixture travel/time and controlled inputs where documented.

Native file/HTTP browser navigation was blocked in the build environment;
physical phones, native restart durability and public Internet hosting still
need user-device tests. Do not convert failed or unexecuted runs into passes.

Private storage and real tokens must never be packaged. Server log output in
QA is synthetic test data, not real players. Use one running server instance for
trusted friends; file-backed rooms are not a production distributed database.

### Roadcraft memory and preview invariants
Only the currently driven car retains a deformation skin/cage. Dispose dynamic
GL buffers when changing cars, but never delete the original model meshes or
persisted four-zone damage. Recreate the visual skin from saved damage when a
car is selected again. Cage springs sleep after settling and wake on setCrush.
Showroom previews must contain-fit the rendered alpha bounds; do not crop wheels
or bumpers when changing vehicle dimensions. The preview test checks all ten.
