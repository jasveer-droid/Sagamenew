'use strict';
const test=require('node:test'),a=require('node:assert/strict'),http=require('node:http'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path');
test('Roadcraft new cars and repair receipts on the actual shared HTTP server',async t=>{
 const {createCoop}=await import('../tools/coop.mjs');const dir=await fs.mkdtemp(path.join(os.tmpdir(),'mz-v10-'));const coop=await createCoop({enabled:true,directory:dir});
 const server=http.createServer(async(req,res)=>{if(!await coop.handle(req,res)){res.writeHead(404);res.end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;
 const req=async(endpoint,body)=>{const r=await fetch(url+'/api/coop/'+endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {...await r.json(),status:r.status};};
 try{
  const host=await req('create',{name:'Driver',password:'unit-test-pass'}),guest=await req('join',{name:'Partner',password:'unit-test-pass',code:host.code});let seq=0;
  const room=coop.rooms.get(host.code);room.team.cash=500000;
  const act=(action,speed=0)=>req('action',{code:host.code,token:host.token,seq:++seq,action,pose:{x:-58.5,z:30,yaw:0,speed,ride:null,health:100}});
  const pulse=()=>req('pulse',{code:guest.code,token:guest.token});
  for(const id of ['sedan','coupe','suv','van','minibus','rally','classic','electric'])await t.test(id+' unlock is visible to both room members',async()=>{const r=await act({type:'buyRide',id});a.ok(r.receipt.ok);a.ok((await pulse()).team.owned[id]);});
  await t.test('new car pose is accepted without clamping its intended speed',async()=>{await req('pulse',{code:host.code,token:host.token,pose:{x:0,z:160,yaw:0,ride:'electric',speed:31,health:100}});const r=await pulse(),p=r.members.find(m=>m.id===host.you).pose;a.equal(p.ride,'electric');a.equal(p.speed,31);});
  await t.test('unknown pose ride cannot be broadcast',async()=>{await req('pulse',{code:host.code,token:host.token,pose:{x:0,z:0,ride:'__proto__',speed:1}});const p=(await pulse()).members.find(m=>m.id===host.you).pose;a.equal(p.ride,null);});
  await t.test('duplicate vehicle purchase is rejected without charge',async()=>{const before=(await pulse()).team.cash;const r=await act({type:'buyRide',id:'coupe'});a.equal(r.receipt.ok,false);a.equal(r.team.cash,before);});
  await t.test('stationary repair has one shared debit and a personal receipt',async()=>{const before=(await pulse()).team.cash;const r=await act({type:'repairCar',id:'coupe'});a.ok(r.receipt.ok);a.equal(r.team.cash,before-180);a.equal(r.receipt.personal.repaired,'coupe');const again=await req('action',{code:host.code,token:host.token,seq,action:{type:'repairCar',id:'coupe'}});a.equal(again.team.cash,before-180);});
  await t.test('moving vehicle service is rejected',async()=>{const before=(await pulse()).team.cash,r=await act({type:'repairCar',id:'coupe'},12);a.equal(r.receipt.ok,false);a.equal(r.team.cash,before);});
  await t.test('unowned/unknown car cannot receive a repair',async()=>{const before=(await pulse()).team.cash;for(const id of ['hatchback','__proto__','skateboard']){const r=await act({type:'repairCar',id});a.equal(r.receipt.ok,false);a.equal(r.team.cash,before);}});
  await t.test('shared wallet cannot overdraw a repair',async()=>{room.team.cash=10;const r=await act({type:'repairCar',id:'coupe'});a.equal(r.receipt.ok,false);a.equal(r.team.cash,10);});
 }finally{await coop.close();await new Promise(r=>server.close(r));await fs.rm(dir,{recursive:true,force:true});}
});
