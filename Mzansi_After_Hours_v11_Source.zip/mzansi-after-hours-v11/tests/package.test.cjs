require('../src/vehicle-dynamics.js');
/** Verify the distributable and actual included HTTP server with Node built-ins. */
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const {spawn}=require('node:child_process');
const http=require('node:http');const net=require('node:net');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'Mzansi_After_Hours_v11.html'),'utf8');
test('Standalone has no external script, stylesheet or asset dependencies',()=>{
 assert.doesNotMatch(html,/<script[^>]+src\s*=/i);
 assert.doesNotMatch(html,/<link\b/i);
 assert.doesNotMatch(html.split('<script>')[0],/<(?:img|audio|video)[^>]+src\s*=\s*["'](?!data:)/i);
 assert.match(html,/window\.MZ_STANDALONE=true/);
 assert.doesNotMatch(html,/window\.MZ_TEST_MODE\s*=\s*true/);
 assert.doesNotMatch(html,/__testStore/);
});
test('Manifest icons are local and present',()=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest')));
 for(const icon of manifest.icons)assert.ok(fs.existsSync(path.join(root,icon.src)));
 assert.equal(manifest.display,'standalone');
});
function request(port,url,method='GET'){
 return new Promise((resolve,reject)=>{const req=http.request({host:'127.0.0.1',port,path:url,method},res=>{let body='';res.on('data',c=>body+=c);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,body}));});req.on('error',reject);req.end();});
}
test('Actual local server serves HTML and scripts, rejects writes and unsupported paths',async()=>{
 const socket=net.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 const child=spawn(process.execPath,[path.join(root,'tools/server.mjs')],{env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
 try{
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Server did not start')),7000);child.once('error',reject);child.stdout.once('data',()=>{clearTimeout(timer);resolve();});});
  const index=await request(port,'/');assert.equal(index.status,200);assert.match(index.body,/MZANSI/);
  const script=await request(port,'/src/game.js');assert.equal(script.status,200);assert.match(script.headers['content-type'],/javascript/);
  assert.equal((await request(port,'/','POST')).status,405);
  assert.equal((await request(port,'/README.md')).status,403);
  assert.equal((await request(port,'/missing.png')).status,404);
  assert.notEqual((await request(port,'/..%2f..%2fetc/passwd')).status,200);
  const head=await request(port,'/assets/icon-192.png','HEAD');assert.equal(head.status,200);assert.equal(head.body,'');
 }finally{child.kill();}
});
