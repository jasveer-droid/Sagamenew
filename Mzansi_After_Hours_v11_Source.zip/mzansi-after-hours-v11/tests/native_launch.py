"""Try actual local URLs and native browser storage; reports environmental restrictions honestly."""
from pathlib import Path
import json,subprocess,os,time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'test-results'
report={'attempts':[]}
server=subprocess.Popen(['node',str(ROOT/'tools/server.mjs')],env={**os.environ,'PORT':'8183'},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
 server.stdout.readline()
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=False,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
  for label,url in [('standalone-file',(ROOT/'Mzansi_After_Hours_v11.html').as_uri()+'?debug=1'),('editable-http','http://127.0.0.1:8183/index.html?debug=1')]:
   ctx=b.new_context();page=ctx.new_page();case={'name':label}
   try:
    page.goto(url,timeout=10000);page.wait_for_function('!!window.GameDebug',timeout=15000)
    case['launch']=True
    page.evaluate("GameDebug.start(true);GameDebug.state.cash=1294;GameDebug.save();")
    page.reload(timeout=10000);page.wait_for_function('!!window.GameDebug',timeout=15000)
    case['native_save_survives_reload']=page.evaluate('GameDebug.state.cash===1294')
   except Exception as e:case['launch']=False;case['limitation']=str(e)[:1200]
   report['attempts'].append(case);ctx.close()
  b.close()
finally:
 server.terminate();server.wait(timeout=5)
(OUT/'native-launch-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
