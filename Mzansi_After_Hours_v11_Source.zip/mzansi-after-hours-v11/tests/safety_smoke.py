"""Additional denied-storage, focus and WebGL recovery regressions.
Uses the same explicitly disclosed in-memory/browser emulation harness as the
main browser suite. Run with: xvfb-run -a python tests/safety_smoke.py
"""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'test-results';OUT.mkdir(exist_ok=True)
HTML=(ROOT/'Mzansi_After_Hours_v11.html').read_text()
# Import only the helper definitions; the main browser script is executable.
helper=(ROOT/'tests/browser_smoke.py').read_text().split('with sync_playwright() as p:')[0]
exec(compile(helper,str(ROOT/'tests/browser_smoke.py'),'exec'))
results=[];errors=[];console_errors=[]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=False,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=b.new_page(viewport={'width':900,'height':650});load(page);fixture(page)
    check(page,'Denied persistent storage warns without stopping play',"window.saveMethod=localStorage.setItem;localStorage.setItem=()=>{throw new Error('Denied for test')};GameDebug.save();return document.getElementById('saveStatus').textContent==='EXPORT TO SAVE'&&!GameDebug.contextLost")
    check(page,'Storage can recover without a new game',"localStorage.setItem=window.saveMethod;GameDebug.save();return document.getElementById('saveStatus').textContent==='SAVED ON THIS BROWSER'")
    check(page,'Losing focus pauses and keeps the session alive',"GameDebug.close();window.dispatchEvent(new Event('blur'));return GameDebug.panel==='pause'&&GameDebug.paused&&!GameDebug.contextLost")
    page.keyboard.press('Tab')
    check(page,'Keyboard focus stays in the open dialog',"return document.getElementById('modal').contains(document.activeElement)")
    evaluate(page,"window.lossExtension=GameDebug.renderer.gl.getExtension('WEBGL_lose_context');window.lossExtension.loseContext()")
    page.wait_for_function("GameDebug.contextLost&& !document.getElementById('recoveryOverlay').classList.contains('hidden')",timeout=10000)
    check(page,'Graphics loss shows the save recovery overlay',"return document.getElementById('recoveryText').textContent.includes('Graphics were interrupted')")
    page.wait_for_timeout(300);evaluate(page,"window.lossExtension.restoreContext()")
    page.wait_for_function("!GameDebug.contextLost&&document.getElementById('recoveryOverlay').classList.contains('hidden')",timeout=15000)
    check(page,'Restored graphics rebuild and return to a paused game',"return GameDebug.panel==='pause'&&GameDebug.paused&&GameDebug.renderer.gl.getError()===0")
    check(page,'Graphics restore preserves cash and chapter',"return GameDebug.state.cash===2500&&GameDebug.state.story.chapter===15")
    b.close()
results.append({'name':'No unexpected exceptions in recovery tests','passed':not errors,'detail':errors})
# Deliberate context loss may cause browser WebGL warnings, not application errors.
report={'test_method':'Same headed Chromium / SwiftShader set_content harness as browser_smoke.py. Deliberate storage denial, blur event and WEBGL_lose_context simulation.', 'results':results,'console_errors':console_errors,'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results)}
(OUT/'safety-results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'failed':report['failed']}),flush=True)
raise SystemExit(1 if report['failed'] else 0)
