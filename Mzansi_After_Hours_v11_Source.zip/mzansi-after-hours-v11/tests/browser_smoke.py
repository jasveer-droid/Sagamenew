"""Browser regression suite. Requires Python Playwright and Chromium, not for play.
Runs exact standalone HTML via set_content because this test environment blocks URL
navigation. A test-only in-memory localStorage adapter is used on about:blank.
No adapter or debug flag is included in the shipping game.
Linux/headed example: xvfb-run -a python tests/browser_smoke.py
"""
from pathlib import Path
import json, os
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'test-results';OUT.mkdir(exist_ok=True)
HTML=(ROOT/'Mzansi_After_Hours_v11.html').read_text()
HARNESS='''<script>window.MZ_TEST_MODE=true;window.__testStore=new Map();Object.defineProperty(window,'localStorage',{value:{getItem:k=>__testStore.get(k)||null,setItem:(k,v)=>__testStore.set(k,String(v)),removeItem:k=>__testStore.delete(k),clear:()=>__testStore.clear()}});</script>'''
results=[];errors=[];console_errors=[]
def check(page,label,js):
    try:
        result=page.evaluate('() => {'+js+'}')
        recovery=page.locator('#recoveryOverlay')
        if recovery.is_visible(): print('RECOVERY AT',label,page.locator('#recoveryText').inner_text(),flush=True)
        if result is False: raise AssertionError('returned false')
        results.append({'name':label,'passed':True,'detail':result});print('PASS',label,flush=True)
    except Exception as e:
        results.append({'name':label,'passed':False,'detail':str(e)});print('FAIL',label,str(e)[:200],flush=True)
def dismiss(page):
    page.evaluate('GameDebug.state.story.seen=GameDebug.state.story.chapter;GameDebug.close()')
def evaluate(page,js):return page.evaluate('() => {'+js+'}')
def load(page):
    page.bring_to_front()
    page.set_default_timeout(30000)
    page.on('pageerror',lambda e:(errors.append(str(e)),print('PAGE ERROR:',str(e),flush=True)))
    page.on('console',lambda e:(console_errors.append(e.text),print('CONSOLE ERROR:',e.text,flush=True)) if e.type=='error' else None)
    page.set_content(HTML.replace('<head>','<head>'+HARNESS,1),wait_until='load')
    page.wait_for_function('!!window.GameDebug',timeout=45000)
def fixture(page):
    evaluate(page,"GameDebug.start(true);const s=GameDebug.state;s.story.chapter=15;s.story.seen=15;s.victory=true;s.nextOrder=1e9;s.settings.quality=0;GameDebug.applySettings();GameDebug.close();GameDebug.setState({});MZPeople.tick(GameDebug.world,GameDebug.state,0,{coop:false});")

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=False,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    ctx=browser.new_context(viewport={'width':1440,'height':900},accept_downloads=True)
    page=ctx.new_page();load(page)
    check(page,'WebGL boot and title',"return !document.querySelector('#titleScreen').classList.contains('hidden')&&GameDebug.renderer.gl.getError()===0")
    check(page,'All fifteen story chapters are bundled',"return MZStory.chapters.length===15")
    page.screenshot(path=str(OUT/'desktop-title.png'));evaluate(page,"GameDebug.state.settings.quality=0;GameDebug.state.settings.maxFps=30;GameDebug.applySettings()")
    page.locator('#startBtn').click();page.wait_for_function("GameDebug.panel==='careerChoice'");page.locator('[data-action=cityStory]').click();page.wait_for_timeout(200)
    check(page,'Start opens the paused story introduction',"return GameDebug.panel==='chapter'&&GameDebug.paused&&GameDebug.state.story.chapter===0")
    page.locator('[data-action="lessonNext"]').click();page.locator('[data-action="storyBegin"]').click();page.wait_for_function("GameDebug.state.story.chapter===1&&GameDebug.panel==='chapter'",timeout=8000)
    check(page,'Taking the keys starts movement lesson',"return GameDebug.state.story.chapter===1&&GameDebug.panel==='chapter'")
    page.locator('[data-action="lessonNext"]').click();page.locator('[data-action="resume"]').click()
    page.keyboard.down('ArrowRight');page.wait_for_function('GameDebug.state.story.looked>=.25',timeout=10000);page.keyboard.up('ArrowRight')
    page.keyboard.down('w');page.wait_for_function('GameDebug.state.story.walked>=3',timeout=10000);page.keyboard.up('w')
    check(page,'Real keyboard walking and turning advance tutorial',"return GameDebug.state.story.walked>=3&&GameDebug.state.story.looked>=.22&&GameDebug.state.story.chapter===2")
    dismiss(page)
    evaluate(page,"GameDebug.teleport(-34.8,16.1,Math.PI)")
    page.keyboard.press('e');page.wait_for_timeout(80)
    check(page,'E interaction opens Zanele dialogue',"return GameDebug.panel==='mentor'")
    page.locator('[data-action="lessonNext"]').click();page.locator('[data-action="mentorTalk"]').click();page.wait_for_timeout(180)
    check(page,'Meeting the guide advances to backpack',"return GameDebug.state.story.chapter===3")
    page.keyboard.press('i');page.wait_for_timeout(80)
    check(page,'Opening backpack records the lesson',"return GameDebug.panel==='inventory'&&GameDebug.state.story.chapter===4")
    dismiss(page);evaluate(page,"GameDebug.teleport(-38.5,18.6,Math.PI)");page.keyboard.press('e')
    check(page,'Bench can be reached and interacted with',"return GameDebug.panel==='bench'&&!GameDebug.paused")
    page.locator('[data-action="prepareBatch"][data-id="glow"]').click()
    for i in range(3):page.locator('[data-action=batchToken][data-id="'+str(i)+'"]').click()
    page.locator('[data-action=batchNext]').click();page.locator('[data-action=batchMatch][data-id=glow]').click();page.locator('[data-action=sealBatch]').click()
    check(page,'Mixing deducts only recipe inputs',"return GameDebug.state.inv.leaf===6&&GameDebug.state.inv.pouch===9&&GameDebug.state.jobs.length===1")
    evaluate(page,'GameDebug.advance(10.1)')
    check(page,'Timed first batch and story completion',"return GameDebug.state.products.glow===3&&GameDebug.state.stats.crafted===1&&GameDebug.state.story.chapter===5")
    page.keyboard.press('p');page.wait_for_timeout(70)
    page.locator('[data-action=phoneTab][data-id=orders]').last.click()
    check(page,'Phone displays real order stock',"return GameDebug.panel==='phone'&&document.querySelector('#modalBody').textContent.includes('Sipho')")
    page.locator('[data-action="track"][data-id="sipho"]').click();page.wait_for_timeout(120)
    check(page,'Tracking correct customer completes phone lesson',"return GameDebug.state.track==='sipho'&&GameDebug.state.story.chapter===6")
    dismiss(page);evaluate(page,"GameDebug.teleport(-13.5,5.5,Math.PI)");page.keyboard.press('e')
    page.locator('[data-action="deliver"]').click();page.wait_for_timeout(120)
    check(page,'First contract pays once plus mentor support',"return GameDebug.state.cash===2750&&GameDebug.state.totalRevenue===170&&GameDebug.state.products.glow===1&&GameDebug.state.story.chapter===7")
    check(page,'Fulfilled contract removed before save',"return !GameDebug.load().orders.some(o=>o.npc==='sipho')")
    dismiss(page);evaluate(page,"GameDebug.teleport(-30,-4.6,0)");page.keyboard.press('e')
    page.locator('[data-action="buy"][data-id="seed"]').click();page.locator('[data-action="buy"][data-id="pouch"]').click()
    check(page,'Both restock actions advance the story',"return GameDebug.state.story.chapter===8&&GameDebug.state.inv.seed===4&&GameDebug.state.cash===2740")
    dismiss(page);evaluate(page,"GameDebug.open('grow',GameDebug.world.getPoint('grow'));GameDebug.action('plant',{id:'0'});GameDebug.advance(35.2);GameDebug.action('plant',{id:'0'});")
    check(page,'Seed planting and harvest produce six leaves',"return GameDebug.state.stats.harvested===1&&GameDebug.state.inv.leaf===12&&GameDebug.state.story.chapter===9")
    dismiss(page);evaluate(page,"GameDebug.open('bench');GameDebug.action('craft',{id:'mist'});GameDebug.advance(10.1);GameDebug.open('customer',GameDebug.world.getPoint('lerato'));GameDebug.action('deliver',{id:String(GameDebug.state.orders.find(o=>o.npc==='lerato').id)});")
    check(page,'Moon Mist production and delivery teach new blend',"return GameDebug.state.story.chapter===10&&GameDebug.state.products.mist===0&&GameDebug.state.totalRevenue===515")
    dismiss(page);evaluate(page,"GameDebug.open('mentor');GameDebug.action('mentorTalk');")
    check(page,'Attention lesson is acknowledged and remembered',"return GameDebug.state.story.flags.heatLesson&&GameDebug.state.story.chapter===11")
    dismiss(page);evaluate(page,"GameDebug.open('upgrades');GameDebug.action('upgrade',{id:'mixer'});")
    check(page,'Equipment purchase advances without negative cash',"return GameDebug.state.upgrades.mixer&&GameDebug.state.cash>=0&&GameDebug.state.story.chapter===12")
    # Continue by actually buying inputs, making batches, and selling. Only the
    # acceptance RNG is fixed so this test cannot fail randomly.
    evaluate(page,"""
    window.earnTo=function(predicate){
      let count=0;const d=GameDebug;
      while(!predicate(d.state)&&count++<120){
        d.state.story.seen=d.state.story.chapter;d.close();
        const s=d.state;const recipe=s.rep>=16?'prism':s.rep>=6?'sunburst':'glow';
        d.open('shop');for(const [k,n] of Object.entries(MZData.RECIPES[recipe].needs)){let guard=0;while(s.inv[k]<n&&guard++<5)d.action('buy',{id:k});}
        d.open('bench');d.action('craft',{id:recipe});d.advance(10.2);
        // A real player can run low on supplies after buying a property/runner.
        // Use the actual free grocery job, not injected cash, to recover.
        if (!Object.values(s.products).some(n=>n>0)) {
          d.close(); if(s.sim<s.recovery.next)d.advance(s.recovery.next-s.sim+.1);
          d.open('shop'); d.action('oddJob');
          d.open('customer',d.world.getPoint('musa'));d.action('completeOddJob');continue;
        }
        d.open('customer',d.world.getPoint('sipho'));
        const product=document.getElementById('tradeProduct');if(!product){d.close();d.advance(8.1);d.open('customer',d.world.getPoint('sipho'));}
        const selected=s.products[recipe]>0?recipe:Object.keys(s.products).find(k=>s.products[k]>0);
        document.getElementById('tradeProduct').value=selected;document.getElementById('tradeProduct').dispatchEvent(new Event('input',{bubbles:true}));
        const qty=document.getElementById('tradeQty');qty.value=String(Math.min(3,s.products[selected]));
        const old=Math.random;Math.random=()=>0;try{d.action('sell');}finally{Math.random=old;}
      }
      return count;
    };
    earnTo(s=>s.cash>=3500);
    """)
    check(page,'Repeatable economy earns workshop money',"return GameDebug.state.cash>=1600&&GameDebug.state.totalRevenue>515")
    check(page,'Unowned workshop gate blocks passage',"return !GameDebug.world.isFree(28,24.5,GameDebug.state)")
    evaluate(page,"GameDebug.open('property');GameDebug.action('property');")
    check(page,'Property purchase opens the physical gate',"return GameDebug.state.workshop&&GameDebug.world.isFree(28,24.5,GameDebug.state)&&GameDebug.state.story.chapter===13")
    evaluate(page,"earnTo(s=>s.cash>=700);GameDebug.open('runner');GameDebug.action('runner');")
    check(page,'Hiring a runner opens final chapter',"return GameDebug.state.runner&&GameDebug.state.reserveOrders&&GameDebug.state.story.chapter===14")
    evaluate(page,"earnTo(s=>s.totalRevenue>=5000);GameDebug.state.story.seen=GameDebug.state.story.chapter;GameDebug.close();GameDebug.advance(.1)")
    check(page,'Full campaign reaches its ending and free play',"return GameDebug.state.story.chapter===15&&GameDebug.state.victory&&GameDebug.state.totalRevenue>=5000")
    evaluate(page,"GameDebug.open('victory')");page.screenshot(path=str(OUT/'ending.png'))
    check(page,'Campaign never exceeded bag or went negative',"return GameDebug.state.cash>=0&&Object.values(GameDebug.state.products).every(n=>n>=0)&&Object.values(GameDebug.state.products).reduce((a,b)=>a+b,0)<=(GameDebug.state.upgrades.bag?80:40)")
    check(page,'Campaign did not trigger recovery overlay',"return !GameDebug.contextLost&&document.getElementById('recoveryOverlay').classList.contains('hidden')")
    # Focused regression fixtures.
    fixture(page)
    check(page,'No debug actions available from wrong panels',"const before=GameDebug.state.inv.leaf;GameDebug.open('inventory');GameDebug.action('craft',{id:'glow'});return GameDebug.state.inv.leaf===before&&GameDebug.state.jobs.length===0")
    check(page,'Unaffordable shop purchase changes nothing',"GameDebug.state.cash=0;GameDebug.open('shop');const n=GameDebug.state.inv.seed;GameDebug.action('buy',{id:'seed'});return GameDebug.state.cash===0&&GameDebug.state.inv.seed===n")
    check(page,'Missing recipe ingredients cannot underflow stock',"GameDebug.state.inv.leaf=0;GameDebug.open('bench');GameDebug.action('craft',{id:'glow'});return GameDebug.state.jobs.length===0&&GameDebug.state.inv.leaf===0")
    check(page,'Reputation locks premium recipes',"const s=GameDebug.state;s.inv.leaf=20;s.inv.prism=10;s.inv.pouch=30;GameDebug.action('craft',{id:'prism'});return s.jobs.length===0")
    fixture(page)
    check(page,'Timing bonus uses actual mint-zone hits',"const d=GameDebug;d.open('bench');d.action('craft',{id:'glow'});const j=d.state.jobs[0];d.action('steady',{id:String(j.id)});d.advance(Math.PI/3.1);d.action('steady',{id:String(j.id)});d.advance(10);return d.state.products.glow===4")
    fixture(page)
    check(page,'Rapid repeated timing taps are rejected',"const d=GameDebug;d.open('bench');d.action('craft',{id:'glow'});const j=d.state.jobs[0];for(let i=0;i<10;i++)d.action('steady',{id:String(j.id)});return j.taps===1")
    fixture(page)
    check(page,'Concurrent mixing reserves output capacity',"const d=GameDebug;d.state.upgrades.mixer=true;d.open('bench');d.action('craft',{id:'glow'});d.action('craft',{id:'mist'});const ids=d.state.jobs.map(j=>j.id);d.advance(10.2);return new Set(ids).size===2&&d.state.products.glow===3&&d.state.products.mist===3")
    check(page,'Full bag prevents consuming new inputs',"const d=GameDebug;d.state.products={glow:40,mist:0,sunburst:0,prism:0};const leaf=d.state.inv.leaf;d.action('craft',{id:'glow'});return d.state.jobs.length===0&&d.state.inv.leaf===leaf")
    fixture(page)
    check(page,'Runner sells only unreserved stock',"const d=GameDebug,s=d.state;s.workshop=s.runner=true;s.products.glow=6;s.orders=[{id:9,npc:'sipho',recipe:'glow',qty:4,pay:300}];s.runnerTick=s.sim;d.advance(25.1);return s.products.glow===4&&s.stats.runnerSales===2&&s.totalRevenue===128")
    check(page,'Fully reserved orders remain untouched',"const d=GameDebug;d.advance(26);return d.state.products.glow===4&&d.state.stats.runnerSales===2")
    check(page,'Reservation toggle enables spare-stock deliveries',"const d=GameDebug;d.open('runner');d.action('toggleReserve');d.close();d.advance(25.1);return d.state.products.glow===2&&d.state.stats.runnerSales===4")
    check(page,'Runner pause stops dispatches',"const d=GameDebug;d.open('runner');d.action('toggleRunner');d.close();d.advance(50);return d.state.products.glow===2")
    fixture(page)
    check(page,'Recovery job has no upfront cost',"const d=GameDebug;d.state.cash=0;d.open('shop');d.action('oddJob');return d.state.recovery.active&&d.state.cash===0&&d.state.track==='musa'")
    check(page,'Grocery delivery requires the correct customer',"const d=GameDebug;d.open('customer',d.world.getPoint('sipho'));d.action('completeOddJob');return d.state.recovery.active&&d.state.cash===0")
    check(page,'Recovery delivery pays once and has a cooldown',"const d=GameDebug;d.open('customer',d.world.getPoint('musa'));d.action('completeOddJob');d.open('customer',d.world.getPoint('musa'));d.action('completeOddJob');d.open('shop');d.action('oddJob');return d.state.cash===75&&!d.state.recovery.active&&d.state.recovery.count===1")
    fixture(page)
    evaluate(page,"GameDebug.open('pause');window.pauseTime=GameDebug.state.sim")
    page.wait_for_timeout(350)
    check(page,'Pause menu freezes simulation',"return GameDebug.state.sim===window.pauseTime")
    evaluate(page,"GameDebug.open('phone');window.pauseTime=GameDebug.state.sim")
    page.wait_for_timeout(250)
    check(page,'Reading phone pauses the world safely',"return GameDebug.state.sim===window.pauseTime")
    fixture(page)
    check(page,'Wall substeps prevent tunnelling',"const d=GameDebug;const p={x:-42,z:20};d.world.move(p,-8,0,d.state);return p.x>-42.6&&p.x<-42")
    check(page,'World boundaries block escape',"return !GameDebug.world.isFree(MZNeighbourhood.bounds.maxX+2,0,GameDebug.state)")
    fixture(page)
    check(page,'Patrol capture applies fine and respawns',"const d=GameDebug,s=d.state;s.cash=500;s.products.glow=8;s.heat=90;s.lastSale=s.sim;s.player.x=0;s.player.z=0;const cop=d.world.police[0];cop.x=.7;cop.z=0;const a=MZPolice.setup(cop);a.mode='chase';a.lastSeen=s.sim;a.last={x:0,z:0};d.advance(.1);d.action('policeComply');return s.cash===320&&s.products.glow===6&&s.stats.fines===1&&s.heat===0&&d.world.inHome(s.player.x,s.player.z)")
    fixture(page)
    check(page,'Sleeping finishes plants and batches',"const d=GameDebug;d.open('grow');d.action('plant',{id:'0'});d.open('bench');d.action('craft',{id:'glow'});d.open('bed');d.action('sleep');return d.state.day===2&&d.state.clock===420&&d.state.products.glow===3&&d.state.sim-d.state.plants[0].start>=35")
    check(page,'Save roundtrip preserves real game state',"const d=GameDebug;d.save();const v=d.load();return v.cash===d.state.cash&&v.products.glow===d.state.products.glow&&v.story.chapter===d.state.story.chapter")
    check(page,'Corrupt primary falls back in the game UI loader',"const d=GameDebug;const key=MZSave.KEY;localStorage.setItem(key+'_backup1',JSON.stringify(d.state));localStorage.setItem(key,'broken');const loaded=d.load();d.save();return loaded&&loaded.cash===d.state.cash")
    check(page,'All destination panels render',"const d=GameDebug;for(const type of ['bench','grow','shop','upgrades','inventory','phone','property','runner','food','bed','taxi','map','pause','help','dev','chapter','mentor','victory']){d.open(type);if(!document.getElementById('modalTitle').textContent)return false;}return true")
    fixture(page)
    check(page,'Stale product selection is repaired safely',"const d=GameDebug;d.state.products.glow=2;d.open('customer',d.world.getPoint('sipho'));const el=document.getElementById('tradeProduct');el.value='missing';el.dispatchEvent(new Event('input',{bubbles:true}));return el.value==='glow'&&!d.contextLost")
    fixture(page)
    check(page,'Moon Mist lesson retargets to the customer after mixing',"const d=GameDebug;d.state.story.chapter=9;d.state.story.seen=9;d.state.track='bench';d.open('bench');d.action('craft',{id:'mist'});d.advance(10.1);return d.state.track==='lerato'&&d.state.story.flags.mistMade")
    # Actual file-input event: import must not replace a save before confirmation.
    fixture(page);evaluate(page,"GameDebug.open('pause')")
    payload=evaluate(page,"const s=GameDebug.snapshot();s.cash=9876;return JSON.stringify(s)")
    page.locator('#importSave').set_input_files({'name':'test-save.json','mimeType':'application/json','buffer':payload.encode()})
    page.wait_for_timeout(150)
    check(page,'Import is staged until explicit confirmation',"return GameDebug.panel==='importConfirm'&&GameDebug.state.cash===2500")
    page.locator('[data-action="confirmImport"]').click()
    check(page,'Confirmed import loads validated cash and state',"return GameDebug.state.cash===9876")
    evaluate(page,"GameDebug.open('pause')")
    page.locator('#importSave').set_input_files({'name':'bad.json','mimeType':'application/json','buffer':b'{broken'})
    page.wait_for_timeout(100)
    check(page,'Malformed import leaves current progress intact',"return GameDebug.state.cash===9876&&GameDebug.panel==='pause'")
    try:
        with page.expect_download(timeout=6000) as dl:
            page.locator('[data-action="export"]').click()
        file=dl.value;file.save_as(str(OUT/'exported-test-save.json'))
        data=json.loads((OUT/'exported-test-save.json').read_text())
        results.append({'name':'Browser JSON export contains validated save data','passed':data['cash']==9876,'detail':file.suggested_filename})
    except Exception as e:results.append({'name':'Browser JSON export contains validated save data','passed':False,'detail':str(e)})
    fixture(page);dismiss(page);evaluate(page,"GameDebug.teleport(-32,14.8,-2.5)")
    page.wait_for_timeout(130);page.screenshot(path=str(OUT/'desktop-yard.png'))
    evaluate(page,"GameDebug.open('bench');GameDebug.action('craft',{id:'glow'})")
    page.screenshot(path=str(OUT/'mixing.png'))
    check(page,'Renderer has no WebGL errors after campaign and menus',"return GameDebug.renderer.gl.getError()===0")
    # Emulated touch device: actual multi-pointer events and responsive layouts.
    ctx.close()
    mobile=browser.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=1)
    page=mobile.new_page();load(page)
    page.screenshot(path=str(OUT/'mobile-title.png'))
    page.locator('#startBtn').tap();page.wait_for_timeout(150)
    page.screenshot(path=str(OUT/'mobile-story.png'))
    check(page,'Mobile automatically enables performance settings',"return GameDebug.state.settings.quality===0&&GameDebug.state.settings.maxFps===30&&GameDebug.touch.enabled")
    fixture(page);dismiss(page);page.wait_for_timeout(150)
    check(page,'Mobile use and joystick are visible',"return !!document.querySelector('#joystick').getBoundingClientRect().width&&!document.querySelector('#touchControls').classList.contains('hidden')")
    page.screenshot(path=str(OUT/'mobile-portrait.png'))
    check(page,'Portrait HUD fits viewport without horizontal overflow',"return document.documentElement.scrollWidth<=innerWidth&&document.querySelector('#touchUse').getBoundingClientRect().right<=innerWidth&&document.querySelector('#joystick').getBoundingClientRect().left>=0")
    # CDP touch input allows genuinely independent contacts rather than mouse clicks.
    cdp=mobile.new_cdp_session(page)
    evaluate(page,"GameDebug.teleport(-32,15,-2.5);window.touchBefore={...GameDebug.state.player}")
    r=page.locator('#joystick').bounding_box();x=r['x']+r['width']/2;y=r['y']+r['height']/2
    cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y,'id':1},{'x':285,'y':390,'id':2}]})
    cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':y-30,'id':1},{'x':318,'y':396,'id':2}]})
    page.wait_for_timeout(450)
    check(page,'Two-finger movement and look operate simultaneously',"const p=GameDebug.state.player,b=window.touchBefore;return Math.hypot(p.x-b.x,p.z-b.z)>.2&&Math.abs(p.yaw-b.yaw)>.05")
    cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
    check(page,'Lifting fingers clears analog movement',"return GameDebug.touch.input.x===0&&GameDebug.touch.input.y===0")
    evaluate(page,"GameDebug.teleport(-34.8,16.1,Math.PI)")
    page.locator('#touchUse').tap()
    check(page,'Mobile USE opens an actual world interaction',"return GameDebug.panel==='mentor'")
    dismiss(page)
    page.set_viewport_size({'width':844,'height':390});page.wait_for_timeout(200)
    page.screenshot(path=str(OUT/'mobile-landscape.png'))
    check(page,'Landscape controls stay on screen',"return ['joystick','touchUse','touchSprint'].every(id=>{const r=document.getElementById(id).getBoundingClientRect();return r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight;})")
    check(page,'Landscape movement and menu controls do not overlap',"const a=document.querySelector('#joystick').getBoundingClientRect(),b=document.querySelector('.bottom-nav').getBoundingClientRect();return a.bottom<b.top")
    evaluate(page,"GameDebug.open('bench')");page.screenshot(path=str(OUT/'mobile-mixing.png'))
    check(page,'Landscape modal scrolls within available height',"const r=document.getElementById('modal').getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight")
    page.set_viewport_size({'width':360,'height':640});page.wait_for_function('MZLayout.viewport.width===360&&MZLayout.viewport.height===640')
    check(page,'Small phone modal remains within viewport',"const r=document.getElementById('modal').getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight&&r.right<=innerWidth")
    dismiss(page);evaluate(page,"GameDebug.open('pause')")
    page.locator('#touchSetting').select_option('off')
    check(page,'Touch controls can be disabled without breaking menus',"return !GameDebug.touch.enabled&&GameDebug.panel==='pause'")
    page.locator('#touchSetting').select_option('on')
    check(page,'Touch controls can be restored',"return GameDebug.touch.enabled")
    check(page,'Mobile renderer reports no WebGL errors',"return GameDebug.renderer.gl.getError()===0")
    mobile.close();browser.close()

results.append({'name':'No uncaught browser exceptions','passed':not errors,'detail':errors})
results.append({'name':'No browser console errors','passed':not console_errors,'detail':console_errors})
report={'test_method':'Chromium headed + SwiftShader; exact standalone HTML via set_content; in-memory test storage on about:blank; touch devices emulated, not physical.', 'results':results,'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results)}
(OUT/'browser-results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'failed':report['failed'],'errors':errors,'console_errors':console_errors}),flush=True)
raise SystemExit(1 if report['failed'] else 0)
