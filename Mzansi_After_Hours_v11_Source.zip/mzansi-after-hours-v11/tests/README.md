# Verification entrypoints for v11

Run `npm test` from the project root for all current Node rules, migrations,
transactions, real HTTP and packaging tests. These include older-numbered `.cjs`
suites whose compatibility expectations are deliberately retained.

The five supported browser commands are in the root README. Playwright, Chromium
and Xvfb are optional test dependencies, not requirements for playing.

Browser state, positioning, funds and time can be controlled only through an
explicitly enabled test/debug interface. Browser checks use a memory storage
adapter; two-client integration uses a test-only Fetch bridge to a real HTTP
service. Neither is present in normal shipping gameplay.

The test report distinguishes real HTTP tests, emulated phone input, application
restoration, native navigation failures and unverified physical devices.
Do not relabel passing automated assertions as bug-free certification.
