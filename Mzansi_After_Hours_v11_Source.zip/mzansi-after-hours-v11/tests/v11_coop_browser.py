"""Two browser clients -> unchanged shipping client -> real Node room server.
A test-only Python Fetch bridge is necessary because native URL navigation is blocked.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,os,subprocess,tempfile,urllib.request,urllib.error,time,traceback,shutil,socket,hashlib
R=Path(__file__).resolve().parents[1];O=R/'test-results';HTML=(R/'Mzansi_After_Hours_v11.html').read_text();checks=[];errors=[];server=None;directory=tempfile.mkdtemp(prefix='mz-v11-browser-')
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
def bridge(url,opts):
 method=opts.get('method','GET');req=urllib.request.Request(f'http://127.0.0.1:{port}'+url,data=opts.get('body','').encode() if method!='GET' else None,method=method,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=6) as r:return {'status':r.status,'body':r.read().decode()}
 except urllib.error.HTTPError as e:return {'status':e.code,'body':e.read().decode()}
def ev(p,js):p.bring_to_front();return p.evaluate('()=>{'+js+'}')
def wait(p,js):p.bring_to_front();p.wait_for_function(js,timeout=35000)
def ck(p,n,js):
 try:
  v=ev(p,js)
  if not v:raise AssertionError('returned false')
  checks.append(dict(name=n,passed=True,detail=v));print('PASS',n,flush=True)
 except Exception as e:checks.append(dict(name=n,passed=False,detail=str(e)));print('FAIL',n,str(e)[:180],flush=True)
def load(p):
 p.expose_function('__coopHTTP',bridge);p.set_default_timeout(25000);p.on('pageerror',lambda e:errors.append(str(e)))
 H="""<script>window.MZ_TEST_MODE=true;window.__testStore=new Map();Object.defineProperty(window,'localStorage',{value:{getItem:k=>__testStore.get(k)||null,setItem:(k,v)=>__testStore.set(k,String(v)),removeItem:k=>__testStore.delete(k)}});const originalFetch=window.fetch.bind(window);window.fetch=async(url,options={})=>{if(String(url).startsWith('/api/coop/')){const r=await window.__coopHTTP(String(url),options);return new Response(r.body,{status:r.status,headers:{'Content-Type':'application/json'}});}return originalFetch(url,options);};</script>"""
 p.set_content(HTML.replace('<head>','<head>'+H,1));p.wait_for_function('!!window.GameDebug',timeout=60000);ev(p,'GameDebug.state.settings.quality=0;GameDebug.state.settings.maxFps=20;GameDebug.applySettings()')
def click(p,s):p.bring_to_front();p.locator(s).first.click()
def op(p,name,x,z,ctx=None):ev(p,f"GameDebug.close();GameDebug.teleport({x},{z},0);GameDebug.open('{name}',{json.dumps(ctx)})")
def settled(p):wait(p,'!GameDebug.coop.pending')
try:
 server=subprocess.Popen(['node','tools/server.mjs','--lan','--coop'],cwd=R,env={**os.environ,'PORT':str(port),'MZ_COOP_DIR':directory},stdout=open(O/'v11-coop-server.log','w'),stderr=subprocess.STDOUT)
 for _ in range(60):
  try:urllib.request.urlopen(f'http://127.0.0.1:{port}/api/coop/status',timeout=1);break
  except:time.sleep(.1)
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=False,args=['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage'])
  a=browser.new_page(viewport={'width':1000,'height':740});context=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);b=context.new_page();load(a);load(b)
  click(a,'#startBtn');wait(a,"GameDebug.panel==='careerChoice'");click(a,'[data-action=cityDo][data-path=explore]');ev(a,"GameDebug.save();GameDebug.open('coop')");a.fill('#coopName','Host');a.fill('#coopPassword','test-only');click(a,'[data-action=coopCreate]');wait(a,'GameDebug.coop.active');code=ev(a,'return GameDebug.coop.data.code')
  ck(a,'UI creates a new shared room without overwriting solo save',"return GameDebug.state.cash===5000&&JSON.parse(localStorage.getItem(MZSave.KEY)).cash===2500")
  click(b,'#titleCoop');b.fill('#coopName','Partner');b.fill('#coopCode',code);b.fill('#coopPassword','test-only');click(b,'[data-action=coopJoin]');wait(b,'GameDebug.coop.active');wait(a,'!!GameDebug.world.partner');ck(a,'Two clients see each other in one room','return GameDebug.coop.data.members.length===2&&!!GameDebug.world.partner')
  op(a,'carShop',-58.5,30);click(a,'[data-action=buyRide][data-id=hatchback]');wait(a,'GameDebug.state.rides.owned.hatchback');wait(b,'GameDebug.state.rides.owned.hatchback');ck(b,'Server car purchase is visible to partner','return GameDebug.state.cash===500&&GameDebug.state.rides.owned.hatchback')
  op(a,'bank',-215,-103);click(a,'[data-action=commerceDo][data-kind=openAccount]');wait(a,'GameDebug.state.enterprise.bank.opened');click(a,'[data-action=bankTab][data-id=move]');a.fill('#bankAmount','180');click(a,'[data-action=commerceDo][data-kind=deposit]');wait(a,'GameDebug.state.enterprise.bank.current===180')
  op(a,'bankApplications',-215,-103);a.fill('#v11Contribution','180');click(a,'[data-action=cityDo][data-kind=apply]');wait(a,'GameDebug.state.cityLife.career.applications.length===1');wait(b,'GameDebug.state.cityLife.career.applications.length===1');ck(b,'Partner receives application pending state',"return GameDebug.state.cityLife.career.applications[0].status==='reviewing'")
  wait(a,"GameDebug.state.cityLife.career.applications[0].status==='approved'");ck(a,'Real server review timer completes without fixture acceleration','return GameDebug.state.enterprise.bank.current===180&&GameDebug.state.cash===320')
  coords=ev(b,'return MZCommerceData.byId.coffee.point');op(b,'businessConfirm',coords['x'],coords['z'],{'businessId':'coffee'});click(b,'[data-action=commerceDo][data-kind=buy]');wait(b,'!!GameDebug.state.enterprise.firms.coffee');wait(a,'!!GameDebug.state.enterprise.firms.coffee');ck(a,'Partner signs and shared loan appears on host','return GameDebug.state.enterprise.bank.current===0&&GameDebug.state.cityLife.career.loan.outstanding===756&&GameDebug.state.cash===320')
  op(a,'roulette',-224,145);click(a,'[data-action=cityDo][data-kind=roulette]');wait(a,'GameDebug.state.cityLife.casino.rounds===1');wait(b,'GameDebug.state.cityLife.casino.rounds===1');value=ev(a,'return GameDebug.state.cash');ck(b,'Roulette receipt synchronises wallet and history',f"return GameDebug.state.cash==={value}&&GameDebug.state.cityLife.casino.last.game==='roulette'")
  op(b,'slots',-229,132);click(b,'[data-action=cityDo][data-kind=slots]');wait(a,'GameDebug.state.cityLife.casino.rounds===2');ck(a,'Partner slot settles in shared casino history',"return GameDebug.state.cityLife.casino.last.game==='slots'")
  op(a,'blackjack',-208,145)
  for i in range(5):
   old=ev(a,'return GameDebug.state.cityLife.casino.wagered');click(a,'[data-action=cityDo][data-kind=deal]');wait(a,f'GameDebug.state.cityLife.casino.wagered>{old}')
   if ev(a,"return GameDebug.state.cityLife.casino.blackjack.status==='playing'"):break
  ck(a,'Browser receives hidden hole card and no undealt server shoe',"const h=GameDebug.state.cityLife.casino.blackjack;return h.status==='playing'&&h.deck===undefined&&h.dealer[1]===null&&document.querySelectorAll('.playing-card.back').length===1")
  op(b,'blackjack',-208,145);click(b,'[data-action=cityDo][data-kind=hit]');wait(b,"document.getElementById('toastArea').textContent.includes('Only the seated player')");ck(b,'Partner UI cannot play host hand',"return GameDebug.state.cityLife.casino.blackjack.status==='playing'")
  click(a,'[data-action=cityDo][data-kind=stand]');wait(a,"GameDebug.state.cityLife.casino.blackjack.status==='settled'");wait(b,"GameDebug.state.cityLife.casino.blackjack.status==='settled'");ck(b,'Settled co-op hand reveals dealer without client exception',"return GameDebug.state.cityLife.casino.blackjack.dealer[1]!==null&&GameDebug.renderer.gl.getError()===0")
  op(a,'partsGarage',-158,156);click(a,'[data-action=cityDo][data-kind=part][data-slot=hood]');wait(a,'!GameDebug.state.cityLife.garage.hatchback.parts.hood');wait(b,'!!GameDebug.state.cityLife.garage.hatchback&&!GameDebug.state.cityLife.garage.hatchback.parts.hood');ck(b,'Removed car panel is shared across browsers','return !GameDebug.state.cityLife.garage.hatchback.parts.hood')
  op(b,'partsGarage',-158,156);click(b,'[data-action=cityDo][data-kind=engine][data-id=none]');wait(a,'GameDebug.state.cityLife.garage.hatchback.engine===null');ck(a,'Engine removal changes host drive readiness',"return MZNightlife.missing(GameDebug.state,'hatchback').includes('engine')");click(b,'[data-action=cityDo][data-kind=engine][data-id=stock]');wait(a,"GameDebug.state.cityLife.garage.hatchback.engine==='stock'");ck(a,'Partner refits retained engine free',"return MZNightlife.missing(GameDebug.state,'hatchback').length===0")
  op(b,'leafShop',-250,152);b.fill('#v11Qty-joint','2');click(b,'[data-action=cityDo][data-kind=buyGoods][data-id=joint]');wait(a,'GameDebug.state.cityLife.inventory.joint===2');ck(a,'Shop inventory synchronises to both players','return GameDebug.state.cityLife.inventory.joint===2')
  op(b,'casinoBar',-204,132);click(b,'[data-action=cityDo][data-kind=drink][data-id=water]');wait(b,'GameDebug.panel===null');ck(b,'Only purchasing player receives drink animation','return GameDebug.world.drinkUntil>GameDebug.realTime');ck(a,'Other player does not animate a drink they did not order','return !(GameDebug.world.drinkUntil>GameDebug.realTime)')
  ev(a,"GameDebug.close();GameDebug.open('coop')");click(a,'[data-action=coopLeave]');wait(a,'!GameDebug.coop.active');ck(a,'Leaving room returns unchanged solo bank and cash','return GameDebug.state.cash===2500&&GameDebug.state.enterprise.bank.current===0&&!GameDebug.state.rides.owned.hatchback')
  ck(b,'Partner remains with shared financed business and modified car','return GameDebug.coop.active&&GameDebug.state.cityLife.career.loan.outstanding===756&&!GameDebug.state.cityLife.garage.hatchback.parts.hood')
  ck(b,'Co-op mobile renderer remains valid','return GameDebug.renderer.gl.getError()===0');browser.close()
except Exception:checks.append(dict(name='Integration completed',passed=False,detail=traceback.format_exc()));print(traceback.format_exc(),flush=True)
finally:
 if server:server.terminate();server.wait(timeout=8)
 shutil.rmtree(directory,ignore_errors=True);checks.append(dict(name='No uncaught JavaScript exceptions',passed=not errors,detail=errors))
 report=dict(build_sha256=hashlib.sha256(HTML.encode()).hexdigest(),method='Two headed Chromium contexts (desktop and touch-emulated). Shipping client and real local HTTP server through test-only Fetch bridge. Actual UI transactions; fixture travel, real review timer.',checks=checks,passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks));(O/'v11-coop-browser-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:report[k] for k in ['passed','failed']}),flush=True)
 if report['failed']:raise SystemExit(1)
