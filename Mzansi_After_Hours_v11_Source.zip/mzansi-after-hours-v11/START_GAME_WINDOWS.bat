@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo This launcher needs Node.js installed. See README.md.
  pause
  exit /b 1
)
node tools/server.mjs --open
pause
