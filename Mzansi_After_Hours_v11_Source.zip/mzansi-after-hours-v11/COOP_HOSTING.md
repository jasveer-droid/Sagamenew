# Co-op setup and hosting - v11

## Two devices on one trusted Wi-Fi

1. Extract the source ZIP on your computer, with Node.js 18+ installed.
2. Stop any old game server. From this project folder run `npm run coop`, or use
   `START_COOP_WINDOWS.bat` on Windows.
3. Open the printed **Phone** address on both devices. On the computer you may
   use its Desktop address; both point at this one server. Allow the server only
   on your trusted private network if your firewall asks.
4. Open **Play with a friend**. Create a room with your name and an optional
   password. Share the six-character code and password privately with your friend.
5. Your friend uses **Join room** on that same server. Close the room panel to
   move around. Phone -> Contacts selects customers; Map locates shops.
6. Leave the server running. Closing its terminal disconnects everyone.

You do not have to press Start on a new solo game before joining a room.
A separate R5,000 Free Roam business starts in the room. Both players can work on
production, growing, purchases and sales; they do not share personal health.

## Different Wi-Fi networks / remote friends

A room code is not a relay service. Deploy the included project as a Node web
service that both devices can reach. Requirements:

- Start command: `node tools/server.mjs --lan --coop`.
- Set the platform `PORT` environment variable as needed. The server binds to
  all interfaces only with `--lan`.
- Provide an HTTPS URL using the host's reverse proxy. Keep same-origin requests
  and forward the original Host header; no cross-origin API access is enabled.
- Attach persistent private storage and set `MZ_COOP_DIR` to that mount path.
- Keep one instance for these file-backed rooms. Multiple independent replicas
  do not share memory or command order; a database/room router would be required.
- Back up the room file privately. It contains session credentials; never put it
  in the public assets folder or source-control history.

An example Dockerfile is included, but no hosting account or public URL has been
configured. Use a private/trusted-friend deployment initially. The server has
small request limits and hashed room passwords, not a full public abuse defence.

## Reconnect and update

After an accidental reload, open Play with a friend -> Rejoin remembered room
in the same browser. The reconnect token is separate from your solo save backup.
An unfinished paid meal is refunded on reconnect/leave rather than charging twice.
If a request was interrupted after the server processed it, the client resends
its sequence number and the server returns the same receipt.

When updating, stop the server, replace source files, retain `.private` (or your
MZ_COOP_DIR volume), then restart. Both players should reload the new client.
Do not run mixed old/new versions against the same active room.

The host leaving the room does not close the server. The remaining partner can
continue. Both member slots remain assigned across accidental disconnections;
use Leave room deliberately before changing browsers or inviting someone else.

## What a room shares

Shared: cash, business reputation, recipe inputs, finished products, growing
slots, production jobs, property/upgrades, runner stock, customer cooldowns,
orders, ride unlocks and server business history.

Personal: health, first-aid count, movement, camera, seating, meal animation,
local police encounters. Visible partner avatars and rides are transmitted,
interpolated, and shown on the map. No voice/chat, PvP, ride passengers or
server-authoritative movement enforcement is included. This is cooperative
business gameplay with a common server ledger, not a full multiplayer physics
simulation of every traffic/NPC agent.

## Living Streets additions

Outdoor collections, route progress, court scores and rewards are part of the shared
server save. Crowd behaviours/injuries remain local per browser; this is not one
authoritative crowd simulation. Copy or retain the configured private room-storage
directory when updating an existing server; stop the old process first. Never place
private room storage under a public static root.

## Everyday Life additions

The two players share one current account, one savings account, the company
portfolio, tills, stock, staffing, bank statement and job progress. A room can
have one active work ticket at a time; either member may do the next task at its
actual workplace. Both players may independently travel while staff serve
customers at open stocked businesses. Personal health and movement are unchanged.

A room account is a joint game account, not separate real banking identities.
There are no real payments, interest, loans or external account connections.
The same authoritative room ledger validates money and stock changes; private
room persistence must be retained during upgrades. Never upload `.private` or
your MZ_COOP_DIR data with publicly downloadable source code.

## Roadcraft update

All ten car IDs are shared purchase unlocks. Dents are per-player state, not
a shared deforming crowd/vehicle solver. The R180 repair is a sequenced shared
wallet command; its personal receipt clears the requesting driver's bodywork.
Both clients must use the same v10 server/assets. Preserve your private room
storage separately from solo JSON backups before replacing the project.

## City Choices shared systems (v11)

Bank applications, reviewed approvals, restricted finance, loan repayments,
casino balances/history, collected shop quantities and owned-car configurations
are part of the server-controlled shared business. Both people can work on a
bank application or modify an owned car. Do not update a room while clients are
still connected with an older version.

Casino outcomes are selected on the server. Requests use the existing ordered
sequence receipts, so retrying a completed request cannot redraw or pay twice.
A shared live blackjack hand belongs to the member who dealt it; only that member
may act. The server redacts the undealt shoe and dealer hole card from responses.
Accidental disconnection keeps the hand available on reconnect. Explicitly
leaving automatically stands any remaining hands and settles before releasing
the member slot, avoiding a permanently blocked shared table.

The drink purchaser alone sees the cup animation. Car part selections are shared,
but driving dynamics and collision damage remain personal. The solo developer
cost waiver is disabled in a room; the gameplay code is not a server credential.
The normal startup career greeting is a solo flow; a room starts in Free Roam.

The co-op tests use two real browser contexts and a real local HTTP room server,
connected by a test-only bridge because native browser URL navigation was blocked
here. This does not certify remote Internet hosting or a Samsung phone on Wi-Fi.
