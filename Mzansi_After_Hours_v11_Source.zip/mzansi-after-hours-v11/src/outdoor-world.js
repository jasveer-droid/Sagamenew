'use strict';
/** Original south-side extension. Geometry is batched; small moving props are culled. */
(function(root){
 root.MZOutdoorWorld={build(a){
  const {world:w,renderer:r,box,col,sign,point,tree,bench,building,person,rnd}=a,G=MZ.Geometry;
  box(0,-.10,121,248,.27,138,0x9da98a);
  const roads=[{x:0,z:72,w:248,d:12,name:'Nelson Crescent'},{x:0,z:160,w:248,d:12,name:'Harbour Road'},{x:18,z:121,w:12,d:134,name:'Ubuntu Avenue South'},{x:-76,z:116,w:10,d:88,name:'Riverside Lane'},{x:76,z:116,w:10,d:88,name:'Foundry Lane'}];
  for(const road of roads){w.roads.push(road);const {x,z,w:width,d}=road,horizontal=width>d;box(x,.008,z,width,.11,d,0x536168);for(const side of [-1,1]){if(horizontal){box(x,.095,z+side*(d/2+1.6),width,.24,3.1,0xc4c5ac);box(x,.17,z+side*(d/2+.06),width,.18,.12,0xe1d4b5);}else{box(x+side*(width/2+1.6),.095,z,3.1,.24,d,0xc4c5ac);box(x+side*(width/2+.06),.17,z,.12,.18,d,0xe1d4b5);}}
   const len=horizontal?width:d;for(let v=-len/2+3;v<len/2;v+=6){const xx=x+(horizontal?v:0),zz=z+(horizontal?0:v);if(horizontal&&[18,-76,76].some(n=>Math.abs(xx-n)<8))continue;if(!horizontal&&[72,160].some(n=>Math.abs(zz-n)<8))continue;box(xx,.077,zz,horizontal?2.7:.12,.015,horizontal?.12:2.7,0xe2dabc);}
  }
  // Land and a protected coastline. Open links at x18 and both outer avenues.
  box(0,.65,191,250,1.3,.45,0x8c9b8b);box(-125,.65,123,.45,1.3,136,0x8c9b8b);
  box(162,.03,144,74,.08,144,0x538e97);for(let z=79;z<210;z+=7)box(156,.076,z,62,.015,.07,0x8dbab7);
  for(let z=58;z<190;z+=4){box(124,.8,z,.13,1.6,.13,0x8daba0);box(124,1.4,z+2,.12,.1,4,0xc7c9ad);}
  // Park paths, pond, planting beds and shaded places to pause.
  box(-35,.085,116,63,.17,67,0x86a47a);box(-34,.182,134,62,.026,3.2,0xcab796);box(-9,.182,111,3.2,.026,58,0xcab796);
  box(-34,.24,111,33,.34,23,0xbdb693);box(-34,.425,111,30,.03,20,0x669c9d);col(-34,111,32,22);
  for(let i=0;i<18;i++){const x=-47+i*1.5;box(x,.46,102,.75,.022,.05,0xa6ccbc);}
  for(const [x,z] of [[-60,88],[-58,109],[-56,142],[-12,140],[-8,91],[-25,146],[-46,126]]){tree(x,z,.92,true);}
  for(const [x,z] of [[-50,135],[-40,141],[-5,122],[-60,97]])bench(x,z);
  for(let i=0;i<24;i++){const x=-53+(i%12)*3.1,z=88+Math.floor(i/12)*3;box(x,.34,z,2.5,.4,2,0x906f51);const flower=new G();for(let k=0;k<3;k++){flower.cylinder(x-.65+k*.6,.8,z,.04,.04,.8,0x5e8a62,6);flower.sphere(x-.65+k*.6,1.19,z,.19,.14,.19,[0xe8c166,0xc78bba,0xebaa8e][i%3],4,6);}box(x,.57,z,2.35,.04,1.85,0x617249);w.outdoorFlowerGeos??=[];w.outdoorFlowerGeos.push(flower);}
  // Court: visible boundaries, two hoops, original no-stakes skill activity.
  box(-103,.1,109,31,.2,38,0x8d8970);box(-103,.214,109,27,.025,33,0x668c82);
  for(const x of [-116,-90])box(x,.233,109,.10,.02,32,0xe9e2c6);for(const z of [93,125,109])box(-103,.233,z,26,.02,.10,0xe9e2c6);
  const hoops=new G();for(const z of [93,125]){box(-106,1.9,z,.14,3.8,.14,0x45625e);col(-106,z,.3,.3);box(-106,3.6,z,2.6,1.5,.12,0xe6d8b4);const front=z===93?1:-1;for(let i=0;i<18;i++){const q=i*Math.PI/9;hoops.sphere(-106+Math.cos(q)*.43,3.08,z+front*.72+Math.sin(q)*.43,.07,.055,.07,0xdcaa62,3,5);}for(let i=0;i<8;i++){const q=i*Math.PI/4;hoops.cylinder(-106+Math.cos(q)*.34,2.85,z+front*.72+Math.sin(q)*.34,.018,.018,.43,0xe4ddc4,5);}}
  w.hoopsMesh=r.mesh(hoops);sign('UBUNTU COURT','TAKE A SHOT / EVERYONE WELCOME',-102,2.9,128,10,1.2,'#325a56','#f6ddb0',0,true);
  // Sheltered recycling counter with containers that match the collection game.
  building(-109,138,18,11,4.7,0xb0b995,'RIVERSIDE RECYCLING','SIX BOTTLES / A CLEANER NEIGHBOURHOOD');
  for(let i=0;i<3;i++){box(-116+i*4,.82,149,2,1.65,1.5,[0x709889,0x7a99a6,0xd2aa62][i]);col(-116+i*4,149,2,1.5);}
  // A mural courtyard and working parcel depot, with wide driving approaches.
  box(-106,.10,176,30,.2,22,0xb8a184);box(-106,2.9,185,32,5.8,.4,0x658787);col(-106,185,32,.4);
  for(let i=0;i<10;i++){box(-119+i*2.9,1.8+(i%3)*.45,184.76,2.2,2.4+(i%2),.04,[0xe0b776,0xbc8694,0x8cb59b,0x8da6bb][i%4]);}
  sign('TOGETHER IN COLOUR','SUNDOWN COMMUNITY MURAL',-107,4.9,184.71,26,1.0,'#385f63','#f3d6a7',Math.PI,true);
  building(47,92,25,18,6.1,0xb49b7b,'HARBOUR PARCEL DEPOT','PICK UP / DELIVER / EARN');
  for(let i=0;i<7;i++){box(37+i*3,.44,104,.95,.9,.85,0xb18b5f);col(37+i*3,104,.95,.85);}
  building(103,102,24,20,6.5,0x83a0a0,'FOUNDRY WORKSHOP','HARBOUR WORKS / LOCAL MAKERS');
  box(47,.13,132,36,.24,29,0x909b8d);for(let i=0;i<4;i++){box(33+i*10,.27,134,.09,.018,20,0xe3d8b6);}
  building(40,178,27,17,6,0xb39b91,'SOUTH BAY STUDIOS','ART / MUSIC / NEIGHBOURS');
  building(-20,180,29,14,5,0x9fac93,'RIVERSIDE COMMUNITY ROOMS','FIND YOUR PEOPLE');
  for(let i=0;i<3;i++){const x=91+i*10,z=132+(i%2)*10;box(x,1.5,z,8,3,7,[0xa96f59,0x6c9094,0xc3ab67][i]);col(x,z,8,7);for(let k=-3;k<=3;k++)box(x+k,1.5,z+3.53,.06,2.9,.06,0x405d5b);}
  // Harbour crane, public lookout deck and telescopes beyond the work yard.
  const crane=new G();for(const x of [94,103])for(const z of [169,179])crane.box(x,5,z,.45,10,.45,0xc4a265);crane.box(99,10.2,175,20,.7,1.1,0xc8aa68);crane.cylinder(106,6.5,175,.05,.05,7,0x4c5e58,7);crane.box(106,3.05,175,.8,.25,.5,0x6c7870);w.craneMesh=r.mesh(crane);col(94,169,.6,.6);col(103,169,.6,.6);col(94,179,.6,.6);col(103,179,.6,.6);
  box(117,.12,177,11,.23,21,0xc2b396);bench(119,171);bench(119,185);
  for(const x of [-118,-84,-67,4,30,68,83,118])for(const z of [82,154,187]){box(x,2.4,z,.12,4.8,.12,0x4a655e);box(x,4.85,z,.8,.18,.6,0xf4d499);}
  // A small play area and wind-driven public-art sculpture.
  for(const x of [-57,-49]){box(x,2.1,170,.16,4.2,.16,0x678783);col(x,170,.3,.3);}box(-53,4.25,170,8.4,.16,.16,0x678783);w.swing={x:-53,z:170};
  for(const p of MZActivities.points){const type=MZActivities.LITTER.some(q=>q.id===p.id)?'litter':MZActivities.POSTS.some(q=>q.id===p.id)?'viewpoint':MZActivities.ROUTE.some(q=>q.id===p.id)?'parcel':'activity';point(p.id,type,p.name,p.x,p.z,'EXPLORE SUNDOWN SOUTH');}
  point('commonsTaxi','taxi','Riverside taxi stop',10,76,'LOCAL TAXIS / R20');point('harbourTaxi','taxi','Harbour taxi stop',82,156,'LOCAL TAXIS / R20');
  sign('RIVERSIDE COMMONS','PARK / COURT / COMMUNITY',-9,3.1,84,14,1.5,'#3d6559','#f4dbab',Math.PI,true);
  sign('HARBOUR WORKS','PARCEL DEPOT / LOOKOUT',54,3.4,83,14,1.5,'#365b68','#f3d6a4',Math.PI,true);
  for(const q of MZActivities.POSTS){box(q.x,1,q.z,.14,2,.14,0x5a7871);sign('POSTCARD STOP','EXPLORE ALL THREE',q.x,1.9,q.z,2.4,.65,'#446e67','#f6d69f',0,true);}
  const extraModels=[person(0x93694d,0xc6a36c,0x40595c,false,'newcomer'),person(0xc79876,0x7299a1,0x465965,true,'newcomer'),person(0x6c513e,0xa391af,0x4f645c,false,'lerato'),person(0xbb8f6c,0x8aa179,0x48585c,false,'newcomer')];
  for(let i=0;i<8;i++){const n=MZNeighbourhood.customers.find(n=>n.district===(i<4?'commons':'harbour')&&n.localIndex===i%4);if(n)w.customers.push({...n,homeX:n.x,homeZ:n.z,ry:Math.PI*.3,kind:'CUSTOMER',type:'customer',model:extraModels[i%4],phase:rnd()*6,walk:false,cooldown:0});}
  for(let i=0;i<8;i++){const path=i<4?[[-65,80],[-65,126],[-58,134],[-10,134],[-10,82]]:[[29,80],[66,80],[68,115],[68,152],[28,152]];w.pedestrians.push({name:['Jabu','Lindi','Amir','Palesa','Sean','Noma','Lee','Dineo'][i],x:path[0][0]+i%3,z:path[0][1]+i*1.5,ry:0,model:extraModels[i%4],phase:rnd()*6,path,index:1,speed:.8+(i%3)*.17});}
  for(const [i,path] of [[[18,66],[18,155],[65,155],[65,78]], [[-76,82],[-76,153],[-16,153],[-16,78]]].entries())w.police.push({id:'southPatrol'+i,x:path[0][0],z:path[0][1],ry:0,phase:i,model:w.police[i].model,path,index:1,speed:1.5,chase:false});
  w.cars.push({x:26,z:69,ry:Math.PI/2,speed:4.2},{x:-70,z:163,ry:-Math.PI/2,speed:-4.1});
 },install(r,w){
  const G=MZ.Geometry,M=MZ.M;const ball=new G();ball.sphere(0,0,0,.23,.23,.23,0xcd925c,8,12);for(let i=0;i<12;i++){const q=i*Math.PI/6;ball.sphere(Math.cos(q)*.228,Math.sin(q)*.228,0,.017,.017,.024,0x574539,3,5);}const bm=r.mesh(ball);
  const bottle=new G();bottle.cylinder(0,.22,0,.13,.13,.38,0x88c2b0,8);bottle.cylinder(0,.45,0,.055,.1,.12,0x88c2b0,8);bottle.cylinder(0,.53,0,.058,.058,.07,0xe4d4a0,8);const bottles=r.mesh(bottle);
  const flowerMeshes=(w.outdoorFlowerGeos||[]).map(g=>r.mesh(g));delete w.outdoorFlowerGeos;
  const swing=new G();swing.beam([-.95,0,0],[-.95,-2.45,0],.025,0xd2cdad,5);swing.beam([.95,0,0],[.95,-2.45,0],.025,0xd2cdad,5);swing.box(0,-2.47,0,2.3,.15,.75,0xb08c5e);const sm=r.mesh(swing);
  const old=w.render;w.render=(s,t)=>{old(s,t);r.gl.useProgram(r.cp);r.draw(w.hoopsMesh);r.draw(w.craneMesh);for(const m of flowerMeshes)r.draw(m);
   for(const p of MZActivities.LITTER)if(!s.outdoors?.litter.includes(p.id))r.draw(bottles,M.model(p.x,.18,p.z,p.x));
   const pose=MZPeople.matrix(w.swing.x,4.18,w.swing.z,0,Math.sin(t*.65)*.16);r.draw(sm,pose);
   let pos={x:-107,y:.48,z:109};if(w.shot){const q=w.shot,elapsed=Math.min(1,(t-q.start)/1.4);pos={x:q.x+(q.goalX-q.x)*elapsed,y:1.4+(3.2-1.4)*elapsed+Math.sin(elapsed*Math.PI)*3,z:q.z+(q.goalZ-q.z)*elapsed};if(t-q.start>1.5)w.shot=null;}r.draw(bm,M.model(pos.x,pos.y,pos.z,t));
  };
 }};
})(window);
