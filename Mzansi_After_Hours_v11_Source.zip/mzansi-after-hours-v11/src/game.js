'use strict';
/* Mzansi After Hours. Original portable single-player game, version 11.0.0. All products are fictional. */
(() => {
    const $ = id => document.getElementById(id), clamp = (n, a, b) => Math.max(a, Math.min(b, n));
    const money = n => 'R ' + Math.round(n).toLocaleString('en-ZA');
    const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const VERSION = 11;
    const isFreeMode = () => MZNeighbourhood.isFree(state);
    const touchDetected = () => MZGuide.detectInput() === 'touch';
    const { SUPPLIES, RECIPES, UPGRADES } = MZData;
    let renderer, world, state, started = false, locked = false, keys = {}, panel = null, panelCtx = null, phoneTab = 'home', paused = false, lastTime = 0, realTime = 0, nearest = null, refreshQueued = false, drag = null, storageWarning = false, audio = null, lastSave = 0, lastHUD = 0, lastMap = 0, lastToast = 0, oldQuest = -1, lookBounce = 0;
    const canvas = $('world');
    let touch = null, lastBackup = 0, recoveredSave = false, contextLost = false, pendingImport = null, lastFocus = null, lastRender = 0, frameHandle = 0;
    const diagnostics = [];
    let lessonPage = 0, journalIndex = null, titleMode = null, titlePlayMode = null, contactDistrict = 'all';
    const noticeLog = [];
    let bankTab='overview',bizFilter='all';
    const cityUi={stake:20,betType:'red',pick:0,business:'coffee',car:null};
    let cityPreviewCache={key:'',image:''};
    let device = null, saveConflict = false, injuryFee = 0, rideMotion = MZMobility.motion();
    try { device = MZDevice.create(localStorage); }
    catch (_) { device = MZDevice.create({getItem:()=>null,setItem:()=>{throw new Error('Storage blocked');}}); }
    // v6 live-only state: never store authentication codes or active physics in saves.
    let devUnlocked=false,devFlags={unlimitedMoney:false,godMode:false,noPolice:false},devAttempts=0,devWaitUntil=0;
    let fall=null,pendingTrafficLesson=false,seatedReturn=null,craftingDraft=null,growVariety='classic',historyCategory='all';
    let remoteStats=null,statsError='',launchSettings=null,serverAdminToken='',lastPoliceNotice=-100;
    // v7: local physical state never goes into a money save or a room password.
    let jumpState=MZTravel.jumpState(),handbrake=false,atlasZoom=null,atlasLayer='all',atlasQuery='',soloState=null,lastTeamRevision=-1,lastCrew='';
    let carCamera=MZCamera.create(),hornUntil=-100,lastNpcNotice=-100,lastShot=-100;
    const coop=MZCoop.create({
        pose:()=>({x:state.player.x,z:state.player.z,yaw:state.rides.riding?rideMotion.heading:state.player.yaw,height:jumpState.height,ride:state.rides.riding?state.rides.equipped:null,speed:rideMotion.speed,walk:(world.lastPlayerSpeed||0)>.2,seat:state.life.seat,eating:!!state.life.meal,health:state.health}),
        personal:()=>state?{player:state.player,health:state.health,medkits:state.medkits,equipped:state.rides.equipped,vehicleDamage:state.rides.damage}:null,
        enter:(data,personal)=>{
            soloState=JSON.parse(JSON.stringify(state));
            if(!started)startGame(false);
            release();stopSeating(true);const settings={...state.settings};state=initial();state.settings=settings;state.mode='free';state.freeGuideSeen=true;state.track=null;state.dev={unlimitedMoney:false,godMode:false,noPolice:false};devUnlocked=false;devFlags=state.dev;
            const me=data.members.find(m=>m.id===data.you);Object.assign(state.player,me?.pose||{x:-32,z:10,yaw:Math.PI});
            if(personal){if(personal.player&&world.isFree(personal.player.x,personal.player.z,state))Object.assign(state.player,personal.player);state.health=clamp(Number(personal.health)||100,1,100);state.medkits=clamp(Math.floor(personal.medkits||0),0,99);if(MZMobility.RIDES[personal.equipped])state.rides.equipped=personal.equipped;for(const id of Object.keys(state.rides.owned))if(personal.vehicleDamage?.[id])state.rides.damage[id]=MZVehicle.clean(personal.vehicleDamage[id]);}
            jumpState=MZTravel.jumpState();fall=null;state.damageUntil=(data.team.sim||0)+4;lastTeamRevision=-1;applySettings();closePanel(false,true);updatePlayModeLabel();toast('Co-op room '+data.code+' / your solo save is kept separately.');
        },
        snapshot:data=>{
            for(const k of ['cash','rep','sim','clock','day','inv','products','plants','jobs','jobSeq','upgrades','workshop','runner','runnerActive','reserveOrders','runnerTick','orders','orderSeq','nextOrder','totalRevenue','stats','cooldowns','outdoors','enterprise','cityLife'])state[k]=data.team[k];
            state.rides.owned=data.team.owned;state.rides.helmet=data.team.helmet;state.life.history=data.team.history;state.life.historySeq=Math.max(0,...state.life.history.map(e=>e.id));applyCooldowns();
            world.partner=data.members.find(m=>m.id!==data.you&&m.online)||null;
            const crew=JSON.stringify([data.code,data.members.map(m=>[m.id,m.name,m.online])]);if(panel==='coop'&&(data.revision!==lastTeamRevision||crew!==lastCrew))refreshQueued=true;lastCrew=crew;
            if(data.revision!==lastTeamRevision&&['bench','grow','inventory','runner','garage','upgrades','carShop','rideShop','phone','restaurant','activities','activity','viewpoint','litter','parcel','bank','business','businesses','careers','workstation','casino','roulette','slots','blackjack','casinoBar','casinoHistory','bankApplications','partsGarage','leafShop','retailBag'].includes(panel)&&!['INPUT','SELECT'].includes(document.activeElement?.tagName))refreshQueued=true;
            lastTeamRevision=data.revision;updateHUD();
        },
        receipt:(r,a)=>{
            if(!r.ok){toast(r.text,true);if(panel)refresh();return;}
            const p=r.personal||{};
            if(p.equipped){stopRide(true);state.rides.equipped=p.equipped;}
            if(p.repaired){state.rides.damage[p.repaired]=MZVehicle.clean(null);if(world.vehicleShells?.[p.repaired])deleteVehicleShell(p.repaired);}
            if(p.medkit)state.medkits=Math.min(99,state.medkits+p.medkit);
            if(p.heal)state.health=Math.min(100,state.health+p.heal);
            if(p.deal){state.lastSale=state.sim;state.heat=Math.min(100,state.heat+8);MZPolice.witness?.(world,state);}
            if(p.meal){state.life.meal={id:p.meal,remaining:MZLife.MEALS[p.meal].seconds,paid:0};}
            if(p.taxi){stopRide(true);stopSeating(false);jumpState=MZTravel.jumpState();[state.player.x,state.player.z,state.player.yaw]=p.taxi;}
            if(a.type==='refundMeal')stopSeating(false);
            if(a.type==='penalty'){state.heat=0;state.caughtUntil=state.sim+20;MZPolice.reset(world);if(a.arrest){stopRide(true);stopSeating(false);Object.assign(state.player,world.homeSpawn);}}
            if(['sell','deliver','food','orderMeal','ride','sleep','refundMeal','penalty'].includes(a.type))closePanel(false,true);else if(panel)refresh();
            if(a.type==='outdoor'){routeActivity(a.kind);closePanel(false,true);}
            if(a.type==='city')cityReceipt(r.city||r,a);
            if(a.type==='commerce')commerceReceipt(r.commerce||r,a);
            if(a.type!=='finishMeal')toast(r.text);sound('ready');updateHUD();
        },
        connection:(message,n)=>{if(n===1||n===3)toast(message,true);if(n>=3){stopRide();keys={};touch?.clear();}if($('coopFeedback'))$('coopFeedback').textContent=message;},
        leave:()=>{release();world.partner=null;world.partnerSmooth=null;state=validSave(soloState||initial());soloState=null;jumpState=MZTravel.jumpState();fall=null;applyCooldowns();applySettings();closePanel(false,true);updatePlayModeLabel();save();toast('Returned to your unchanged solo business.');}
    });



    function cityPreview(){
        const id=world.garagePreviewId,el=$('v11CarPreview');if(!el||!id||!world.rideMeshes[id])return;
        const key=id+JSON.stringify(MZNightlife.carConfig(state,id));
        try{if(cityPreviewCache.key!==key){const mesh=world.rideMeshes[id],filtered={...mesh,parts:mesh.parts.filter(p=>MZNightlife.visible(state,id,p))};cityPreviewCache={key,image:MZRideWorld.preview(renderer,filtered,id)};}el.src=cityPreviewCache.image;}catch(e){diagnostics.push({message:'Garage preview: '+e.message});}finally{renderer.resize();}
    }
    function cityReceipt(r,a){
        if(a.kind==='career'){
            state.mode='free';state.freeGuideSeen=true;titlePlayMode='free';updatePlayModeLabel();
            state.track=a.path==='business'?'communityBank':a.path==='work'?'careerCentre':null;
            if(a.path==='work')openPanel('careers');else if(a.path==='business')openPanel('bankApplications');else closePanel(false,true);
        }else if(r.personal?.drink){world.drinkUntil=realTime+4;closePanel(false,true);}
        else if(panel)refresh();
        updateHUD();
    }
    function cityAction(name,data){
        const pages=['careerChoice','bankApplications','casino','roulette','blackjack','slots','casinoBar','casinoHistory','partsGarage','leafShop','retailBag'];
        if(name==='cityOpen'){
            if(!started||!pages.includes(data.page))return true;
            if(data.page==='bankApplications'&&Object.hasOwn(MZCommerceData.byId,data.id))cityUi.business=data.id;
            openPanel(data.page);return true;
        }
        if(name==='cityContinue'){state.cityLife.career.seen=true;closePanel(false,true);save();maybeBrief();return true;}
        if(name==='cityStory'){state.story.seen=-1;state.cityLife.career.seen=true;state.cityLife.career.path='explore';MZNeighbourhood.setMode(state,'story');titlePlayMode='story';updatePlayModeLabel();closePanel(false,true);save();maybeBrief();return true;}
        if(name==='cityNumber'){cityUi.betType='straight';cityUi.pick=Number(data.id);refresh();return true;}
        if(name==='cityChip'){const v=Number(data.amount);if([10,20,50,100,500].includes(v)){cityUi.stake=v;if($('v11Stake'))$('v11Stake').value=v;}return true;}
        if(name!=='cityDo')return false;
        if(!started||!pages.includes(panel))return true;
        const allowed={career:['careerChoice'],apply:['bankApplications'],repay:['bankApplications'],budget:['casino'],roulette:['roulette'],slots:['slots'],deal:['blackjack'],hit:['blackjack'],stand:['blackjack'],double:['blackjack'],split:['blackjack'],drink:['casinoBar'],buyGoods:['leafShop'],engine:['partsGarage'],component:['partsGarage'],part:['partsGarage'],wheel:['partsGarage'],restore:['partsGarage']};
        if(!allowed[data.kind]?.includes(panel))return true;
        const a={type:'city',kind:data.kind,path:data.path,id:data.id==='none'?null:data.id,car:data.car,slot:data.slot,index:Number(data.index),install:data.install==='true'};
        if(['roulette','slots','deal'].includes(a.kind)){a.amount=Number($('v11Stake')?.value);cityUi.stake=a.amount;}
        if(a.kind==='roulette'){a.betType=$('v11BetType').value;a.pick=Number($('v11Pick').value);cityUi.betType=a.betType;cityUi.pick=a.pick;}
        if(a.kind==='apply'){a.business=$('v11Business').value;a.contribution=Number($('v11Contribution').value);a.plan=$('v11Plan').value;cityUi.business=a.business;}
        if(a.kind==='repay')a.amount=Number($('v11Repay').value);
        if(a.kind==='budget')a.amount=Number($('v11Budget').value);
        if(a.kind==='buyGoods')a.qty=Number($('v11Qty-'+a.id).value)*(a.id==='flower'?2:1);
        if(coop.active){coop.send(a);return true;}
        const result=MZNightlife.perform(state,{...state.player,ride:state.rides.riding?state.rides.equipped:null},a);
        if(result.ok){cityReceipt(result,a);save();sound('ready');}else sound();
        toast(result.text,!result.ok);return true;
    }

    function commerceReceipt(result,a){
        const id=a.id||state.enterprise.work?.biz;
        if(['startShift','startService'].includes(a.kind)){state.track=MZCommerceData.byId[a.id].point.id;openPanel('workstation');}
        else if(a.kind==='buy')openPanel('business',{businessId:a.id});
        else if(a.kind==='finishTask'&&result.finished)openPanel('business',{businessId:id});
        else if(a.kind==='cancelWork')openPanel('careers');
        else if(panel)refresh();
        updateHUD();
    }
    function commerceAction(name,data){
        if(name==='commercePage'){
            const page=data.page;
            if(!['bank','businesses','careers','business','businessConfirm','workstation','commerceGuide'].includes(page))return true;
            if(!started&&page!=='commerceGuide')return true;
            if(['business','businessConfirm'].includes(page)&&!MZCommerceData.byId[data.id])return true;
            if(panel==='phone'&&['bank','businesses','careers'].includes(page)){phoneTab=page;refresh();}
            else openPanel(page,{businessId:data.id});
            return true;
        }
        if(name==='bankTab'){
            if(!['overview','move','bills','statement'].includes(data.id))return true;
            bankTab=data.id;refresh();return true;
        }
        if(name==='exportBank'){
            if(!started)return true;downloadJSON({game:'Mzansi After Hours',scope:coop.active?'shared team game account':'solo game account',version:11,exported:new Date().toISOString(),bank:state.enterprise.bank},'mzansi-game-bank-statement.json');return true;
        }
        if(name!=='commerceDo')return false;
        if(!started||!['bank','business','businessConfirm','careers','businesses','workstation','phone'].includes(panel))return true;
        const permitted={buy:['businessConfirm'],startShift:['business'],startService:['business'],beginTask:['workstation'],finishTask:['workstation'],cancelWork:['workstation'],stock:['business'],open:['business'],close:['business'],hire:['business'],upgrade:['business'],price:['business'],rename:['business'],collect:['business']};
        if(permitted[data.kind]&&!permitted[data.kind].includes(panel))return true;
        const a={type:'commerce',kind:data.kind,id:data.id||state.enterprise.work?.biz||'',choice:data.choice,work:Number(data.work),step:Number(data.step),token:Number(data.token),price:data.price};
        if(['deposit','withdraw','save','unsave','goal'].includes(a.kind)){
            const v=$('bankAmount')?.value?.trim()||'';
            if(!/^\d{1,10}$/.test(v)){const p=$('commerceFeedback');if(p)p.textContent='Enter a positive whole-rand amount, using digits only.';return true;}
            a.amount=Number(v);
        }else if(data.amount!==undefined)a.amount=Number(data.amount);
        if(a.kind==='buy')a.name=$('newBusinessName')?.value||'';
        if(a.kind==='rename')a.name=$('renameBusiness')?.value||'';
        if(coop.active){coop.send(a);return true;}
        const pose={...state.player,ride:state.rides.riding?state.rides.equipped:null};
        const result=MZCommerce.perform(state,pose,a);
        if(!result.ok){const p=$('commerceFeedback');if(p)p.textContent=result.text;toast(result.text,true);return true;}
        save();commerceReceipt(result,a);toast(result.text);sound('ready');return true;
    }

    function activeCar(){return state?.rides.riding&&MZMobility.RIDES[state.rides.equipped]?.car;}
    function routeActivity(kind){const a=state.outdoors;if(kind==='courierStart'||kind==='parcel')state.track=a.courierStep>=0?MZActivities.ROUTE[a.courierStep].id:'depot';if(kind==='pickup')state.track=a.litter.length===6?'recycling':MZActivities.LITTER.find(p=>!a.litter.includes(p.id))?.id||'recycling';}
    function resetCamera(){MZCamera.reset(carCamera);if(started)toast('Camera reset behind the car. Swipe or move the mouse to look around.');}
    function v8Action(name,data){
        if(['activities','cameraSettings'].includes(name)){openPanel(name);return true;}
        if(name==='cameraReset'){resetCamera();if(panel==='cameraSettings')closePanel(false);return true;}
        if(name==='cameraDistance'){state.settings.carCameraDistance=MZCamera.zoom(carCamera,Number(data.id));save();if(panel)refresh();return true;}
        if(name==='horn'){if(activeCar()){hornUntil=state.sim+1;sound('warn');if(panel==='cameraSettings')closePanel(false);}return true;}
        if(name==='outdoorDo'){
            if(!started||!['activity','viewpoint','litter','parcel'].includes(panel)||!MZActivities.near(state.player,data.id))return true;
            if(coop.active){coop.send({type:'outdoor',kind:data.kind,id:data.id});return true;}
            const result=MZActivities.perform(state,state.player,data.kind,data.id);if(result.ok){if(result.heal)state.health=Math.min(100,state.health+result.heal);routeActivity(data.kind);sound('ready');save();closePanel(false);}toast(result.text,!result.ok);updateHUD();return true;
        }
        if(name==='shoot'){
            if(panel!=='activity'||panelCtx?.id!=='court'||!MZActivities.near(state.player,'court')||state.rides.riding||realTime-lastShot<1.8)return true;
            lastShot=realTime;const score=MZActivities.shot(realTime);state.player.yaw=0;state.player.pitch=.08;
            world.shot={x:state.player.x,z:state.player.z,goalX:-106+(score.hit?0:1.2),goalZ:93.72,start:realTime,hit:score.hit};
            if(coop.active)coop.send({type:'basketScore',hit:score.hit});else{state.outdoors.shots++;if(score.hit)state.outdoors.hoops++;MZLife.log(state,'exploring',score.hit?'A basket at Ubuntu Court.':'Practised a shot at Ubuntu Court.');save();}
            closePanel(false);toast(score.hit?'Basket! Nice shot.':'Just wide. Try releasing inside the green zone.');return true;
        }
        if(name==='helpNpc'){
            if(panel!=='npcCare'||!panelCtx||Math.hypot(panelCtx.x-state.player.x,panelCtx.z-state.player.z)>4)return true;
            if(MZPeople.help(panelCtx,state,data.kit==='yes')){MZLife.log(state,'system','Checked on '+panelCtx.name+' after a collision');save();closePanel(false);toast('They will be back on their feet shortly.');}return true;
        }
        return false;
    }

    function jump(){if(!started||panel||paused||fall||state.life.seat||coop.stalled)return false;const ride=state.rides.riding?MZMobility.RIDES[state.rides.equipped]:null;const ok=MZTravel.jump(jumpState,ride);if(ok)sound();return ok;}
    function deleteVehicleShell(id){
        const rec=world.vehicleShells?.[id];if(rec){for(const p of rec.parts)if(p)renderer.gl.deleteBuffer(p.mesh.buffer);delete world.vehicleShells[id];}
    }
    function carCrash(impact,contact=null){
        if(impact<3||state.sim<state.damageUntil)return;
        const id=state.rides.equipped;
        if(MZMobility.RIDES[id]?.car){state.rides.damage??={};state.rides.damage[id]=MZVehicle.crush(state.rides.damage[id],impact,contact?.x||0,contact?.z??-1);}
        state.damageUntil=state.sim+2;rideMotion.impact=.65;const loss=state.dev.godMode?0:Math.min(state.health,Math.round(impact*1.4));state.health-=loss;
        toast('Collision / -'+loss+' health. Car condition '+MZVehicle.condition(state.rides.damage?.[id])+'%.',true);sound('warn');
        MZLife.log(state,'traffic','Vehicle collision / '+(MZMobility.RIDES[id]?.name||'car')+' / bodywork damaged');
        if(state.health<=0){stopRide(true);fall=MZLife.createFall(state,{speed:1,z:state.player.z+1});}save();
    }
    function vehicleAction(name,data){
        if(name==='drivingSetup'){openPanel(name);return true;}
        if(name==='driveSetting'){
            if(panel!=='drivingSetup')return true;
            const k=data.id==='wet'?'roadWet':data.id==='assist'?'stabilityAssist':null;if(!k)return true;
            state.settings[k]=!state.settings[k];save();refresh();return true;
        }
        if(name==='repairCar'){
            if(panel!=='drivingSetup'||Math.abs(rideMotion.speed)>.3)return true;
            const id=data.id;if(!MZMobility.RIDES[id]?.car||!state.rides.owned[id]||!MZVehicle.damaged(state.rides.damage?.[id]))return true;
            if(coop.active){coop.send({type:'repairCar',id});return true;}
            if(!MZLife.pay(state,MZVehicle.REPAIR_PRICE)){toast('You need R180 in pocket cash for roadside service.',true);return true;}
            state.rides.damage[id]=MZVehicle.clean(null);deleteVehicleShell(id);MZLife.log(state,'purchase','Roadside repair / '+MZMobility.RIDES[id].name,state.dev.unlimitedMoney?0:-180);save();refresh();toast('Bodywork repaired. Normal performance restored.');return true;
        }
        return false;
    }
    function v7Action(name,data){
        if(name==='coop'||name==='carShop'){openPanel(name);return true;}
        if(name==='atlasZoom'){atlasZoom=[1,1.5,2.5].includes(Number(data.id))?Number(data.id):1;refresh();return true;}
        if(name==='trackRoad'){const i=Number(String(data.id).replace('road',''));if(world.roads[i]){state.track='road'+i;closePanel(false);toast('Tracking '+world.roads[i].name);}return true;}
        if(['coopCreate','coopJoin','coopResume','coopLeave'].includes(name)){
            const feedback=$('coopFeedback');if(feedback)feedback.textContent='Connecting to your room server...';
            const task=name==='coopLeave'?coop.leave():coop.connect(name==='coopCreate'?'create':name==='coopJoin'?'join':'resume',{name:$('coopName')?.value||'Neighbour',password:$('coopPassword')?.value||'',code:$('coopCode')?.value?.trim().toUpperCase()});
            task.then(()=>{if(coop.active)openPanel('coop');}).catch(e=>{const el=$('coopFeedback');if(el)el.textContent=e.message;else toast(e.message,true);});return true;
        }
        if(!coop.active)return false;
        if(['devToggle','cheat','reset','setPlayMode','confirmImport','loadLatest','newConfirm','oddJob','completeOddJob'].includes(name)){toast('This is a shared Free Roam business. Leave the room to use solo saves, story or cheats.',true);return true;}
        const remote=['buy','craft','steady','plant','carePlant','upgrade','property','runner','toggleRunner','toggleReserve','buyRide','buyHelmet','buyMedkit','sell','deliver','declineOrder','food','orderMeal','ride','sleep'];
        if(remote.includes(name)){
            const a={type:name,id:data.id,npc:panelCtx?.id,variety:growVariety,kind:data.kind};
            if(name==='sell'){a.recipe=$('tradeProduct')?.value;a.qty=Number($('tradeQty')?.value);a.mult=Number($('tradePrice')?.value)/100;}
            coop.send(a);return true;
        }
        if(name==='stand'&&state.life.meal){coop.send({type:'refundMeal'});return true;}
        if(name==='policeComply'&&panel==='policeStop'){coop.send({type:'penalty',arrest:!!panelCtx?.arrest});return true;}
        return false;
    }
    function renderPartner(dt){
        const remote=coop.active?world.partner:null;$('friendLabel').classList.add('hidden');if(!remote)return;
        const p=remote.pose;if(!world.partnerSmooth||world.partnerSmooth.id!==remote.id)world.partnerSmooth={...p,id:remote.id};const q=world.partnerSmooth,k=Math.min(1,dt*10);
        for(const a of ['x','z','height'])q[a]+=(p[a]-q[a])*k;q.yaw+=Math.atan2(Math.sin(p.yaw-q.yaw),Math.cos(p.yaw-q.yaw))*k;
        renderer.gl.useProgram(renderer.cp);const model=world.customers[0].model;
        if(p.ride&&world.rideMeshes[p.ride])renderer.draw(world.rideMeshes[p.ride],MZ.M.model(q.x,.22+q.height,q.z,-q.yaw));
        if(!MZMobility.RIDES[p.ride]?.car){world.partnerActor??={model,phase:0,ry:0,x:0,z:0,name:'Partner'};Object.assign(world.partnerActor,{x:q.x,z:q.z,ry:Math.PI-q.yaw,height:q.height+(p.seat?-.5:0),walk:p.walk});world.drawPerson(world.partnerActor,realTime);}
        const v=renderer.project(q.x,2.5+q.height,q.z);if(v&&!panel&&v.x>30&&v.x<MZLayout.viewport.width-30&&v.y>80&&v.y<MZLayout.viewport.height-65){const el=$('friendLabel');el.textContent=remote.name+' / CO-OP';el.style.left=v.x+'px';el.style.top=v.y+'px';el.classList.remove('hidden');}
    }

    function screenMessage(text){const node=$('screenFeedback')||$('launchNotice');if(node)node.textContent=text;if(started)toast(text);}
    async function setFullscreen(){
        try{
            if(document.fullscreenElement||document.webkitFullscreenElement){const f=document.exitFullscreen||document.webkitExitFullscreen;if(f)await Promise.resolve(f.call(document));}
            else {const el=document.documentElement,f=el.requestFullscreen||el.webkitRequestFullscreen;if(!f){screenMessage('This browser does not offer page fullscreen. The layout still fits; try Add to Home Screen from your browser menu.');return false;}await Promise.resolve(f.call(el));}
            MZLayout.refresh();screenMessage('Screen layout updated. Rotate your device whenever you need.');return true;
        }catch(_){MZLayout.refresh();screenMessage('Fullscreen was not allowed by this browser. Continue in fitted browser mode, or use Add to Home Screen.');return false;}
    }
    function stopSeating(refund=true){
        if(!state?.life)return;
        const m=state.life.meal;if(m&&refund){state.cash+=m.paid||0;MZLife.log(state,'restaurant','Unfinished meal cancelled and refunded',m.paid||0);}
        state.life.meal=null;state.life.seat=null;
        if(seatedReturn&&world.isFree(seatedReturn.x,seatedReturn.z,state))Object.assign(state.player,seatedReturn);
        seatedReturn=null;$('seatedBar')?.classList.add('hidden');
    }
    function lifeAction(name,data){
        if(name==='fullscreen'){setFullscreen();return true;}
        if(name==='refit'){MZLayout.refresh();screenMessage('Screen fit refreshed using the visible browser size.');return true;}
        if(['launcherSettings','guideHub'].includes(name)){openPanel(name);return true;}
        if(name==='guideTopic'){openPanel('guideTopic',{id:data.id});return true;}
        if(name==='restaurantTrack'){action('track',{id:'restaurant'});return true;}
        if(name==='openHistory'){phoneTab='history';openPanel('phone');return true;}
        if(name==='exportHistory'){downloadJSON({game:'mzansi-after-hours',history:state.life.history},'mzansi-business-history.json');return true;}
        if(name==='unlockDev'){
            if(panel!=='devGate')return true;
            const feedback=$('devMessage');if(Date.now()<devWaitUntil){feedback.textContent='Please wait a few seconds before trying again.';return true;}
            if($('developerCode')?.value!=='Gameon@2025'){devAttempts++;if(devAttempts>=5){devWaitUntil=Date.now()+15000;devAttempts=0;}feedback.textContent='That code does not match. Check upper/lowercase and symbols.';return true;}
            devUnlocked=true;devAttempts=0;state.dev=devFlags;openPanel('dev');return true;
        }
        if(name==='lockDev'){devUnlocked=false;devFlags={unlimitedMoney:false,godMode:false,noPolice:false};state.dev=devFlags;serverAdminToken='';remoteStats=null;save();updateHUD();openPanel('devGate');return true;}
        if(name==='devToggle'){
            if(!devUnlocked||panel!=='dev'||!Object.hasOwn(devFlags,data.id))return true;
            devFlags[data.id]=!devFlags[data.id];state.dev=devFlags;
            if(data.id==='noPolice'){MZPolice.reset(world);state.heat=0;}
            if(started){MZLife.log(state,'developer',data.id+' switched '+(devFlags[data.id]?'on':'off'));save();}
            refresh();updateHUD();return true;
        }
        if(name==='beginFromDev'){if(devUnlocked){closePanel(false);startGame(false);}return true;}
        if(name==='devStats'){if(devUnlocked)openPanel('devStats');return true;}
        if(name==='fetchStats'){
            if(!devUnlocked||panel!=='devStats')return true;
            serverAdminToken=$('serverAdminToken')?.value||serverAdminToken;statsError='Loading shared statistics...';$('statsFeedback').textContent=statsError;
            MZMetrics.dashboard(serverAdminToken).then(data=>{if(!devUnlocked)return;remoteStats=data;statsError='';if(panel==='devStats')refresh();}).catch(e=>{statsError=e.message;if(panel==='devStats')refresh();});return true;
        }
        if(name==='prepareBatch'){
            if(panel!=='bench'||!RECIPES[data.id])return true;const r=RECIPES[data.id];
            if(!requirements(r)||!MZNeighbourhood.canCraft(state,r)||state.jobs.length>=mixSlots()||productCount()+state.jobs.length*4+4>capacity())return true;
            craftingDraft={recipe:data.id,step:0,tokens:[],bench:panelCtx};openPanel('crafting');return true;
        }
        if(name==='batchToken'){if(panel==='crafting'&&craftingDraft?.step===0){const i=Number(data.id);if([0,1,2].includes(i)&&!craftingDraft.tokens.includes(i)){craftingDraft.tokens.push(i);sound();refresh();}}return true;}
        if(name==='batchNext'){if(panel==='crafting'&&craftingDraft?.step===0&&craftingDraft.tokens.length===3){craftingDraft.step=1;refresh();$('modalBody').scrollTop=0;}return true;}
        if(name==='batchMatch'){if(panel==='crafting'&&craftingDraft?.step===1){if(data.id!==craftingDraft.recipe){$('batchFeedback').textContent='Choose the same blend shown at the top. No supplies were lost.';}else{craftingDraft.step=2;sound('ready');refresh();$('modalBody').scrollTop=0;}}return true;}
        if(name==='cancelBatch'){const bench=craftingDraft?.bench;craftingDraft=null;openPanel('bench',bench);return true;}
        if(name==='sealBatch'){
            if(panel!=='crafting'||craftingDraft?.step!==2)return true;
            const d=craftingDraft;craftingDraft=null;openPanel('bench',d.bench);action('craft',{id:d.recipe});return true;
        }
        if(name==='carePlant'){
            const i=Number(data.id);if(panel!=='grow'||!Number.isInteger(i)||i<0||i>=growSlots())return true;
            if(MZLife.carePlant(state,i,data.kind)){sound('ready');toast('Care task complete. This harvest gains one extra leaf.');save();refresh();}return true;
        }
        if(name==='sit'){
            if(panel!=='seat'||!started||fall)return true;const seat=world.seats.find(s=>s.id===data.id);
            if(!seat||Math.hypot(state.player.x-seat.x,state.player.z-seat.z)>4)return true;if(coop.active&&world.partner?.pose.seat===seat.id){toast('Your friend is using this seat. Choose another table.',true);return true;}
            stopRide(true);seatedReturn={...state.player};state.life.seat=seat.id;Object.assign(state.player,{x:seat.x,z:seat.z,yaw:seat.yaw,pitch:-.08});
            MZLife.log(state,'restaurant','Sat down at '+seat.name);closePanel(false);save();updateHUD();return true;
        }
        if(name==='tableMenu'){if(state.life.seat)openPanel('restaurant',world.getPoint('restaurant'));return true;}
        if(name==='stand'){stopSeating(true);closePanel(false);save();updateHUD();return true;}
        if(name==='orderMeal'){
            const meal=MZLife.MEALS[data.id];if(panel!=='restaurant'||!meal||!state.life.seat||state.life.meal||!world.inRestaurant(state.player.x,state.player.z)||!canAfford(meal.price))return true;
            const paid=state.dev.unlimitedMoney?0:meal.price;MZLife.pay(state,meal.price);state.life.meal={id:data.id,remaining:meal.seconds,paid};MZLife.log(state,'restaurant','Ordered '+meal.name, -paid);closePanel(false);save();sound();return true;
        }
        if(name==='policeComply'){
            if(panel!=='policeStop')return true;const arrest=!!panelCtx?.arrest;
            if(arrest){closePanel(false,true);catchPlayer();}
            else {const fine=state.dev.unlimitedMoney?0:Math.min(75,state.cash);MZLife.pay(state,fine);state.heat=0;state.caughtUntil=state.sim+20;state.stats.fines++;MZPolice.reset(world);MZLife.log(state,'police','Cooperated with a patrol warning',-fine);closePanel(false,true);toast('Warning settled. You may continue.');save();}
            return true;
        }
        if(name==='policeLeave'){
            if(panel!=='policeStop'||panelCtx?.arrest)return true;const officer=panelCtx.officer;closePanel(false,true);if(officer){const a=MZPolice.setup(officer);a.mode='chase';a.lastSeen=state.sim;a.last={x:state.player.x,z:state.player.z};a.routeAt=0;}
            state.heat=Math.max(65,state.heat);MZLife.log(state,'police','Left a patrol stop; pursuit started');save();return true;
        }
        if(name==='policeCooperate'){
            const officer=world.police.find(p=>['warning','chase'].includes(p.ai?.mode)&&Math.hypot(p.x-state.player.x,p.z-state.player.z)<9&&MZLife.canSee(world,p,state.player,state,12));
            if(officer){const arrest=officer.ai.mode==='chase';officer.ai.mode='stop';openPanel('policeStop',{officer,arrest});}return true;
        }
        return false;
    }
    function tickLife(dt){
        MZMetrics.tick(dt);
        if(fall){const finished=MZLife.tickFall(fall,dt,world,state);if(finished){const knockout=fall.knockout;fall=null;state.damageUntil=state.sim+2;
            if(knockout){stopSeating();injuryFee=coop.active?0:MZMobility.recover(state);if(coop.active){state.health=60;state.rides.riding=false;coop.enqueue({type:'recovery'});}Object.assign(state.player,world.homeSpawn);state.player.pitch=0;openPanel('injury');}
            else if(pendingTrafficLesson){pendingTrafficLesson=false;openPanel('trafficLesson');}save();}}
        if(state.life.meal&&state.life.seat){const m=state.life.meal;m.remaining-=dt;if(m.remaining<=0){const meal=MZLife.MEALS[m.id];const healed=Math.min(meal.heal,100-state.health);state.health+=healed;stamina=100;state.life.meals++;if(coop.active)coop.enqueue({type:'finishMeal'});state.life.meal=null;MZLife.log(state,'restaurant','Finished '+meal.name+' / +'+healed+' health');toast('Meal finished. +'+healed+' health. Stay a while or stand up.');sound('ready');save();}}
        if(!panel&&!fall){const event=MZPolice.tick(world,state,dt,{speed:world.lastPlayerSpeed||0});if(event){
            if(event.type==='stop'){stopRide(true);openPanel('policeStop',event);}
            else if(state.sim-lastPoliceNotice>3){lastPoliceNotice=state.sim;const text={warning:'Police: please stop and speak to the officer.',chase:'Police pursuit started.',search:'The patrol lost sight of you and is searching the last-seen area.',clear:'The patrol search has ended.'}[event.type];if(text){toast(text,event.type!=='clear');MZLife.log(state,'police',text);}}
        }}
    }

    function stopRide(dismount=false){rideMotion.speed=0;rideMotion.vx=0;rideMotion.vz=0;if(dismount&&state)state.rides.riding=false;}
    function indoors(){const p=state.player;return world.inRestaurant(p.x,p.z)||(world.nightlifeBuildings||[]).some(b=>p.x>b.x-b.w/2+.3&&p.x<b.x+b.w/2-.3&&p.z>b.z-b.d/2+.3&&p.z<b.z+b.d/2-.3)||world.inHome(p.x,p.z)||(p.x>28.2&&p.x<51.8&&p.z>15&&p.z<37);}
    function updateSaveCard(){
        const stamp=state?.meta?.savedAt;
        $('resumeDetail').textContent=!device.available?'Local saving is blocked. Export a backup to keep your progress.':stamp ? 'Day '+state.day+' / '+money(state.cash)+' / saved '+new Date(stamp).toLocaleString() : 'Your progress will be saved automatically in this browser.';
        $('profileTag').textContent=device.profile.id+' / LOCAL BROWSER PROFILE';
    }
    function toggleRide(){
        if(!started||panel||contextLost||fall||state.life.seat)return;
        if(state.rides.riding){if(MZMobility.RIDES[state.rides.equipped]?.car){const p=state.player;for(const side of [1,-1]){const x=p.x+Math.cos(rideMotion.heading)*1.4*side,z=p.z+Math.sin(rideMotion.heading)*1.4*side;if(world.isFree(x,z,state)){p.x=x;p.z=z;break;}}}stopRide(true);toast('On foot. Your ride is safely stored in My rides.');save();updateHUD();return;}
        const id=state.rides.equipped;
        if(!id||!state.rides.owned[id]){openPanel('garage');return;}
        if(indoors()){toast('Step outside before mounting your ride.',true);return;}
        if(state.health<=0)return;
        const ride=MZMobility.RIDES[id];if(ride.car){const missing=MZNightlife.missing(state,id);if(missing.length){toast('Refit before driving: '+missing.join(', '),true);openPanel('partsGarage');return;}}if(ride.car&&!MZTravel.footprint(state.player.x,state.player.z,state.player.yaw,ride,world,state)){toast('Move to an open road or clear parking space before entering the car.',true);return;}
        jumpState=MZTravel.jumpState();state.rides.riding=true;rideMotion=ride.car?MZTravel.carMotion(state.player.yaw):MZMobility.motion(state.player.yaw);
        if(ride.car){carCamera=MZCamera.create(state.settings.carCameraDistance);}
        state.player.pitch=Math.min(state.player.pitch,-.10);
        if(!state.roadGuide.riding){state.roadGuide.riding=true;openPanel('rideLesson');}
        else toast('Riding '+MZMobility.RIDES[id].name+'. Brake before traffic.');
        save();updateHUD();
    }
    function healWithKit(){if(!started||saveConflict)return;const n=MZMobility.useMedkit(state);if(!n){toast(state.health>=100?'You already have full health.':'No first-aid kits. Visit Ubuntu Wheels or Sunset Spaza.',true);return;}sound('ready');toast('First aid: +'+n+' health.');updateHUD();if(panel==='health')refresh();save();}
    function takeTrafficHit(car){
        if(fall||state.sim<state.damageUntil)return false;
        if(state.rides.riding&&MZMobility.RIDES[state.rides.equipped]?.car){carCrash(Math.abs(car.speed)+Math.abs(rideMotion.speed)*.6);rideMotion.vx*=-.2;rideMotion.vz*=-.2;return true;}
        jumpState=MZTravel.jumpState();
        let impact;
        if(state.dev.godMode){impact={lost:0,knockedOut:false,protectedRide:false};state.damageUntil=state.sim+5;state.stats.trafficHits++;}
        else impact=MZMobility.damage(state,Math.round(23+Math.abs(car.speed)*2));
        if(!impact)return false;
        stopRide(true);stopSeating(true);fall=MZLife.createFall(state,car);state.damageUntil=state.sim+fall.duration+1;
        pendingTrafficLesson=!state.roadGuide.traffic;state.roadGuide.traffic=true;
        sound('warn');if(!state.settings.reducedMotion){$('flash').style.opacity='.16';setTimeout(()=>$('flash').style.opacity='0',180);}
        MZLife.log(state,'health','Traffic collision / lost '+impact.lost+' health');
        toast('Traffic hit. You are getting back up. Health lost: '+impact.lost+'.',true);save();updateHUD();return true;
    }

    function updatePlayModeLabel(){
        const mode=titlePlayMode||state.mode||'story';
        document.querySelectorAll('[data-play-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.playMode===mode)));
        $('playModeStatus').textContent=mode==='free'?'No compulsory missions. All blends available; earn money, buy upgrades and choose your customers.':'Guided chapters with Zanele. Switch modes anytime without losing your progress.';
        const saved=!!state.meta.savedAt;
        $('startBtn').innerHTML=(saved?'Continue ':'Start ')+(mode==='free'?'Free Roam':'your story')+' <span>&#8599;</span>';
    }
    function updateDeviceLabel(){
        if(!state)return;
        const mode=state.settings.mobileControls;
        document.querySelectorAll('[data-device]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.device===mode)));
        $('deviceStatus').textContent=(mode==='auto'?'Auto detected: ': 'Selected: ')+(touch?.enabled?'touch controls':'mouse + keyboard')+' - change this anytime in Menu.';
    }

    function storyEvent(name, data = {}) {
        MZStory.event(state, name, data);
        if (!isFreeMode() && name === 'crafted' && data.recipe === 'mist' && state.story.chapter === 9 && state.track === 'bench')
            state.track = 'lerato';
    }
    function syncStory() {
        if(isFreeMode())return;
        const before = state.story.chapter;
        for (const c of MZStory.advance(state)) {
            if (c.reward)
                toast("Zanele's support: +" + money(c.reward) + ' / ' + c.title);
        }
        if (before !== state.story.chapter) {
            state.track = quest().target;
            refreshQueued = !!panel;
        }
    }
    function maybeBrief() {
        if(started && !panel && !contextLost && isFreeMode()){
            if(!state.freeGuideSeen){state.freeGuideSeen=true;openPanel('freeGuide');save();}
            return;
        }
        if (!started || panel || contextLost || MZStory.complete(state))
            return;
        if (state.story.seen !== state.story.chapter) {
            state.story.seen = state.story.chapter;
            openPanel('chapter');
            save();
        }
    }
    function applySettings() {
        document.body.classList.toggle("reader-large",!!state.settings.largeText);
        renderer.pixel = [touchDetected() ? .8 : 1, 1.35, 1.8][state.settings.quality];
        renderer.visualQuality=state.settings.quality;
        MZCamera.zoom(carCamera,state.settings.carCameraDistance||7);
        if (state.settings.quality>0 && !renderer.shadowReady) renderer.bakeShadows?.(world.shadowMeshes);
        touch?.update();
        $('pinnedLesson').classList.toggle('hidden', !state.settings.guidePinned);
        updateDeviceLabel();
    }
    function applyCooldowns() { for (const n of world.customers)
        n.cooldown = state.cooldowns[n.id] || 0; }
    function spareStock(id) { const reserved = state.reserveOrders ? state.orders.filter(o => o.recipe === id).reduce((n, o) => n + o.qty, 0) : 0; return Math.max(0, state.products[id] - reserved); }
    function lookBy(dx, dy, touchInput = false) {
        if (!started || panel || contextLost)
            return;
        const sensitivity = touchInput ? .0045 * state.settings.touchSensitivity : .0021 * state.settings.sensitivity;
        const delta = dx * sensitivity;
        if(activeCar()){MZCamera.look(carCamera,delta,dy*sensitivity);return;}
        state.player.yaw += delta;
        state.player.pitch = clamp(state.player.pitch - dy * sensitivity, -1.14, 1.14);
        storyEvent('look', { amount: delta });
    }
    const initial = () => MZSave.initial(touchDetected());
    function validSave(raw) { return MZSave.validate(raw, touchDetected()); }
    function load() {
        try {
            const result = MZSave.read(localStorage, touchDetected());
            if (result) {
                recoveredSave = result.recovered;
                return result.state;
            }
        }
        catch (_) { }
        return null;
    }
    function save(show = false, forceBackup = false, overwrite = false) {
        if(coop.active){lastSave=state.sim;coop.remember();$('saveStatus').textContent=coop.stalled?'CO-OP / RECONNECTING':'TEAM SAVED ON SERVER';return;}
        if (!started || (saveConflict && !overwrite)) return;
        if(!overwrite && device.newer(state)){
            saveConflict=true;openPanel('saveConflict');$('saveStatus').textContent='NEWER SAVE FOUND';return;
        }
        for (const n of world.customers)
            state.cooldowns[n.id] = n.cooldown || 0;
        try {
            const rotate = forceBackup || realTime - lastBackup >= 30;
            MZSave.write(localStorage, state, rotate, device.session);
            device.remember(state.settings.mobileControls);
            storageWarning=false;$('saveWarning').classList.add('hidden');
            if (rotate)
                lastBackup = realTime;
            lastSave = state.sim;
            $('saveStatus').textContent = 'SAVED ON THIS BROWSER';
            if (show)
                toast('Progress saved in this browser.');
        }
        catch (e) {
            $('saveStatus').textContent = 'EXPORT TO SAVE';
            $('saveWarning').classList.remove('hidden');
            lastSave = state.sim;
            if (!storageWarning) {
                toast('Browser storage is unavailable. Use Menu > Export save to keep your progress.', true);
                storageWarning = true;
            }
        }
    }
    function downloadJSON(data, filename) {
        const a = document.createElement('a');
        const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 10000);
    }
    function exportSave() { save(); downloadJSON(state, 'mzansi-v11-day-' + state.day + '.json'); toast('Save export requested. Keep the JSON file as your backup.'); }
    function toast(text, warn = false) {
        const t=document.createElement('div');t.className='toast'+(warn?' warn':'');
        const copy=document.createElement('span');copy.textContent=text;t.append(copy);
        const close=document.createElement('button');close.textContent='×';close.className='toast-close';close.setAttribute('aria-label','Dismiss notification');close.onclick=()=>t.remove();t.append(close);
        $('toastArea').append(t);while($('toastArea').children.length>4)$('toastArea').firstChild.remove();
        noticeLog.unshift({text,warn,day:state?.day||1});if(noticeLog.length>40)noticeLog.pop();
        const seconds=state?.settings.tipSeconds??16;
        if(seconds>0)setTimeout(()=>t.remove(),seconds*1000);
    }
    function sound(kind = 'click') { if (!state?.settings.sound)
        return; try {
        audio = audio || new (window.AudioContext || window.webkitAudioContext)();
        if (audio.state === 'suspended')
            audio.resume().catch(() => { /* Audio permission must not stop play. */ });
        const tones = kind === 'cash' ? [523, 659, 784] : kind === 'warn' ? [230, 180] : kind === 'ready' ? [440, 660] : [420];
        tones.forEach((f, i) => { let o = audio.createOscillator(), g = audio.createGain(); o.type = kind === 'warn' ? 'triangle' : 'sine'; o.frequency.value = f; o.connect(g); g.connect(audio.destination); let t = audio.currentTime + i * .07; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(kind === 'warn' ? .045 : .035, t + .012); g.gain.exponentialRampToValueAtTime(.001, t + .16); o.start(t); o.stop(t + .18); });
    }
    catch (e) { } }
    const productCount = () => Object.values(state.products).reduce((a, b) => a + b, 0);
    const capacity = () => state.upgrades.bag ? 80 : 40;
    const mixSlots = () => 1 + (state.upgrades.mixer ? 1 : 0) + (state.workshop ? 1 : 0);
    const growSlots = () => state.workshop ? 4 : 2;
    const rank = () => state.rep >= 45 ? 'LOCAL LEGEND' : state.rep >= 20 ? 'KNOWN AROUND TOWN' : state.rep >= 6 ? 'MAKING A NAME' : 'NEW FACE';
    const canAfford = price => MZLife.canPay(state,price);
    const requirements = r => Object.entries(r.needs).every(([k, v]) => state.inv[k] >= v);
    const recipeRequirements = r => Object.entries(r.needs).map(([k, n]) => `<span class="${state.inv[k] >= n ? 'enough' : 'missing'}">${n} ${SUPPLIES[k].name.toLowerCase()} (${state.inv[k]})</span>`).join(' &nbsp; / &nbsp; ');
    function quest() { return MZStory.current(state); }
    function release() { stopRide(); try {
        document.exitPointerLock?.();
    }
    catch (_) { } locked = false; keys = {}; drag = null; touch?.clear(); }
    function requestLock() { if (!started || panel || touch?.enabled)
        return; try {
        const p = canvas.requestPointerLock?.();
        if (p?.catch)
            p.catch(() => { });
    }
    catch (_) { } }
    function startGame(fresh = false) {
        release();
        saveConflict=false;
        if (fresh) {
            if (started)
                save(false, true);
            const previousMeta=load()?.meta;
            state = initial();
            if(previousMeta)state.meta={...previousMeta};
            state.settings.mobileControls=device.profile.mode;
            phoneTab = 'home';
            $('toastArea').replaceChildren();
            oldQuest = -1;
        }
        else
            state = load() || state || initial();
        if(launchSettings){Object.assign(state.settings,launchSettings);launchSettings=null;}
        state.dev=devUnlocked?devFlags:{unlimitedMoney:false,godMode:false,noPolice:false};
        jumpState=MZTravel.jumpState();world.jumpHeight=0;fall=null;state.life.seat=null;state.life.meal=null;seatedReturn=null;MZPolice.reset(world);
        if(titleMode!==null)state.settings.mobileControls=titleMode;
        if(titlePlayMode!==null && state.mode!==titlePlayMode)MZNeighbourhood.setMode(state,titlePlayMode);
        updatePlayModeLabel();
        if (!world.isFree(state.player.x, state.player.z, state))
            Object.assign(state.player, world.homeSpawn);
        applyCooldowns();
        stamina = 100;
        stopRide(true);rideMotion.heading=state.player.yaw;
        if(state.health<=0){MZMobility.recover(state);Object.assign(state.player,world.homeSpawn);}
        // Traffic starts in a deterministic position after loading. Give the player
        // time to move off a road before it can cause a fresh hit.
        state.damageUntil=Math.max(state.damageUntil,state.sim+3);
        lastSave = state.sim;
        oldQuest = -1;
        started = true;
        MZLife.log(state,"system",fresh?"Started a new game with R2,500":"Returned to the neighbourhood");
        MZMetrics.begin(()=>state,device.profile.id,!!touch?.enabled);
        paused = false;
        panel = null;
        panelCtx = null;
        refreshQueued = false;
        $('titleScreen').classList.add('hidden');
        $('cinema').classList.add('hidden');
        $('hud').classList.remove('hidden');
        $('boot').classList.add('hidden');
        $('modalBackdrop').classList.add('hidden');
        $('crosshair').classList.remove('hidden');
        applySettings();
        syncStory();
        updateHUD();
        save(false,fresh,fresh);
        device.retention();
        sound();
        if(!coop.active)openPanel('careerChoice');else maybeBrief();
        if (!panel) {
            requestLock();
            toast(isFreeMode()?'Welcome back. Choose a destination in Map or a customer in Phone.':'Welcome back. Your next chapter is marked in gold.');
        }
        if (recoveredSave) {
            toast('A previous save was recovered or upgraded. Export a v11 backup from Menu.');
            recoveredSave = false;
        }
    }
    function openPanel(type, ctx = null) {
        if(type==='customer'&&ctx&&MZPeople.injured(ctx))type='npcCare';
        if(type==='map'&&atlasZoom===null)atlasZoom=MZLayout.viewport.width<620?2.5:1;
        if(type==='dev'&&!devUnlocked)type='devGate';
        if(type==='devStats'&&!devUnlocked)type='devGate';
        if(panel==='policeStop'&&type!=='policeStop')return;
        if(type==='district')type='districts';
        if(isFreeMode() && ['chapter','mentor'].includes(type))type='freeGuide';
        if(saveConflict && type!=='saveConflict')return;
        if (!started && !['coop', 'help', 'newConfirm', 'saveCenter', 'importConfirm', 'saveConflict','launcherSettings','drivingSetup','cameraSettings','devGate','dev','devStats','guideHub','guideTopic','commerceGuide'].includes(type))
            return;
        lastFocus = document.activeElement;
        release();
        if(type!==panel && ['chapter','mentor','lesson'].includes(type))lessonPage=0;
        if(type==='lesson')journalIndex=Number.isInteger(ctx?.index)?ctx.index:Math.min(state.story.chapter,14);
        panel = type;
        panelCtx = ctx;
        paused = !['bench', 'grow','workstation','bankApplications'].includes(type);
        if (started) {
            storyEvent(type);
            syncStory();
        }
        document.body.classList.add('modal-open');
        $('modalBackdrop').classList.remove('hidden');
        $('interaction').classList.add('hidden');
        $('crosshair').classList.add('hidden');
        renderPanel();
        touch?.update();
        sound();
        $('closeModal').focus({ preventScroll: true });
    }
    function closePanel(lock = true, forced = false) {
        if(panel==='policeStop'&&!forced)return;
        if(panel==='crafting')craftingDraft=null;
        if(saveConflict && panel==='saveConflict')return;
        panel = null;
        panelCtx = null;
        paused = false;
        refreshQueued = false;
        document.body.classList.remove('modal-open');
        $('modalBackdrop').classList.add('hidden');
        $('crosshair').classList.remove('hidden');
        keys = {};
        drag = null;
        touch?.clear();
        touch?.update();
        if (lastFocus?.isConnected && lastFocus !== document.body)
            lastFocus.focus({ preventScroll: true });
        if(started)updateCompass();
        if (lock && started)
            requestLock();
        save();
    }
    function renderPanel() {
        if (!panel)
            return;
        let title = '', sub = '', html = '', foot = 'E / ESC to return to the street';
        const button = (txt, a, data = '', disabled = false, cls = '') => `<button class="${cls}" data-action="${a}" ${data} ${disabled ? 'disabled' : ''}>${txt}</button>`;
        if(panel==='freeGuide'){
            title='Your city. Your choice.';sub='FREE ROAM / NO COMPULSORY MISSIONS';
            html=`<div class="free-banner"><span>OPEN NEIGHBOURHOOD</span><h3>40 customers.<br>Make your own rounds.</h3><p>All seven districts and all four blends are available. Supplies, upgrades and vehicles still cost in-game rands.</p></div><div class="lesson-box"><h3>Roam. Make. Trade.</h3><p><b>1. Make stock:</b> use the mixing bench at The Yard. You have starter supplies.</p><p><b>2. Choose anyone:</b> Phone &gt; Contacts lists every customer. Track one, walk or ride over, then press E or tap USE.</p><p><b>3. Make an offer:</b> choose a product, quantity and price. Customers can decline high offers; their favourite blend pays a 10% premium.</p><p>Phone orders are optional. Health, traffic, attention and saving still work. Switching modes keeps your cash, inventory and purchased rides. Your story chapter waits for you.</p></div><div class="grid">${button('Explore the streets','resume','','', 'primary')}${button('Choose a customer','contacts','','', 'secondary')}${button('Explore districts','districts','','', 'secondary')}${button('Replay a tutorial lesson','replayConfirm','','', 'secondary')}</div>`;
            foot='PAUSED / THIS GUIDE WAITS UNTIL YOU CLOSE IT';
        }
        else if(panel==='districts'){
            title='Explore Sundown Bay';sub='7 DISTRICTS / ONE CONNECTED NEIGHBOURHOOD';
            html=`<p>Every district is open from the start. Walk or ride there, or use a taxi stop for R20. There are 40 customers across seven districts.</p><div class="grid district-cards">${MZNeighbourhood.districts.map(d=>`<div class="card district-card district-${d.id}"><span class="tag">${world.customers.filter(n=>n.district===d.id).length} CUSTOMERS</span><h3>${d.name}</h3><p>${d.description}</p>${button('Track district','track',`data-id="${d.target}"`,false,'primary')}${button('Browse customers','districtContacts',`data-id="${d.id}"`,false,'secondary')}</div>`).join('')}</div>`;
        }
        else if(panel==='modeConfirm'){
            const next=panelCtx?.mode==='free'?'free':'story';title='Switch to '+(next==='free'?'Free Roam':'Story mode')+'?';sub='SAME SAVE / NO RESET';
            html=`<p>Your cash, health, products, upgrades, property and rides are kept. ${next==='free'?'Story steps and story rewards will pause. All blend recipes become available; you still need their ingredients.':'Your story chapter resumes where you left it. Reputation requirements apply to crafting again; existing stock is kept.'}</p>${button('Keep progress and switch','setPlayMode',`data-id="${next}"`,false,'primary wide')}${button('Cancel','pause','',false,'secondary wide')}`;
        }
        else if (['chapter','mentor','lesson'].includes(panel)) {
            const i = panel==='lesson' ? journalIndex : Math.min(state.story.chapter, MZStory.chapters.length - 1), c = MZStory.chapters[i];
            const finished = panel!=='lesson' && MZStory.complete(state);
            title = panel === 'mentor' ? 'Auntie Zanele' : c.title;
            sub = (panel==='lesson'?'REPLAY / ': '') + (panel === 'mentor' ? 'THE YARD / A FAMILIAR FACE' : c.role);
            const person = panel === 'mentor' ? 'Auntie Zanele' : c.speaker;
            const portrait=world.portraitFor(person);
            html = `<div class="story-speaker"><div class="portrait"><img src="${portrait}" alt="${esc(person)}"></div><div><span class="eyebrow">${finished ? 'A PLACE TO CALL HOME' : 'CHAPTER ' + (i + 1) + ' / ' + MZStory.chapters.length}</span><h3>${esc(person)}</h3><span class="read-status">PAUSED / READ AT YOUR OWN PACE</span></div></div>`;
            if(lessonPage===0) {
                html += `<div class="scene-banner scene-${['home','home','home','home','mix','street','street','shop','home','mix','home','shop','workshop','workshop','street'][i]}"><div class="scene-mark">${MZGuide.svg(i===7?'home':i===5?'phone':i===4?'bag':'home')}</div><div><span>SUNDOWN BAY</span><strong>${i===7?'SUNSET SPAZA':i>=12?'WORKSHOP 02':i===5||i===6?'THE NEIGHBOURHOOD':'THE YARD'}</strong></div><span class="scene-number">${String(i+1).padStart(2,'0')}</span></div><p class="story-quote">&ldquo;${finished ? 'The key was only the beginning. You built the rest. Welcome home, neighbour.' : esc(c.line)}&rdquo;</p>`;
                html += button(finished?'Explore the neighbourhood':'Next: show me how to play',finished?'resume':'lessonNext','',false,'primary wide');
            } else {
                html += `<div class="lesson-steps">${MZGuide.lesson(i,!!touch?.enabled).map((step,j)=>`<article class="lesson-step"><div class="step-icon">${['home','person','wallet','move','look','map','use','bag','phone','clock'].includes(step.icon)?MZGuide.svg(step.icon):`<img src="${MZVisuals.icon(step.icon)}" alt="">`}</div><div><small>STEP 0${j+1}</small><h3>${esc(step.title)}</h3><p>${esc(step.body)}</p></div></article>`).join('')}</div><details class="full-lesson"><summary>Read the complete rule</summary><p>${esc(c.lesson)}</p>${button("Replay this lesson", "replayChapter", `data-id="${i}"`, false, "secondary")}</details><div class="story-objective"><span class="tiny-dot"></span>${esc(c.task)}</div><div class="lesson-actions">${button('Back','lessonBack','',false,'secondary')}`;
                if(panel==='lesson')html+=button('Lesson understood','resume','',false,'primary');
                else if(state.story.chapter===0)html+=button('Take the keys & begin','storyBegin','',false,'primary');
                else if(panel==='mentor')html+=button(state.story.chapter===10?'Tell me about attention':'Thanks, Zanele','mentorTalk','',false,'primary');
                else html+=button("I am ready - let's go",'resume','',false,'primary');
                html+='</div>';
            }
            html += `<p class="export-note">${lessonPage===0?'STORY 1 / 2':'LESSON 2 / 2'} &middot; No countdown. This stays open until you choose a button. Read it again using How to play or Phone &gt; Story.</p>`;
            foot='YOUR GAME IS PAUSED / NOTHING HAPPENS WHILE YOU READ';
        }
        else if (panel === 'bench') {
            title = panelCtx?.id === 'workBench' ? 'Workshop mixing line' : 'The mixing bench';
            sub = 'SMALL BATCHES / INVENTED INGREDIENTS';
            html = `<p>Choose a blend. A batch takes ${state.upgrades.solar ? 6 : 10} seconds and makes 3 packs. Use the optional timing bonus for a fourth pack, or head outside while it runs.</p><div class="split-stat"><div class="stat"><span>PACKED STOCK</span><strong>${productCount()} / ${capacity()}</strong></div><div class="stat"><span>MIXING SLOTS</span><strong>${state.jobs.length} / ${mixSlots()}</strong></div><div class="stat"><span>REPUTATION</span><strong>${state.rep}</strong></div></div>`;
            if (state.jobs.length)
                html += `<div class="jobs">${state.jobs.map(j => `<div class="order-card"><div class="row"><h3>${RECIPES[j.recipe].name}</h3><span class="job-timer" data-timer="${j.id}"></span></div><div class="job-meter"><div data-job="${j.id}"></div></div><div class="small" style="font-size:10px;color:var(--muted)">Bonus hits: ${j.hits}/2 &middot; Taps left: ${3 - j.taps}</div>${j.taps < 3 ? `<div class="timing-track" style="position:relative;height:20px;background:#ffffff0b;border-radius:4px;margin-top:12px;overflow:hidden"><span style="position:absolute;left:35%;width:30%;height:100%;background:#8ed7b34a"></span><span data-needle="${j.id}" style="position:absolute;width:3px;height:100%;background:#f2b965"></span></div>${button(touch?.enabled ? 'Tap in the mint zone' : 'Steady the mixer [SPACE]', 'steady', `data-id="${j.id}"`, false, 'secondary wide')}` : '<p style="margin-top:12px!important;margin-bottom:0!important">Timing complete. Your batch is finishing.</p>'}</div>`).join('')}</div>`;
            html += `<div class="grid">${Object.entries(RECIPES).map(([id, r]) => { let locked = !MZNeighbourhood.canCraft(state,r), full = productCount() + state.jobs.length * 4 + 4 > capacity(); return `<div class="card ${locked ? 'locked' : ''}"><span class="tag ${locked ? 'warn' : ''}">${locked ? 'UNLOCKS AT ' + r.rep + ' REP' : r.effect}</span><h3><img class="item-art" src="${MZVisuals.icon(id)}" alt="">${r.name}</h3><p>${r.desc}</p><div class="row"><span class="cost">${money(r.value)} / pack</span><span class="small">Makes 3-4</span></div><div class="recipe-inputs">${recipeRequirements(r)}</div>${button(locked ? 'Build your reputation' : full ? 'Stock bag full' : state.jobs.length >= mixSlots() ? 'All stations busy' : 'Prepare a batch', 'prepareBatch', `data-id="${id}"`, locked || !requirements(r) || state.jobs.length >= mixSlots() || full, 'primary')}</div>`; }).join('')}</div>`;
            foot = 'SPACE = optional timing tap. You may leave while batches finish. These are fantasy recipes.';
        }
        else if (panel === 'grow') {
            title = 'The grow room';
            sub = 'YOUR YARD / GLOWLEAF PLANTERS';
            html = `<p>Glowleaf is an imaginary plant. Use one seed, wait for it to mature, then collect six leaves. You have <strong>${state.inv.seed} seeds</strong> and <strong>${state.inv.leaf} leaves</strong>.</p><div class="grid">${state.plants.map((p, i) => { let locked = i >= growSlots(), ready = p && state.sim - p.start >= p.duration; return `<div class="card ${locked ? 'locked' : ''}"><span class="tag">PLANTER 0${i + 1}</span><h3>${locked ? 'More room to grow' : ready ? 'Ready to harvest' : p ? 'Growing Glowleaf' : 'Fresh start'}</h3><p>${locked ? 'Buying Workshop 02 unlocks this planter.' : ready ? 'Six leaves are ready for your next blend.' : p ? 'Your plant grows while you explore the neighbourhood.' : 'Plant one seed. Make this little corner productive.'}</p>${p && !ready ? `<div class="job-meter"><div data-plant="${i}"></div></div><span class="job-timer" data-plant-timer="${i}"></span>` : ''}${button(locked ? 'Buy Workshop 02' : ready ? 'Harvest 6 leaves' : p ? 'Growing...' : 'Plant a seed', 'plant', `data-id="${i}"`, locked || !!p && !ready || !p && !state.inv.seed, ready ? 'primary' : '')}</div>`; }).join('')}</div>`;
            foot = 'Plants grow while the game is running. Buy more seeds at Sunset Spaza.';
        }
        else if (panel === 'shop') {
            title = panelCtx?.id==='marketSupply'?'Market supply kiosk':'Sunset Spaza';
            sub = 'NANDI / YOUR LOCAL SUPPLIER';
            html = `<p class="dialogue">"Welcome, neighbour. Everything starts with good supplies. What can I get you?"</p><div class="row" style="margin-bottom:20px"><span class="eyebrow">CASH ON HAND</span><strong style="color:var(--amber)">${money(state.cash)}</strong></div><div class="grid">${Object.entries(SUPPLIES).map(([id, s]) => `<div class="card"><h3><img class="item-art small-art" src="${MZVisuals.icon(id)}" alt="">${s.name}</h3><p>${s.desc}</p><div class="row"><span class="cost">${money(s.price)} / ${s.qty === 1 ? 'each' : s.qty + ' units'}</span><span class="small">In bag: ${state.inv[id]}</span></div>${button('Buy ' + s.qty, 'buy', `data-id="${id}"`, !canAfford(s.price), 'primary')}</div>`).join('')}</div>`;
            html += `<div class="card help-job"><span class="tag">NEIGHBOURHOOD WORK / NO COST</span><h3>A grocery delivery</h3><p>${state.recovery.active ? "Take Nandi's groceries to Musa on the western pavement. He will pay R75." : state.sim < state.recovery.next ? 'The next grocery job is available after ' + Math.ceil(state.recovery.next - state.sim) + ' seconds of street play.' : 'Short of cash? Carry a grocery parcel to Musa for R75. You need no supplies or finished stock.'}</p>${button(state.recovery.active ? 'Track Musa' : 'Take the grocery job', 'oddJob', '', !state.recovery.active && state.sim < state.recovery.next, 'secondary wide')}</div>`;
        }
        else if (panel === 'upgrades') {
            title = 'Bay Hardware';
            sub = 'AADIL / BUILD SOMETHING BIGGER';
            html = `<p class="dialogue">"A small upgrade now saves you work later. Have a look around."</p><div class="grid">${Object.entries(UPGRADES).map(([id, u]) => `<div class="card"><span class="tag">${state.upgrades[id] ? 'INSTALLED' : 'UPGRADE ' + u.icon}</span><h3><img class="item-art" src="${MZVisuals.icon(id)}" alt="">${u.name}</h3><p>${u.desc}</p><span class="cost">${money(u.price)}</span>${button(state.upgrades[id] ? 'Already installed' : 'Buy & install', 'upgrade', `data-id="${id}"`, state.upgrades[id] || !canAfford(u.price), 'primary')}</div>`).join('')}</div>`;
        }
        else if (panel === 'inventory') {
            title = 'Your backpack';
            sub = 'SUPPLIES / FINISHED PRODUCTS';
            html = `<div class="split-stat"><div class="stat"><span>CASH</span><strong>${money(state.cash)}</strong></div><div class="stat"><span>PACKED STOCK</span><strong>${productCount()}/${capacity()}</strong></div><div class="stat"><span>LIFETIME SALES</span><strong>${money(state.totalRevenue)}</strong></div></div><h3>Finished products</h3>${Object.entries(RECIPES).map(([id, r]) => `<div class="inventory-row"><span><img class="item-art small-art" src="${MZVisuals.icon(id)}" alt="">${r.name}<small style="margin-left:8px;color:var(--muted)">${money(r.value)} each</small></span><strong>${state.products[id]}</strong></div>`).join('')}<h3 style="margin-top:25px">Supplies</h3>${Object.entries(SUPPLIES).map(([id, s]) => `<div class="inventory-row"><span><img class="item-art small-art" src="${MZVisuals.icon(id)}" alt="">${s.name}</span><strong>${state.inv[id]}</strong></div>`).join('')}<p class="panel-note" style="margin-top:20px">Finished stock is shared with your delivery runner once hired. Mixing reserves up to four spaces per batch. Raw supplies do not use packed-stock space.</p>`;
        }
        else if (panel === 'phone') {
            title = 'Your phone';
            sub = 'SUNDOWN BAY / CONNECTIONS';
            html = `<div class="panel-tabs">${['orders', 'contacts', 'story'].map(t => button(t[0].toUpperCase() + t.slice(1), 'phoneTab', `data-id="${t}"`, false, phoneTab === t ? 'active' : '')).join('')}</div>`;
            if (phoneTab === 'orders') {
                html += `<p>Orders stay available until delivered. Track a customer, bring the right stock, and press E to finish the deal.</p>${state.orders.length ? state.orders.map(o => { let n = world.getPoint(o.npc), r = RECIPES[o.recipe], ready = state.products[o.recipe] >= o.qty; return `<div class="order-card"><div class="row"><h3>${n.name}</h3><span class="payment">${money(o.pay)}</span></div><p>${o.qty} &times; ${r.name} &middot; You have ${state.products[o.recipe]}<br>"${n.greeting}"</p><div class="order-bottom"><span class="${ready ? 'ready' : ''}">${ready ? 'READY TO DELIVER' : 'NEEDS STOCK'}</span>${button(state.track === o.npc ? 'Tracking customer' : 'Track customer', 'track', `data-id="${o.npc}"`)}</div>${isFreeMode()||o.npc!=='sipho'||state.story.flags.siphoDelivered?button('Decline / no penalty','declineOrder',`data-id="${o.id}"`,false,'text-btn'):''}</div>`; }).join('') : '<p>New orders will arrive soon. You can still sell directly to any customer.</p>'}`;
            }
            else if (phoneTab === 'contacts') {
                const contacts=world.customers.filter(n=>contactDistrict==='all'||n.district===contactDistrict).sort((a,b)=>Math.hypot(a.x-state.player.x,a.z-state.player.z)-Math.hypot(b.x-state.player.x,b.z-state.player.z));
                html+=`<label class="field">District<select id="contactDistrict"><option value="all">All districts (40)</option>${MZNeighbourhood.districts.map(d=>`<option value="${d.id}" ${contactDistrict===d.id?'selected':''}>${d.name} (${world.customers.filter(n=>n.district===d.id).length})</option>`).join('')}</select></label><p>Trade directly with any customer. Sorted nearest first. Phone orders are optional; you do not need one to make a sale.</p><div class="grid contact-cards">${contacts.map(n=>`<div class="card"><span class="tag">${MZNeighbourhood.districts.find(d=>d.id===n.district).short} / ${Math.round(Math.hypot(n.x-state.player.x,n.z-state.player.z))}m</span><h3>${n.name}</h3><p>${esc(n.role||'Neighbourhood regular')}<br>${n.favourite?'Favourite: '+RECIPES[n.favourite].name+' (+10% value)':'Open to every blend'}<br>${state.sim<n.cooldown?'Ready again in '+Math.ceil(n.cooldown-state.sim)+'s':'Ready to trade'}</p>${button('Track customer','track',`data-id="${n.id}"`,false,'primary')}</div>`).join('')}</div>`;
            }
            else {
                const q = quest();
                html += `<div class="card"><span class="tag">${isFreeMode() ? 'FREE ROAM / STORY PAUSED' : MZStory.complete(state) ? 'FREE PLAY' : 'CHAPTER ' + q.n + ' / ' + MZStory.chapters.length}</span><h3>${esc(q.title)}</h3><p>${esc(q.text)}</p>${button(isFreeMode()?'Free Roam guide':'Read current chapter', 'readChapter', '', false, 'primary')}${isFreeMode()?button('Find customers','contacts','',false,'secondary'):button('Track next objective', 'track', `data-id="${q.target}"`)}</div><div class="split-stat" style="margin-top:20px"><div class="stat"><span>LIFETIME SALES</span><strong>${money(state.totalRevenue)}</strong></div><div class="stat"><span>DELIVERIES</span><strong>${state.stats.delivered}</strong></div><div class="stat"><span>BATCHES</span><strong>${state.stats.crafted}</strong></div></div><h3>Your story journal</h3>${MZStory.chapters.map((c, i) => `<details class="journal-entry" ${i === state.story.chapter ? 'open' : ''}><summary><span>${i < state.story.chapter ? '&#10003;' : String(i + 1).padStart(2, '0')}</span>${esc(c.title)}</summary><p class="dialogue">${esc(c.line)}</p><p>${esc(c.lesson)}</p>${button("Replay this lesson", "replayChapter", `data-id="${i}"`, false, "secondary")}</details>`).join('')}`;
            }
        }
        else if (panel === 'customer') {
            let n = panelCtx, rOrder = state.orders.find(o => o.npc === n.id);
            title = n.name;
            sub = (MZNeighbourhood.districts.find(d=>d.id===n.district)?.name||'NEIGHBOURHOOD')+' / CUSTOMER';
            let watch = world.police.some(p => Math.hypot(p.x - state.player.x, p.z - state.player.z) < 11);
            html = `<p class="dialogue">"${n.greeting}"</p>${watch ? '<p class="panel-note">A patrol is nearby. A deal here adds extra attention in this game.</p>' : ''}`;
            if(n.favourite)html+=`<p class="panel-note">Favourite: <b>${RECIPES[n.favourite].name}</b> pays 10% more in direct trades. All your finished blends can be offered.</p>`;
            if (n.id === 'musa' && state.recovery.active)
                html += `<div class="order-card"><span class="tag">NANDI'S GROCERIES</span><h3>A neighbourhood delivery</h3><p>No stock is needed. You are carrying the parcel from Sunset Spaza.</p>${button('Hand over groceries / earn R75', 'completeOddJob', '', false, 'primary wide')}</div>`;
            if (rOrder) {
                let r = RECIPES[rOrder.recipe], ready = state.products[rOrder.recipe] >= rOrder.qty;
                html += `<div class="order-card"><span class="eyebrow">WAITING ORDER</span><div class="row" style="margin-top:12px"><h3>${rOrder.qty} &times; ${r.name}</h3><span class="payment">${money(rOrder.pay)}</span></div><p>Your stock: ${state.products[rOrder.recipe]} / ${rOrder.qty} required</p>${button(ready ? 'Deliver order for ' + money(rOrder.pay) : 'Bring the required stock', 'deliver', `data-id="${rOrder.id}"`, !ready || state.sim < n.cooldown, 'primary wide')}</div>`;
            }
            let available = Object.entries(RECIPES).filter(([id]) => state.products[id] > 0);
            if (available.length && state.sim >= n.cooldown) {
                html += `<h3 style="margin-top:23px">Make a street sale</h3><p>Set your offer. A higher asking price pays more, but the customer may decline.</p><label class="field">Product<select id="tradeProduct">${available.map(([id, r]) => `<option value="${id}">${r.name} (${state.products[id]} in stock)</option>`).join('')}</select></label><label class="field">Quantity<select id="tradeQty">${Array.from({ length: Math.min(5, state.products[available[0][0]]) }, (_, i) => `<option value="${i + 1}">${i + 1} pack${i ? 's' : ''}</option>`).join('')}</select></label><label class="field">Asking price <input id="tradePrice" type="range" min="85" max="130" value="100" step="5"></label><div class="row"><span id="tradeChance" style="font-size:11px;color:var(--mint)"></span><strong class="cost" id="tradeTotal" style="color:var(--amber)"></strong></div>${button('Offer deal', 'sell', '', false, 'primary wide')}`;
            }
            else if (state.sim < n.cooldown)
                html += '<p>Give me a few seconds on the street before the next deal. Close this panel to let time pass.</p>';
            else
                html += '<p class="panel-note">You have no finished stock. Make a batch at your mixing bench, then return.</p>';
        }
        else if (panel === 'property') {
            title = 'Workshop 02';
            sub = state.workshop ? 'YOUR NEXT CHAPTER / OWNED' : 'PROPERTY OPPORTUNITY / SUNDOWN BAY';
            html = `<p class="dialogue">"More space. More possibilities. Make it yours."</p><div class="split-stat"><div class="stat"><span>EXTRA PLANTERS</span><strong>+2</strong></div><div class="stat"><span>MIXING SLOT</span><strong>+1</strong></div><div class="stat"><span>DELIVERY DESK</span><strong>Yes</strong></div></div><p>The shutter opens after purchase. Your two extra planters are at home; the new mixing line and delivery desk are inside this workshop.</p>${state.workshop ? '<p class="panel-note">You own Workshop 02. Walk inside through the open shutter.</p>' : button('Buy Workshop 02 - R 1 600', 'property', '', !canAfford(1600), 'primary wide')}`;
        }
        else if (panel === 'runner') {
            title = 'The dispatch desk';
            sub = 'WORKSHOP 02 / YOUR FIRST TEAMMATE';
            html = `<p class="dialogue">"You handle the blends. I will handle the deliveries."</p><p>Your runner automatically sells up to two finished packs every 25 seconds at 85% of their normal street value. Stock comes from your shared backpack. Reserved order stock is protected unless you turn reservation off. No spare stock means no delivery.</p><div class="split-stat"><div class="stat"><span>TEAM STATUS</span><strong style="font-size:17px">${state.runner ? 'ON THE JOB' : 'NOT HIRED'}</strong></div><div class="stat"><span>READY STOCK</span><strong>${productCount()}</strong></div><div class="stat"><span>COMMISSION</span><strong>15%</strong></div></div>${state.runner ? '<p class="panel-note">Your runner works during street play and production screens. Keep spare stock above the quantities reserved for phone orders.</p>' : button('Hire delivery runner - R 650', 'runner', '', !canAfford(650), 'primary wide')}`;
            if (state.runner)
                html += `<div class="lesson-box"><div class="row"><h3>Kabelo's shift</h3><span class="tag">${state.runnerActive ? 'WORKING' : 'PAUSED'}</span></div><p>Spare packs available: ${Object.keys(RECIPES).reduce((n, k) => n + spareStock(k), 0)}. Runner packs sold: ${state.stats.runnerSales}.</p><div class="grid">${button(state.runnerActive ? 'Pause runner' : 'Resume runner', 'toggleRunner', '', false, 'secondary')}${button(state.reserveOrders ? 'Order protection: ON' : 'Order protection: OFF', 'toggleReserve', '', false, 'secondary')}</div></div>`;
        }
        else if (panel === 'food') {
            title = panelCtx?.id==='bayFood'?'Bayfront cafe':'Braai & Chill';
            sub = 'THABO / A NEIGHBOURHOOD BREAK';
            html = `<p class="dialogue">"Take a seat, my friend. A proper break goes a long way."</p><p>A quick meal restores 25 health and your stamina, and reduces attention by 6 points. Purely a game effect.</p>${button('Grab a plate - R 25', 'food', '', !canAfford(25), 'primary wide')}`;
        }
        else if (panel === 'bed') {
            title = 'Call it a night';
            sub = 'YOUR YARD / A FRESH START';
            html = `<p>Rest until 07:00 the next morning. Health returns to 100 for free. Your plants and current batches will finish. Attention returns to zero. Orders remain available.</p><div class="split-stat"><div class="stat"><span>DAY</span><strong>${state.day}</strong></div><div class="stat"><span>CASH</span><strong>${money(state.cash)}</strong></div><div class="stat"><span>SALES SO FAR</span><strong>${money(state.totalRevenue)}</strong></div></div>${button('Sleep until morning', 'sleep', '', false, 'primary wide')}`;
        }
        else if (panel === 'taxi') {
            title = 'Sundown Taxi Rank';
            sub = 'BONGANI / LOCAL RUNS';
            html = `<p class="dialogue">"Where to, neighbour?"</p><p>Catch a quick ride to a familiar corner of Sundown Bay. Each ride costs R 20.</p><div class="grid">${[['home', 'Your yard'], ['spaza', 'Sunset Spaza'], ['shop', 'Workshop 02'], ['square', 'Sunset Square'],['market','Masakhane Market'],['bayfront','Bayfront Walk'],['heights','Jacaranda Heights'],['enterprise','Enterprise Quarter'],['commons','Riverside Commons'],['harbour','Harbour Works'],['nightlife','After Hours / casino & garage']].map(([id, n]) => `<div class="card"><h3>${n}</h3>${button('Ride for R 20', 'ride', `data-id="${id}"`, !canAfford(20), 'primary')}</div>`).join('')}</div>`;
        }
        else if (panel === 'map') {
            title = 'Sundown Bay';
            sub = 'NEIGHBOURHOOD MAP / CLICK A MARKER TO TRACK';
            html = MZAtlas.panel(world,esc,atlasZoom,atlasLayer,atlasQuery);
        }
        else if (panel === 'pause') {
            title = 'Take a breather';
            sub = 'PAUSED / MZANSI AFTER HOURS';
            html = `<div class="split-stat"><div class="stat"><span>DAY</span><strong>${state.day}</strong></div><div class="stat"><span>CASH</span><strong>${money(state.cash)}</strong></div><div class="stat"><span>REPUTATION</span><strong>${state.rep}</strong></div></div><div class="grid">${button('Back to the street', 'resume', '', false, 'primary')}${button('Save progress', 'save', '', false, 'secondary')}${button('Export save file', 'export', '', false, 'secondary')}${button('Controls & about', 'help', '', false, 'secondary')}</div><div style="margin-top:20px"><label class="field">Sound effects<input type="checkbox" id="soundSetting" ${state.settings.sound ? 'checked' : ''}></label><label class="field">Head movement<input type="checkbox" id="bobSetting" ${state.settings.headbob ? 'checked' : ''}></label><label class="field">Mouse sensitivity<input id="sensitivitySetting" type="range" min="0.3" max="2.5" step=".1" value="${state.settings.sensitivity}"></label><label class="field">Graphics<select id="qualitySetting"><option value="0" ${state.settings.quality === 0 ? 'selected' : ''}>Performance</option><option value="1" ${state.settings.quality === 1 ? 'selected' : ''}>Balanced</option><option value="2" ${state.settings.quality === 2 ? 'selected' : ''}>Sharp</option></select></label></div><div class="row" style="margin-top:20px">${button('Sandbox tools [F2]', 'dev', '', false, 'secondary')}${button('Start a new game', 'newConfirm', '', false, 'danger-btn')}</div><p class="export-note">Autosaves use this browser on this device. Export a save before changing computers, browser profiles, or the HTML filename.</p><label class="field">Import save <input class="file-input" id="importSave" type="file" accept=".json,application/json"></label>`;
            html += `<div class="settings-extra"><label class="field">Touch controls<select id="touchSetting"><option value="auto" ${state.settings.mobileControls === 'auto' ? 'selected' : ''}>Automatic</option><option value="on" ${state.settings.mobileControls === 'on' ? 'selected' : ''}>Always on</option><option value="off" ${state.settings.mobileControls === 'off' ? 'selected' : ''}>Off / keyboard</option></select></label><label class="field">Touch look sensitivity<input id="touchSensitivitySetting" type="range" min=".4" max="2" step=".1" value="${state.settings.touchSensitivity}"></label><label class="field">Frame rate<select id="fpsSetting"><option value="30" ${state.settings.maxFps === 30 ? 'selected' : ''}>30 / battery saver</option><option value="60" ${state.settings.maxFps === 60 ? 'selected' : ''}>60 / smooth</option></select></label><div class="grid">${button('Fullscreen', 'fullscreen', '', false, 'secondary')}${button('What do I do now?', 'readChapter', '', false, 'secondary')}${button('I am stuck / return home', 'unstuck', '', false, 'secondary')}${button('Export diagnostics', 'diagnostics', '', false, 'secondary')}</div></div>`;
            html += `<div class="settings-extra"><h3>Read at your pace</h3><label class="field">Notification duration<select id="tipsSetting">${[[8,'8 seconds'],[16,'16 seconds'],[30,'30 seconds'],[0,'Until I dismiss them']].map(([v,t])=>`<option value="${v}" ${state.settings.tipSeconds===v?'selected':''}>${t}</option>`).join('')}</select></label><label class="field">Pin current instructions<input id="pinSetting" type="checkbox" ${state.settings.guidePinned?'checked':''}></label><div class="grid">${button('Replay tutorial lessons','replayConfirm','',false,'secondary')}${button('Recent notifications','notices','',false,'secondary')}</div><p class="export-note">Teaching panels always wait for you. This duration changes small notifications only.</p></div>`;
        }
        else if(panel==='notices') {
            title='Your recent messages';sub='NOTIFICATION HISTORY / THIS PLAY SESSION';
            html=noticeLog.length?noticeLog.map(n=>`<div class="order-card"><small>DAY ${n.day}</small><p>${esc(n.text)}</p></div>`).join(''):'<p>No notifications yet. Your story lessons are in Phone &gt; Story.</p>';
        }
        else if(panel==='replayConfirm') {
            title='Replay from the beginning?';sub='LESSONS ONLY / YOUR PROGRESS IS SAFE';
            html='<p>This reopens the first tutorial lesson. It does not reset your cash, inventory, objectives, property or story rewards. Replay other chapters through your phone journal.</p>'+button('Read the first lesson','replayStart','',false,'primary wide')+button('Back to menu','pause','',false,'secondary wide');
        }
        else if (panel === 'importConfirm') {
            title = 'Load this saved story?';
            sub = 'SAVE IMPORT / CONFIRM REPLACEMENT';
            html = `<p>Your current progress will be replaced by this file. Your current local save is backed up first when storage is available.</p><div class="split-stat"><div class="stat"><span>DAY</span><strong>${pendingImport?.day || 1}</strong></div><div class="stat"><span>CASH</span><strong>${money(pendingImport?.cash || 0)}</strong></div><div class="stat"><span>CHAPTER</span><strong>${(pendingImport?.story.chapter || 0) + 1}</strong></div></div>${button('Export current game first', 'export', '', false, 'secondary wide')}${button('Load imported save', 'confirmImport', '', false, 'primary wide')}${button('Cancel', 'cancelImport', '', false, 'secondary wide')}`;
        }
        else if (panel === 'rideShop' || panel === 'garage') {
            const shop=panel==='rideShop';title=shop?'Ubuntu Wheels':'My rides';sub=shop?'TUMI / BUY ONCE. KEEP IT.':'OWNED RIDES / AVAILABLE FROM YOUR BACKPACK';
            html=`<div class="ride-intro"><div><span class="eyebrow">${shop?'YOUR NEIGHBOURHOOD RIDE SHOP':'YOUR PERSONAL GARAGE'}</span><h3>${shop?'Make the journey yours.':'Pick your way through the bay.'}</h3><p>${shop?'Browse the display outside Sunset Spaza. All purchases use money earned in this game.':'Choose an owned ride, close this panel and mount outside. Your rides are not lost in traffic accidents.'}</p></div><strong>${money(state.cash)}</strong></div>`;
            if(!shop)html+=button('Find Ubuntu Wheels on the map','track','data-id="rideShop"',false,'secondary wide');
            html+=`<div class="ride-grid">${Object.entries(MZMobility.RIDES).filter(([id,r])=>!shop||!r.car).map(([id,r])=>{
                const owned=state.rides.owned[id],selected=state.rides.equipped===id;
                return `<article class="ride-card ${selected?'selected':''}"><div class="ride-art"><img src="${world.ridePreviews[id]}" alt="${r.kind}"><span>${owned?(selected?'SELECTED':'OWNED'):r.kind.toUpperCase()}</span></div><div class="ride-copy"><div class="eyebrow">${r.kind}</div><h3>${r.name}</h3><p>${r.description}</p><div class="ride-spec"><span>TOP SPEED</span><strong>${Math.round(r.maxSpeed*3.6)} km/h</strong></div>${owned?button(selected?'Selected / close & mount':'Select this ride','chooseRide',`data-id="${id}"`,selected,'secondary wide'):shop?button('Buy / '+money(r.price),'buyRide',`data-id="${id}"`,!canAfford(r.price),'primary wide'):button(r.car?'Available at Ubuntu Motors':'Available at Ubuntu Wheels','track',`data-id="${r.car?'carShop':'rideShop'}"`,false,'secondary wide')}</div></article>`;
            }).join('')}</div>`;
            if(shop)html+=`<h3 class="section-heading">Look after yourself</h3><div class="grid"><div class="card"><span class="tag">TRAFFIC PROTECTION</span><h3>Rider helmet</h3><p>Reduces traffic damage by 35% while riding. Equips automatically and never breaks.</p>${button(state.rides.helmet?'Helmet owned':'Buy helmet / R 120','buyHelmet','',state.rides.helmet||!canAfford(120),'secondary')}</div><div class="card"><span class="tag">HEALTH +45</span><h3>First-aid kit</h3><p>Carry a kit for later. You currently have ${state.medkits}. Maximum 99 kits.</p>${button('Buy first-aid kit / R 45','buyMedkit','',state.medkits>=99||!canAfford(45),'secondary')}</div></div>`;
            html+=`<p class="panel-note">${touch?.enabled?'Use the joystick to accelerate and steer. Pull back to brake. Tap RIDE to mount or get off.':'Press V to mount or get off. W accelerates, A/D steer, mouse looks independently; S brakes; Space jumps (handbrake in cars). Shift gives your top speed.'} Riding inside your yard or workshop is disabled. Menus stop your ride safely.</p><div class="grid">${button('Riding instructions','rideLesson','',false,'secondary')}${button('Back to the street','resume','',false,'primary')}</div>`;
        }
        else if(['rideLesson','trafficLesson'].includes(panel)){
            const road=panel==='trafficLesson';title=road?'Watch the traffic':'Your first ride';sub='PAUSED / READ UNTIL YOU ARE READY';
            html=`<div class="story-speaker"><img class="portrait" src="${world.portraitFor('Tumi')}" alt="Tumi"><div><div class="eyebrow">TUMI / UBUNTU WHEELS</div><h3>${road?'The roads are shared.':'A little further, a little faster.'}</h3></div></div><p class="story-quote">${road?'A moving car can hurt you. Keep an eye on your health and use the pavements when walking.':'These are your wheels now. They stay in your garage, even after you close the game.'}</p><div class="lesson-box"><h3>${road?'Health and recovery':'How to ride'}</h3><p>${road?'The health bar starts at 100. Traffic hits lower it and knock you off your ride. A short damage cooldown prevents repeated hits every frame. First aid restores 45 health, a meal restores 25, and sleeping in your own bed restores full health for free.':touch?.enabled?'Choose a ride in My rides. Step outside and tap RIDE. Push the joystick forward to accelerate and sideways to steer; pull it back to brake. Swipe to look and turn. Hold PUSH / PEDAL / GO for top speed. Tap OFF to dismount.':'Choose a ride in My rides. Step outside and press V. Hold W to accelerate. A / D and the mouse turn your ride. Press S to brake; Space to jump (handbrake in cars); Shift gives top speed. Press V again to get off.'}</p></div><div class="lesson-box"><h3>${road?'A second chance':'Slow down before crossing'}</h3><p>${road?'At zero health, neighbours bring you home with 60 health. Transport costs up to R60, never more than you have. You keep your stock, story progress and all owned rides. Sleep to finish recovering.':'Releasing the throttle slows you gradually. Opening a menu stops you immediately. You cannot ride inside your yard or workshop. A helmet from Ubuntu Wheels reduces traffic damage while riding.'}</p></div>${button('I understand / continue','resume','',false,'primary wide')}`;
        }
        else if(panel==='health'){
            title='Health & first aid';sub='LOOK AFTER YOURSELF';
            html=`<div class="health-summary"><span aria-hidden="true">&#9829;</span><strong>${state.health}<small>/100</small></strong><p>${state.health<25?'Low health. Take a break before crossing a road.':'A little care goes a long way.'}</p></div><div class="grid"><div class="card"><h3>First-aid kits: ${state.medkits}</h3><p>Restore up to 45 health. A kit is only consumed when you need healing.</p>${button('Use first-aid kit','useMedkit','',state.medkits<1||state.health>=100,'primary')}</div><div class="card"><h3>Free recovery at home</h3><p>Sleep in your own bed to recover to 100 health. Meals at Braai & Chill restore 25 health for R25.</p>${button('Track my bed','track','data-id="bed"',false,'secondary')}</div></div>${button('Find supplies at Ubuntu Wheels','track','data-id="rideShop"',false,'secondary wide')}${button('Read traffic lesson','trafficLesson','',false,'secondary wide')}`;
        }
        else if(panel==='injury'){
            title='Your neighbours brought you home';sub='RECOVERED / YOUR STORY CONTINUES';
            html=`<div class="health-summary"><span>&#9829;</span><strong>60<small>/100</small></strong><p>Rest up. Your money, stock and rides have not been reset.</p></div><p>Your transport home cost ${money(injuryFee)}. You never go into debt. Your owned rides are in My rides. You have a few seconds of protection after recovery.</p><p class="panel-note">Your bed is free. Sleep to restore full health, or use a first-aid kit now.</p><div class="grid">${button('Track my bed','track','data-id="bed"',false,'secondary')}${button('Continue from home','resume','',false,'primary')}</div>`;
        }
        else if(panel==='saveCenter'){
            title='Your progress on this browser';sub=device.profile.id+' / LOCAL PROFILE';
            const stamp=state.meta.savedAt;
            html=`<div class="save-overview"><span class="save-dot ${storageWarning||!device.available?'warning':''}"></span><div><h3>${storageWarning||!device.available?'Browser saving is blocked':'Automatic saving is on'}</h3><p>${stamp?'Last saved: '+esc(new Date(stamp).toLocaleString()):'Your first save is created when you start playing.'}</p></div></div><div class="split-stat"><div class="stat"><span>CASH SAVED</span><strong>${money(state.cash)}</strong></div><div class="stat"><span>DAY</span><strong>${state.day}</strong></div><div class="stat"><span>OWNED RIDES</span><strong>${Object.values(state.rides.owned).filter(Boolean).length}</strong></div></div><p>Return with the <strong>same browser and the same game address</strong> and choose Continue. Money, stock, purchases, health, story and control preference are remembered. A local random profile identifies this browser only; it does not track your physical device.</p><p class="panel-note">This is not cloud saving. A different phone, another browser, private browsing, cleared site data, or a renamed HTML file may not contain this save. Export your JSON backup before changing files, addresses or devices.</p><div class="grid">${button('Save now','save','',!started,'primary')}${button('Export backup file','export','',false,'secondary')}${button(device.persisted?'Storage protection enabled':'Ask browser to protect save','protectSave','',device.persisted,'secondary')}${button('Back','resume','',false,'secondary')}</div><p class="export-note">Browser storage protection reduces automatic eviction when supported. It cannot prevent deliberate data clearing and is not a substitute for an exported backup.</p><label class="field">Import v1 through v11 save<input class="file-input" id="importSave" type="file" accept=".json,application/json"></label>`;
        }
        else if(panel==='saveConflict'){
            title='A newer save is open in another tab';sub='PAUSED TO PROTECT YOUR PROGRESS';
            html=`<p>This tab has stopped writing because another game tab saved more recently. Close the other tab, then load its latest progress here. Exporting this session lets you keep a separate backup before switching.</p><div class="grid">${button('Load latest saved progress','loadLatest','',false,'primary')}${button('Export this session instead','export','',false,'secondary')}</div>`;
        }
        else if (panel === 'help') {
            title = 'Welcome to Sundown Bay';
            sub = 'CONTROLS / DESKTOP & MOBILE / V11.0.0';
            html = `<p>Grow fictional Glowleaf, mix imaginary products, fulfil orders, manage attention, and expand from your back room into a workshop. This is an original South African-inspired neighbourhood, not a recreation of a real city.</p>${[['Left touch stick', 'Walk on mobile'], ['Swipe right side', 'Look on mobile'], ['USE / RUN', 'Interact / hold to sprint'], ['W A S D', 'Walk'], ['Mouse / drag', 'Look around'], ['Arrow keys', 'Forward / back / turn (mouse-free option)'], ['Shift', 'Sprint'], ['E', 'Interact / close a panel'], ['P / I / M', 'Phone / backpack / map'], ['Space', 'Jump / car handbrake / bench timing'], ['Esc', 'Release mouse / menu / close panel'], ['F2', 'Optional sandbox tools']].map(([k, v]) => `<div class="control-row"><kbd>${k}</kbd><span>${v}</span></div>`).join('')}<p class="panel-note" style="margin-top:21px">Follow the gold marker for the story. Watch your phone for orders. Raw supplies and finished products are separate; recipes consume raw supplies. Your first supplies are free.</p><p>Police react to witnessed deals, warn players, pursue visible suspects, and search a last-seen area. Cooperating with a warning costs up to R75. A pursuit stop costs up to R180 and some finished stock. These are fictional game penalties; no combat is included.</p><p style="font-size:11px">All products, ingredients, effects, recipes, and trading rules are invented. No real drug-production instructions are included. Solo play works offline; optional two-player co-op requires the included server. No real-money purchases or external art downloads. Optional first-party play statistics require an enabled shared server and player consent. It is not affiliated with Schedule I or TVGS.</p>${button(started ? 'Back to the street' : 'Back to the title', 'resume', '', false, 'primary wide')}`;
        }
        else if (panel === 'dev') {
            title = 'Sandbox tools';
            sub = 'OPTIONAL / TEST THE GAME YOUR WAY';
            html = `<p>These are optional cheats for exploring the game. They change your saved game. Use Export save first to keep an untouched playthrough.</p><div class="grid">${[['cash', 'Add R 5 000'], ['supplies', 'Add raw supplies'], ['packs', 'Add finished products'], ['rep', 'Add 20 reputation'], ['finish', 'Finish plants & batches'], ['heat', 'Trigger a patrol chase'], ['clear', 'Clear attention'], ['home', 'Return to your yard']].map(([id, n]) => button(n, 'cheat', `data-id="${id}"`, false, 'secondary')).join('')}</div>`;
        }
        else if (panel === 'newConfirm') {
            title = 'Start a new story?';
            sub = 'REPLACE YOUR CURRENT LOCAL SAVE';
            html = `<p>This replaces your current game in this browser. An exported save file can be imported later.</p>${started ? button('Export current save first', 'export', '', false, 'secondary wide') : ''}${button('Start fresh with R 2 500', 'reset', '', false, 'primary wide')}${button('Keep my current game', 'resume', '', false, 'secondary wide')}`;
        }
        else if (panel === 'victory') {
            title = 'From your yard to your own name';
            sub = 'STORY GOAL COMPLETE / FREE PLAY CONTINUES';
            html = `<div class="big-success"><div class="success-seal">&#10022;</div><h3>You made it, neighbour.</h3><p>You own a workshop, have a delivery runner, and have brought in ${money(state.totalRevenue)} in lifetime sales.</p></div><div class="split-stat"><div class="stat"><span>DAY</span><strong>${state.day}</strong></div><div class="stat"><span>REPUTATION</span><strong>${state.rep}</strong></div><div class="stat"><span>BATCHES</span><strong>${state.stats.crafted}</strong></div></div>${button('Keep building your story', 'resume', '', false, 'primary wide')}`;
        }
        if(panel==='pause')html=`<div class="mode-card"><div><span class="eyebrow">CURRENT PLAY MODE</span><h3>${isFreeMode()?'FREE ROAM':'STORY MODE'}</h3><p>Switch without resetting your progress.</p></div>${button(isFreeMode()?'Switch to Story':'Switch to Free Roam','changePlayMode',`data-id="${isFreeMode()?'story':'free'}"`,false,'secondary')}</div>`+html;
        if(panel==='map')html=`<div class="grid map-actions">${button('Explore districts','districts','',false,'secondary')}${button('Find any customer','contacts','',false,'secondary')}${button('Clear marker','clearTrack','',false,'secondary')}</div>`+html;
        if(panel==='phone'&&phoneTab==='orders')html=`<label class="field">Optional new orders<input type="checkbox" id="receiveOrders" ${state.settings.receiveOrders?'checked':''}></label>`+html;
        if(panel==='shop')html+=`<div class="card" style="margin-top:18px"><h3>First-aid kit / +45 health</h3><p>You have ${state.medkits}. Use from Health or press B.</p>${button('Buy first aid / R45','buyMedkit','',!canAfford(45)||state.medkits>=99,'secondary')}</div>`;
        if(panel==='inventory')html+=`<div class="grid" style="margin-top:20px">${button('My rides [G]','garage','',false,'secondary')}${button('Health & first aid','health','',false,'secondary')}</div>`;
        if(panel==='pause')html=`<div class="grid utility-grid">${button('My rides [G]','garage','',false,'secondary')}${button('Health & first aid','health','',false,'secondary')}${button('Saved progress & backups','saveCenter','',false,'secondary')}${button('Visit Ubuntu Wheels','track','data-id="rideShop"',false,'secondary')}</div>`+html;
        if(panel==='map')html=button('Track Ubuntu Wheels / ride shop','track','data-id="rideShop"',false,'secondary wide')+html;
        if(['customer','shop','upgrades','runner','food','rideShop'].includes(panel)){
            const name=panel==='customer'?panelCtx.name:({shop:'Nandi',upgrades:'Aadil',runner:'Kabelo',food:'Thabo',rideShop:'Tumi'})[panel];
            html=`<div class="npc-strip"><img src="${world.portraitFor(name)}" alt="${esc(name)}"><div><small>SUNDOWN BAY / YOUR NEIGHBOURS</small><strong>${esc(name)}</strong></div></div>`+html;
        }
        const lifeContext={s:state,ctx:panelCtx,button,esc,money,started,draft:craftingDraft,variety:growVariety,historyCategory,remoteStats,statsError};
        const lifePanel=MZLifePanels.render(panel,lifeContext);
        if(lifePanel){({title,sub,html,foot}=lifePanel);}
        if(panel==='phone'&&['bank','careers','businesses'].includes(phoneTab)){const content=MZCommercePanels.render(phoneTab,{s:state,ctx:panelCtx,button,esc,money,bankTab,bizFilter,coop:coop.active});html='<div class="phone-commerce">'+content.html+'</div>';}
        if(panel==='phone'){
            title=phoneTab==='home'?'Sundown Mobile':({orders:'Orders',contacts:'Contacts',history:'History',story:'Journal',bank:'Ubuntu Banking',careers:'Jobs',businesses:'Businesses'})[phoneTab]||'Sundown Mobile';
            sub='YOUR POCKET / YOUR BUSINESS';html=MZLifePanels.phone(phoneTab,state,html,lifeContext);
        }
        if(['pause','freeGuide','bench'].includes(panel))html=`<div class="handbook-link">${button('Handbook / clearer step-by-step help','guideHub','',false,'secondary wide')}${panel==='pause'?button('Screen, fullscreen & accessibility','launcherSettings','',false,'secondary wide'):''}</div>`+html;
        if(panel==='food'&&panelCtx?.id!=='bayFood')html=button('Go inside the restaurant','track','data-id="restaurant"',false,'primary wide')+html;
        const travelPanel=MZTravelPanels.render(panel,{s:state,world,esc,money,button,coop});
        if(travelPanel)({title,sub,html,foot}=travelPanel);
        if(panel==='pause')html=button('Play with a friend / co-op room','coop','',false,'primary wide')+html;
        if(panel==='garage')html=button('Visit Ubuntu Motors / buy a car','track','data-id="carShop"',false,'primary wide')+html;
        if(panel==='phone'&&phoneTab==='home')html+=`<button class="primary wide" data-action="coop">Play with a friend</button>`;
        if(panel==='rideLesson')html=`<div class="lesson-box"><h3>Jump, brake and drive</h3><p>On foot, skateboard, bicycle or scooter: press SPACE or tap JUMP. S brakes a ride; Space remains the mixing timing button while a bench is open.</p><p>Cars: W goes forward, S brakes then reverses, A/D steer, SPACE is the handbrake. On mobile use the stick and hold BRAKE. Cars do not jump on command. Your speed is shown in km/h. V or OFF gets out.</p></div>`+html;
        if(panel==='phone'&&phoneTab==='home')html+=button('Activities / explore Sundown South','activities','',false,'secondary wide');
        if(['pause','freeGuide','districts'].includes(panel))html=button('New places & activities','activities','',false,'primary wide')+html;
        if(panel==='garage'||panel==='launcherSettings')html=button('Driving setup / surface & grip','drivingSetup','',false,'secondary wide')+button('Driving camera / look controls','cameraSettings','',false,'secondary wide')+html;
        if(panel==='rideLesson')html='<div class="lesson-box"><h3>Free-look car camera</h3><p>Move your mouse or swipe empty world space to look around the car. Drive with W/S and A/D or the joystick. Press C or tap the reset-view arrow to look forward again. T sounds the horn.</p></div>'+html;
        const outdoor=MZOutdoorPanels.render(panel,{s:state,ctx:panelCtx,w:world,button,esc,money,shotBusy:realTime-lastShot<1.8});
        if(outdoor)({title,sub,html,foot}=outdoor);
        const commerce=MZCommercePanels.render(panel,{s:state,ctx:panelCtx,button,esc,money,bankTab,bizFilter,coop:coop.active});
        if(commerce)({title,sub,html,foot}=commerce);
        if(['pause','freeGuide','guideHub'].includes(panel))html=button('Everyday life / jobs, businesses & banking','commercePage','data-page="commerceGuide"',false,'primary wide')+html;
        if(panel==='phone'&&phoneTab==='home'&&state.enterprise.work)html=button('Continue work ticket / '+MZCommerceData.byId[state.enterprise.work.biz].name,'commercePage','data-page="workstation"',false,'secondary wide commerce-pinned-work')+html;
        const cityPanel=MZNightPanels.render(panel,{s:state,ctx:panelCtx,ui:cityUi,button,esc,money,w:world,coop:coop.active});
        if(cityPanel)({title,sub,html,foot}=cityPanel);
        const cityLinks=`<div class="v11-links">${button('Work or open a business','cityOpen','data-page="careerChoice"',false,'secondary')}${button('Bank applications','cityOpen','data-page="bankApplications"',false,'secondary')}${button('Casino & bar','cityOpen','data-page="casino"',false,'secondary')}${button('Custom Works / garage','cityOpen','data-page="partsGarage"',false,'secondary')}${button('Leaf Lounge','cityOpen','data-page="leafShop"',false,'secondary')}${button('Retail inventory','cityOpen','data-page="retailBag"',false,'secondary')}</div>`;
        if(['pause','freeGuide'].includes(panel)||(panel==='phone'&&phoneTab==='home'))html=cityLinks+html;
        if(panel==='garage')html=button('Custom Works / engines and removable parts','cityOpen','data-page="partsGarage"',false,'primary wide')+html;
        if(panel==='bank'||(panel==='phone'&&phoneTab==='bank'))html=button('Business applications & loan','cityOpen','data-page="bankApplications"',false,'primary wide')+html;
        if(panel==='businessConfirm'){
            const bid=panelCtx?.businessId||panelCtx?.id,approval=state.cityLife.career.applications.find(a=>a.id===state.cityLife.career.approvals[bid]&&a.status==='approved');
            html=`<div class="panel-note">${approval?'BANK APPROVED / Pay '+money(approval.contribution)+' from Current; restricted loan '+money(approval.loan)+' + fee '+money(approval.fee)+'.':'BANK REVIEW REQUIRED / Apply at the branch before signing. Existing businesses remain yours.'}</div>`+button('View bank applications','cityOpen',`data-page="bankApplications" data-id="${bid}"`,false,'secondary wide')+html;
        }
        $('closeModal').disabled=['saveConflict','policeStop'].includes(panel);
        $('modal').dataset.panel=panel;
        $('modalTitle').textContent = title;
        $('modalSub').textContent = sub;
        $('modalBody').innerHTML = html;
        if(panel==='partsGarage')cityPreview();
        const teaching = ['chapter','mentor','lesson','rideLesson','trafficLesson','freeGuide','guideTopic'].includes(panel);
        $('modalFoot').textContent = teaching ? 'PAUSED / READ AT YOUR OWN PACE' : (coop.active?'LIVE CO-OP / ':(paused ? 'PAUSED / ' : 'LIVE PRODUCTION / ')) + (touch?.enabled ? 'Tap the close button to return.' : foot);
        $('modalFoot').classList.toggle('teaching-footer', teaching);
        // Keep the navigation visible even when a phone lesson needs scrolling.
        if (teaching) {
            let actions = $('modalBody').querySelector('.lesson-actions');
            if (!actions) {
                const next = $('modalBody').querySelector('[data-action="lessonNext"], [data-action="resume"]');
                if (next) {
                    actions = document.createElement('div'); actions.className = 'lesson-actions';
                    next.classList.remove('wide'); actions.append(next);
                }
            }
            if (actions) $('modalFoot').prepend(actions);
        }
        if(panel==='phone'){
            $('modalFoot').innerHTML=`<nav class="phone-dock" aria-label="Phone apps">${[['home','Home','home'],['orders','Orders','phone'],['contacts','People','person'],['history','History','clock'],['story','Journal','bag']].map(([id,t,icon])=>`<button data-action="phoneTab" data-id="${id}" aria-pressed="${phoneTab===id}">${MZGuide.svg(icon)}<span>${t}</span></button>`).join('')}</nav><div class="phone-home-indicator"></div>`;
        }
        if(panel==='workstation'){const actions=$('modalBody').querySelector('.work-actions');if(actions)$('modalFoot').prepend(actions);}
        if (panel === 'customer')
            updateTrade();
        if (panel === 'map')
            drawMap($('largeMap'), true);
        updatePanelTimers();
    }
    function refresh() { if (!panel)
        return; let y = $('modalBody').scrollTop; renderPanel(); $('modalBody').scrollTop = y; refreshQueued = false; }
    function updateTrade(resetQty = false) {
        const prod = $('tradeProduct'), qty = $('tradeQty'), price = $('tradePrice');
        if (!prod || !qty || !price || panel !== 'customer') return;
        let id = prod.value;
        // A stale selection must never crash the game after stock changes.
        if (!Object.hasOwn(RECIPES, id) || state.products[id] < 1) {
            id = Array.from(prod.options).map(o => o.value)
                .find(k => Object.hasOwn(RECIPES, k) && state.products[k] > 0);
            if (!id) { refreshQueued = true; return; }
            prod.value = id;
            resetQty = true;
        }
        if (resetQty) qty.innerHTML = Array.from({length: Math.min(5, state.products[id])},
            (_, i) => `<option value="${i + 1}">${i + 1} pack${i ? 's' : ''}</option>`).join('');
        const quantity = clamp(Number(qty.value) || 1, 1, Math.min(5, state.products[id]));
        const mult = clamp((Number(price.value) || 100) / 100, .85, 1.3);
        const pay = Math.round(MZNeighbourhood.streetValue(RECIPES[id],panelCtx) * quantity * mult);
        $('tradeTotal').textContent = money(pay);
        $('tradeChance').textContent = Math.round(saleChance(mult) * 100) + '% chance of acceptance';
    }
    function saleChance(mult) { return clamp(.98 - Math.max(0, mult - 1) * 1.8 + Math.min(state.rep, 35) * .002, .3, .99); }
    function registerSale(recipe, qty, pay, npc, delivery = false, remote = false) {
        if (!Object.hasOwn(RECIPES, recipe) || !Number.isInteger(qty) || qty < 1 || state.products[recipe] < qty || !Number.isFinite(pay) || pay < 1)
            return false;
        state.products[recipe] -= qty;
        state.cash += Math.round(pay);
        state.totalRevenue += Math.round(pay);
        state.rep += qty;
        state.stats.sales += qty;
        if (delivery)
            state.stats.delivered++;
        if (remote)
            state.stats.runnerSales += qty;
        const nearby = !remote && MZPolice.active(state) && world.police.some(p => MZLife.canSee(world,p,state.player,state,20,true));
        state.heat = clamp(state.heat + (remote ? 2 : nearby ? 26 : 10) + (!remote ? qty * .7 : 0), 0, !isFreeMode() && state.story.chapter <= 10 ? 45 : 100);
        state.lastSale = state.sim;
        if(nearby)MZPolice.witness(world,state);
        MZLife.log(state,'trade',(remote?'Runner delivery':delivery?'Order to '+(npc?.name||'customer'):'Sale to '+(npc?.name||'customer'))+' / '+qty+' '+RECIPES[recipe].name,pay);
        if (npc) {
            npc.cooldown = state.sim + 5;
            state.cooldowns[npc.id] = npc.cooldown;
        }
        storyEvent('sale', { recipe });
        if (delivery)
            storyEvent('delivery', { npc: npc?.id });
        syncStory();
        toast((remote ? 'Kabelo delivered' : delivery ? 'Order delivered' : 'Deal done') + ': ' + qty + ' ' + RECIPES[recipe].name + ' / +' + money(pay));
        if (nearby)
            toast('A nearby patrol noticed the deal. Attention increased.', true);
        sound('cash');
        save();
        refreshQueued = true;
        return true;
    }
    function action(name, data = {}) {
        if(saveConflict&&!['loadLatest','export'].includes(name))return;
        if(['sell','deliver'].includes(name)&&MZPeople.injured(panelCtx||{})){toast('This customer is recovering. Check on them and return shortly.',true);return;}
        if(cityAction(name,data))return;
        if(vehicleAction(name,data))return;
        if(commerceAction(name,data))return;
        if(v8Action(name,data))return;
        if(v7Action(name,data))return;
        if(saveConflict && !['loadLatest','export'].includes(name))return;
        if(name==='cheat'&&(!devUnlocked||!started||panel!=='dev'))return;
        if(lifeAction(name,data))return;
        const beforeActionCash=state.cash;
        if(['freeGuide','districts'].includes(name)){openPanel(name);return;}
        if(name==='contacts'){phoneTab='contacts';contactDistrict='all';openPanel('phone');return;}
        if(name==='districtContacts'&&MZNeighbourhood.districts.some(d=>d.id===data.id)){contactDistrict=data.id;phoneTab='contacts';openPanel('phone');return;}
        if(name==='clearTrack'){state.track=null;save();closePanel(false);return;}
        if(name==='changePlayMode'&&panel==='pause'&&['story','free'].includes(data.id)){openPanel('modeConfirm',{mode:data.id});return;}
        if(name==='setPlayMode'&&panel==='modeConfirm'&&data.id===panelCtx?.mode){
            MZNeighbourhood.setMode(state,data.id);titlePlayMode=data.id;oldQuest=-1;updatePlayModeLabel();closePanel(false);updateHUD();save();maybeBrief();return;
        }
        if(name==='declineOrder'&&panel==='phone'){
            const order=state.orders.find(o=>String(o.id)===String(data.id));
            if(!order||(!isFreeMode()&&order.npc==='sipho'&&!state.story.flags.siphoDelivered))return;
            state.orders=state.orders.filter(o=>o!==order);state.nextOrder=Math.max(state.nextOrder,state.sim+20);save();refresh();return;
        }
        if(['garage','health','saveCenter','rideLesson','trafficLesson'].includes(name)){openPanel(name);return;}
        if(name==='useMedkit'){healWithKit();return;}
        if(name==='protectSave'){device.protect().then(ok=>{toast(ok?'Browser storage protection enabled. Keep an exported backup too.':'The browser did not grant storage protection. Normal saving still works when available.');if(panel==='saveCenter')refresh();});return;}
        if(name==='loadLatest'){saveConflict=false;const latest=load();if(latest){state=latest;titlePlayMode=state.mode;startGame(false);}else openPanel('saveCenter');return;}
        if(saveConflict && name!=='export')return;
        if(name==='lessonNext'){lessonPage=1;renderPanel();$('modalBody').scrollTop=0;return;}
        if(name==='lessonBack'){lessonPage=0;renderPanel();$('modalBody').scrollTop=0;return;}
        if(name==='replayStart'){openPanel('lesson',{index:0});return;}
        if(name==='replayChapter'){openPanel('lesson',{index:Number(data.id)});return;}
        if(['notices','replayConfirm','pause'].includes(name)){openPanel(name);return;}

        let id = data.id;
        // Reject malformed or stale panel actions; UI disabling is not the only guard.
        const allowed = { buyRide:['rideShop','carShop'],chooseRide:['rideShop','garage'],buyHelmet:['rideShop'],buyMedkit:['rideShop','shop'], reset:['newConfirm'], craft: ['bench'], steady: ['bench'], plant: ['grow'], buy: ['shop'], upgrade: ['upgrades'], deliver: ['customer'], sell: ['customer'], property: ['property'], runner: ['runner'], food: ['food'], sleep: ['bed'], ride: ['taxi'], oddJob: ['shop'], completeOddJob: ['customer'], toggleRunner: ['runner'], toggleReserve: ['runner'], confirmImport: ['importConfirm'] };
        if (allowed[name] && !allowed[name].includes(panel))
            return;
        if(name==='buyRide'){
            if(!MZMobility.buyRide(state,id))return;
            stopRide();sound('ready');toast(MZMobility.RIDES[id].name+' purchased. Close the shop, then press V or tap RIDE outside.');refresh();
        }
        else if(name==='chooseRide'){
            if(!Object.hasOwn(state.rides.owned,id)||!state.rides.owned[id])return;
            stopRide(true);state.rides.equipped=id;toast(MZMobility.RIDES[id].name+' selected.');refresh();
        }
        else if(name==='buyHelmet'){
            if(state.rides.helmet||!canAfford(120))return;
            MZLife.pay(state,120);state.rides.helmet=true;toast('Helmet equipped automatically while riding.');sound('ready');refresh();
        }
        else if(name==='buyMedkit'){
            if(!canAfford(45)||state.medkits>=99)return;
            MZLife.pay(state,45);state.medkits++;toast('First-aid kit added. Press B or open Health to use it.');sound();refresh();
        }
        else if (name === 'craft') {
            let r = RECIPES[id];
            if (!r || !MZNeighbourhood.canCraft(state,r) || !requirements(r) || state.jobs.length >= mixSlots() || productCount() + state.jobs.length * 4 + 4 > capacity())
                return;
            for (let [k, v] of Object.entries(r.needs))
                state.inv[k] -= v;
            state.jobs.push({ id: ++state.jobSeq, recipe: id, start: state.sim, duration: state.upgrades.solar ? 6 : 10, hits: 0, taps: 0, lastTap: -10 });
            sound();
            toast('Mixing ' + r.name + '. Stay for the timing bonus, or collect it automatically when ready.');
            refresh();
        }
        else if (name === 'steady') {
            let j = state.jobs.find(j => String(j.id) === String(id));
            if (!j || j.taps >= 3 || state.sim - j.lastTap < .48 || state.sim - j.start >= j.duration)
                return;
            let p = (Math.sin((state.sim - j.start) * 3.1) + 1) / 2;
            j.taps++;
            j.lastTap = state.sim;
            if (p >= .35 && p <= .65) {
                j.hits++;
                sound('ready');
                toast('Steady hands! Bonus hit ' + j.hits + '/2.');
            }
            else {
                sound();
                toast('Missed the mint zone. The normal batch still finishes.');
            }
            refresh();
        }
        else if (name === 'plant') {
            const i=Number(id);if(!Number.isInteger(i)||i<0||i>=growSlots())return;
            if(state.plants[i]){const harvested=MZLife.harvest(state,i);if(!harvested)return;toast('Harvested '+harvested+' fictional Glowleaf leaves.');sound('ready');}
            else {if(!MZLife.beginPlant(state,i,growVariety))return;toast('Seed planted. Try the optional care tasks for extra leaves.');sound();}refresh();
        }
        else if (name === 'buy') {
            let s = SUPPLIES[id];
            if (!s || !canAfford(s.price))
                return;
            MZLife.pay(state,s.price);
            state.inv[id] += s.qty;
            state.stats.bought++;
            storyEvent('buy', { id });
            sound();
            toast('Bought ' + s.qty + ' ' + s.name.toLowerCase() + ' / ' + money(s.price));
            refresh();
        }
        else if (name === 'upgrade') {
            let u = UPGRADES[id];
            if (!u || state.upgrades[id] || !canAfford(u.price))
                return;
            MZLife.pay(state,u.price);
            state.upgrades[id] = true;
            sound('ready');
            toast(u.name + ' installed.');
            refresh();
        }
        else if (name === 'deliver') {
            let o = state.orders.find(o => String(o.id) === String(id));
            if (!o || state.products[o.recipe] < o.qty || panelCtx?.id !== o.npc || state.sim < panelCtx.cooldown)
                return;
            state.orders = state.orders.filter(p => p !== o);
            registerSale(o.recipe, o.qty, o.pay, panelCtx, true);
            state.nextOrder = Math.min(state.nextOrder, state.sim + 20);
            closePanel(false);
        }
        else if (name === 'sell') {
            if (panel !== 'customer' || !$('tradeProduct') || state.sim < panelCtx.cooldown)
                return;
            let recipe = $('tradeProduct').value, qty = Number($('tradeQty').value), mult = Number($('tradePrice').value) / 100;
            if (!RECIPES[recipe] || !Number.isInteger(qty) || qty < 1 || qty > 5 || state.products[recipe] < qty || mult < .85 || mult > 1.3)
                return;
            if (Math.random() < saleChance(mult)) {
                registerSale(recipe, qty, Math.round(MZNeighbourhood.streetValue(RECIPES[recipe],panelCtx) * qty * mult), panelCtx);
                closePanel(false);
            }
            else {
                panelCtx.cooldown = state.sim + 8;
                toast(panelCtx.name + ' declined that price. Try a lower offer after a few seconds.', true);
                closePanel(false);
            }
        }
        else if (name === 'property') {
            if (state.workshop || !canAfford(1600))
                return;
            MZLife.pay(state,1600);
            state.workshop = true;
            sound('ready');
            toast('Workshop 02 is yours. The shutter is open, and two extra planters are unlocked.');
            refresh();
        }
        else if (name === 'runner') {
            if (!state.workshop || state.runner || !canAfford(650))
                return;
            MZLife.pay(state,650);
            state.runner = true;
            state.runnerTick = state.sim;
            sound('ready');
            toast('Your runner is on the job. Keep finished packs in stock.');
            refresh();
        }
        else if (name === 'food') {
            if (!canAfford(25))
                return;
            MZLife.pay(state,25);
            state.health=Math.min(100,state.health+25);
            stamina = 100;
            state.heat = Math.max(0, state.heat - 6);
            sound('ready');
            toast('A good meal: +25 health, stamina restored.');
            closePanel(false);
        }
        else if (name === 'sleep') {
            stopSeating(true);fall=null;
            state.sim += 65;
            state.runnerTick = state.sim;
            state.day++;
            state.clock = 420;
            state.heat = 0;
            state.health=100;stopRide(true);
            stamina = 100;
            tickProduction();
            toast('Morning, neighbour. Welcome to day ' + state.day + '.');
            closePanel(false);
        }
        else if (name === 'ride') {
            const dest = MZNeighbourhood.taxiStops;
            if (!dest[id] || !canAfford(20))
                return;
            MZLife.pay(state,20);
            stopSeating(true);fall=null;stopRide(true);
            [state.player.x, state.player.z, state.player.yaw] = dest[id];
            state.player.pitch = 0;
            state.sim += 5;
            toast('You have arrived. Fare: R 20.');
            closePanel(false);
        }
        else if (name === 'track') {
            if (!world.getPoint(id))
                return;
            state.track = id;
            storyEvent('track', { id });
            toast('Tracking ' + world.getPoint(id).name + '. Follow the gold marker.');
            closePanel(false);
        }
        else if (name === 'phoneTab') {
            if (!['home','orders', 'contacts', 'story','history','bank','careers','businesses'].includes(id))
                return;
            phoneTab = id;
            refresh();
        }
        else if (name === 'resume')
            closePanel(false);
        else if (name === 'save')
            save(true);
        else if (name === 'export')
            exportSave();
        else if (name === 'help')
            openPanel('help');
        else if (name === 'dev')
            openPanel('dev');
        else if (name === 'newConfirm')
            openPanel('newConfirm');
        else if (name === 'reset') {
            closePanel(false);
            startGame(true);
        }
        else if (name === 'storyBegin') {
            storyEvent('intro');
            closePanel(false);
        }
        else if (name === 'mentorTalk') {
            storyEvent('mentor');
            if (state.story.chapter === 10) {
                storyEvent('heatLesson');
                toast('Lesson saved in your phone journal.');
            }
            closePanel(false);
        }
        else if (name === 'readChapter') {
            openPanel('chapter');
        }
        else if (name === 'toggleRunner') {
            state.runnerActive = !state.runnerActive;
            state.runnerTick = state.sim;
            refresh();
        }
        else if (name === 'toggleReserve') {
            state.reserveOrders = !state.reserveOrders;
            refresh();
        }
        else if (name === 'oddJob') {
            if (!state.recovery.active && state.sim < state.recovery.next)
                return;
            state.recovery.active = true;
            state.track = 'musa';
            toast("Take Nandi's groceries to Musa. Follow the gold compass.");
            closePanel(false);
        }
        else if (name === 'completeOddJob') {
            if (!state.recovery.active || panelCtx?.id !== 'musa')
                return;
            state.recovery.active = false;
            state.recovery.next = state.sim + 90;
            state.recovery.count++;
            state.cash += 75;
            toast('Groceries delivered. +R75. You can restock at Sunset Spaza.');
            sound('cash');
            state.track = quest().target;
            closePanel(false);
        }
        else if (name === 'fullscreen') {
            try {
                const p = document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.();
                if (p?.catch)
                    p.catch(() => toast('Fullscreen is not supported here. Browser play still works.', true));
                else if (!p)
                    toast('Use your browser fullscreen option if available.');
            }
            catch (_) {
                toast('Fullscreen is unavailable in this browser.', true);
            }
        }
        else if (name === 'unstuck') {
            stopSeating(true);fall=null;
            stopRide(true);
            Object.assign(state.player, world.homeSpawn);
            state.player.pitch = 0;
            closePanel(false);
            toast('Returned safely to your yard.');
        }
        else if (name === 'diagnostics') {
            downloadJSON({ build: '11.0.0', agent: navigator.userAgent, viewport: [innerWidth, innerHeight], webgl: renderer.gl.getParameter(renderer.gl.VERSION), settings: state.settings, chapter: state.story.chapter, errors: diagnostics }, 'mzansi-diagnostics.json');
        }
        else if (name === 'cancelImport') {
            pendingImport = null;
            openPanel(started?'pause':'saveCenter');
        }
        else if (name === 'confirmImport') {
            if(!pendingImport)return;
            if(started)save(false,true);
            const previous=load();
            state=pendingImport;pendingImport=null;titlePlayMode=state.mode;
            state.meta=previous?.meta||{revision:0,savedAt:0,writer:''};
            state.rides.riding=false;saveConflict=false;
            if(!world.isFree(state.player.x,state.player.z,state))Object.assign(state.player,world.homeSpawn);
            started=true;applyCooldowns();save(false,true,true);startGame(false);
            toast('Save imported. Money, story and owned rides restored.');
        }
        else if (name === 'cheat') {
            if (id === 'cash')
                state.cash += 5000;
            else if (id === 'supplies')
                for (let k in state.inv)
                    state.inv[k] += k === 'pouch' ? 60 : 12;
            else if (id === 'packs') {
                for (let k of ['glow', 'mist', 'sunburst', 'prism'])
                    state.products[k] += Math.min(6, Math.max(0, capacity() - productCount() - state.jobs.length * 4));
            }
            else if (id === 'rep')
                state.rep += 20;
            else if (id === 'finish') {
                state.sim += 60;
                tickProduction();
            }
            else if (id === 'heat') {
                state.heat = 90;
                const cop=world.police[0],a=MZPolice.setup(cop);a.mode='chase';a.last={x:state.player.x,z:state.player.z};a.lastSeen=state.sim;a.routeAt=0;
                state.lastSale = state.sim;
                closePanel(false);
            }
            else if (id === 'clear'){state.heat = 0;MZPolice.reset(world);}
            else if (id === 'home') {
                stopSeating(true);fall=null;Object.assign(state.player, world.homeSpawn);
                state.player.pitch = 0;
                closePanel(false);
            }
            toast('Sandbox change applied.');
            if (panel)
                refresh();
        }
        if (started) {
            const labels={buy:'Bought '+(SUPPLIES[id]?.name||'supplies'),upgrade:'Installed '+(UPGRADES[id]?.name||'upgrade'),buyRide:'Purchased '+(MZMobility.RIDES[id]?.name||'ride'),buyHelmet:'Bought a riding helmet',buyMedkit:'Bought first aid',property:'Bought Workshop 02',runner:'Hired a delivery runner',ride:'Taxi journey',food:'Bought a takeaway meal',craft:'Started '+(RECIPES[id]?.name||'batch'),sleep:'Rested until morning',cheat:'Developer tool: '+id};
            if(labels[name])MZLife.log(state,name==='craft'?'production':name==='cheat'?'developer':name==='sleep'?'system':'purchase',labels[name],state.cash-beforeActionCash);
            syncStory();updateHUD();save();
        }
    }
    function tickProduction() {
        let complete = state.jobs.filter(j => state.sim - j.start >= j.duration);
        for (let j of complete) {
            let qty = j.hits >= 2 ? 4 : 3;
            let space = capacity() - productCount();
            if (space < qty)
                continue;
            state.products[j.recipe] += qty;
            state.stats.crafted++;
            MZLife.log(state,'production',RECIPES[j.recipe].name+' completed / '+qty+' packs');
            storyEvent('crafted', { recipe: j.recipe });
            state.jobs = state.jobs.filter(x => x !== j);
            toast(RECIPES[j.recipe].name + ' ready: ' + qty + ' packs added to your stock.');
            sound('ready');
            refreshQueued = true;
        }
        state.plants.forEach((p, i) => { if (p && state.sim - p.start >= p.duration && !p.notified) {
            p.notified = true;
            toast('Planter ' + (i + 1) + ' is ready to harvest.');
            sound('ready');
            refreshQueued = true;
        } });
    }
    function updatePanelTimers() { for(const el of document.querySelectorAll('[data-review]')){const a=state.cityLife.career.applications.find(a=>String(a.id)===el.dataset.review);if(a)el.textContent=a.status==='reviewing'?'Reviewing / '+Math.max(0,Math.ceil(a.reviewAt-state.sim))+' seconds':a.status.toUpperCase();} MZCommercePanels.update(state); if(panel==='activity'&&panelCtx?.id==='court'){const el=$('shotNeedle');if(el)el.style.left=(MZActivities.shot(realTime).aim*100)+'%';const shotButton=document.querySelector('[data-action=shoot]');if(shotButton)shotButton.disabled=!!state.rides.riding||realTime-lastShot<1.8;}  if (panel === 'bench') {
        for (let j of state.jobs) {
            let p = clamp((state.sim - j.start) / j.duration, 0, 1), bar = document.querySelector(`[data-job="${j.id}"]`), timer = document.querySelector(`[data-timer="${j.id}"]`), needle = document.querySelector(`[data-needle="${j.id}"]`);
            if (bar)
                bar.style.width = p * 100 + '%';
            if (timer)
                timer.textContent = (state.sim - j.start >= j.duration ? 'Ready / free stock space to collect' : Math.max(0, Math.ceil(j.duration - (state.sim - j.start))) + 's remaining');
            if (needle)
                needle.style.left = ((Math.sin((state.sim - j.start) * 3.1) + 1) / 2) * 98 + '%';
        }
    } if(panel==='grow'&&state.plants.some((p,i)=>p&&MZLife.growth(p,state.sim)>=.45&&document.querySelectorAll('[data-grow-stage]')[i]?.dataset.growStage==='1'))refreshQueued=true;
        if (panel === 'grow')
        state.plants.forEach((p, i) => { if (!p)
            return; let bar = document.querySelector(`[data-plant="${i}"]`), timer = document.querySelector(`[data-plant-timer="${i}"]`); if (bar)
            bar.style.width = clamp((state.sim - p.start) / p.duration, 0, 1) * 100 + '%'; if (timer)
            timer.textContent = Math.max(0, Math.ceil(p.duration - (state.sim - p.start))) + 's remaining'; }); }
    function newOrder() { if (!state.settings.receiveOrders || (!isFreeMode() && state.story.chapter < 7))
        return; let free = world.customers.filter(n => !state.orders.some(o => o.npc === n.id)); if (!free.length || state.orders.length >= (isFreeMode()?8:5))
        return; let n = free[Math.floor(Math.random() * free.length)], available = Object.keys(RECIPES).filter(id => MZNeighbourhood.canCraft(state,RECIPES[id])), recipe = available[Math.floor(Math.random() * available.length)], qty = 2 + Math.floor(Math.random() * 3), pay = Math.round(RECIPES[recipe].value * qty * (1.08 + Math.random() * .13)); state.orders.push({ id: ++state.orderSeq, npc: n.id, recipe, qty, pay }); toast('New order from ' + n.name + ' / ' + money(pay) + '. Check your phone [P].'); if (panel === 'phone')
        refreshQueued = true; }
    function catchPlayer() { if(coop.active){coop.enqueue({type:'penalty',arrest:true});stopRide(true);state.heat=0;state.caughtUntil=state.sim+20;Object.assign(state.player,world.homeSpawn);MZPolice.reset(world);closePanel(false,true);return;}stopRide(true); stopSeating(true);fall=null; let fine = state.dev.unlimitedMoney?0:Math.min(state.cash, 180); MZLife.pay(state,fine); let lost = 0; for (let k in state.products) {
        let n = Math.ceil(state.products[k] * .25);
        state.products[k] -= n;
        lost += n;
    } state.heat = 0; state.caughtUntil = state.sim + 20; state.stats.fines++; Object.assign(state.player, world.homeSpawn); state.player.pitch = 0; for (let p of world.police) {
        p.chase = false;
        p.x = p.path[0][0];
        p.z = p.path[0][1];
        p.index = 1;
    } MZPolice.reset(world);MZLife.log(state,'police','Patrol penalty / '+lost+' finished packs confiscated',-fine);if (panel)
        closePanel(false,true); sound('warn'); $('flash').style.opacity = '.35'; setTimeout(() => $('flash').style.opacity = '0', 230); toast('Caught by the patrol. Fine: ' + money(fine) + '. ' + lost + ' packs confiscated. Back at your yard.', true); save(); }
    let stamina = 100;
    function simulate(dt) {
        const previousPlayer={x:state.player.x,z:state.player.z};
        state.sim += dt;
        state.clock += dt * 1.6;
        if (state.clock >= 1440) {
            state.clock -= 1440;
            state.day++;
        }
        if(!coop.active){
        tickProduction();
        if (state.sim >= state.nextOrder) {
            newOrder();
            state.nextOrder = state.sim + 50;
        }
        if (state.runner && state.runnerActive && state.sim - state.runnerTick >= 25) {
            state.runnerTick = state.sim;
            let k = Object.keys(RECIPES).reverse().find(k => spareStock(k) > 0);
            if (k) {
                let n = Math.min(2, spareStock(k));
                registerSale(k, n, Math.round(n * RECIPES[k].value * .85), null, false, true);
            }
        }
        }
        if (state.sim - state.lastSale > 9) {
            let inHome = world.inHome(state.player.x, state.player.z);
            state.heat = Math.max(0, state.heat - dt * (inHome ? 2.2 : .65));
        }
        if (!panel && !fall && !state.life.seat && !coop.stalled) {
            let p = state.player, forward = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0), side = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0);
            if(activeCar())MZCamera.look(carCamera,((keys.ArrowRight?1:0)-(keys.ArrowLeft?1:0))*dt*1.65,0);else p.yaw += ((keys.ArrowRight ? 1 : 0) - (keys.ArrowLeft ? 1 : 0)) * dt * 1.65;
            forward += touch?.input.y || 0;
            side += touch?.input.x || 0;
            let moving = forward || side, sprint = (keys.ShiftLeft || keys.ShiftRight || touch?.input.sprint) && moving && stamina > 3;
            const bx=p.x,bz=p.z;
            if(state.rides.riding){
                if(indoors()){
                    stopRide(true);toast('Dismounted indoors. Your ride is safely stored.');save();
                }else{
                    const r=MZMobility.RIDES[state.rides.equipped];
                    if(r.car){
                        const result=MZTravel.carStep(rideMotion,r,{forward,side,brake:!!keys.Space||handbrake||!!touch?.input.sprint},dt,p,world,state);
                        p.yaw=rideMotion.heading;state.stats.distanceRidden+=result.distance;carCrash(result.impact,result.contact);
                    }else{
                        p.yaw+=Math.max(-1,Math.min(1,side))*dt*1.65;
                        const travel=MZMobility.step(rideMotion,r,{forward,yaw:p.yaw,brake:handbrake,boost:!!(keys.ShiftLeft||keys.ShiftRight||touch?.input.sprint)},dt);
                        world.move(p,travel.dx,travel.dz,state,r.radius);
                        const distance=Math.hypot(p.x-bx,p.z-bz);state.stats.distanceRidden+=distance;rideMotion.distance+=distance;
                        if(Math.hypot(travel.dx,travel.dz)>.01&&distance<Math.hypot(travel.dx,travel.dz)*.20)rideMotion.speed=0;
                    }
                    world.rideDynamics=rideMotion;world.rideHeading=rideMotion.heading;world.rideRoll=rideMotion.roll||0;world.ridePitch=rideMotion.pitch||0;
                    if(indoors()){stopRide(true);toast('Dismounted at the door.');save();}
                }
                sprint=false;
            }else{
                let speed=(sprint?7.5:4.8),len=Math.max(1,Math.hypot(forward,side));
                forward/=len;side/=len;
                world.move(p,(Math.sin(p.yaw)*forward+Math.cos(p.yaw)*side)*speed*dt,(-Math.cos(p.yaw)*forward+Math.sin(p.yaw)*side)*speed*dt,state);
            }
            storyEvent('move',{distance:Math.hypot(p.x-bx,p.z-bz)});
            if (keys.ArrowLeft || keys.ArrowRight)
                storyEvent('look', { amount: dt * 1.65 });
            if (sprint)
                stamina = Math.max(0, stamina - dt * 16);
            else
                stamina = Math.min(100, stamina + dt * 19);
            lookBounce = !state.rides.riding && moving && state.settings.headbob ? Math.sin(state.sim * (sprint ? 13 : 9)) * .035 : 0;
        }
        else {
            stamina = Math.min(100, stamina + dt * 15);
            lookBounce = 0;
        }
        MZTravel.stepJump(jumpState,dt);world.jumpHeight=jumpState.height;
        const crowdCars=[];
        for (let c of world.cars) {
            const old={x:c.x,z:c.z,ry:c.ry};
            if(coop.active){c.startX??=c.x;c.x=((c.startX+c.speed*state.sim+128)%256+256)%256-128;}else c.x+=c.speed*dt;
            if(Math.abs(c.x-old.x)>100)old.x=c.x;
            if(c.x>128){c.x=-128;old.x=c.x;}
            if(c.x<-128){c.x=128;old.x=c.x;}
            crowdCars.push({x:c.x,z:c.z,old,heading:c.speed>0?Math.PI/2:-Math.PI/2,vx:c.speed,vz:0,source:'traffic'});
            if(!panel && state.sim>=state.damageUntil && MZMobility.trafficHit(previousPlayer,state.player,old,c,state.rides.riding ? .43 : .32))takeTrafficHit(c);
        }
        if(activeCar())crowdCars.push({x:state.player.x,z:state.player.z,old:previousPlayer,heading:rideMotion.heading,vx:rideMotion.vx,vz:rideMotion.vz,halfWidth:MZMobility.RIDES[state.rides.equipped].halfWidth,halfLength:MZMobility.RIDES[state.rides.equipped].halfLength,source:'player'});
        world.lifeSim=state.sim;
        MZPeople.tick(world,state,dt,{coop:coop.active,locked:['customer','npcCare'].includes(panel)?panelCtx?.id:null,cars:crowdCars,horn:state.sim<hornUntil});
        const incidents=MZPeople.collisions(world,state,crowdCars);
        for(const e of incidents)if(e.source==='player'){
            rideMotion.vx*=.68;rideMotion.vz*=.68;state.heat=Math.min(100,state.heat+28);state.lastSale=state.sim;MZPolice.witness(world,state);
            MZLife.log(state,'traffic','Vehicle hit '+(e.person.name||'a neighbour')+' / attention increased');
            if(state.sim-lastNpcNotice>2){toast((e.person.name||'A neighbour')+' is hurt. Stop safely and check on them.',true);lastNpcNotice=state.sim;}save();
        }
        if(!coop.active){MZActivities.tick(state);MZCommerce.tick(state);const before=state.cityLife.career.applications.map(a=>a.status).join(',');MZNightlife.tick(state);if(before!==state.cityLife.career.applications.map(a=>a.status).join(',')){save();if(panel==='bankApplications')refreshQueued=true;toast('The bank has reviewed your application.');}}
        world.lastPlayerSpeed=Math.hypot(state.player.x-previousPlayer.x,state.player.z-previousPlayer.z)/Math.max(dt,.001);
        tickLife(dt);
        syncStory();
        if (!panel && !isFreeMode() && MZStory.complete(state) && !state.victory) {
            state.victory = true;
            openPanel('victory');
            save();
        }
        if (state.sim - lastSave >= 3)
            save();
    }
    function nearestPoint() { let p = state.player, best = null, score = 1e9; for (let n of [...world.points, ...world.customers,...world.pedestrians.filter(MZPeople.injured),...world.police.filter(MZPeople.injured)]) {
        if (n.requires && !state[n.requires])
            continue;
        if(n.type==='litter'&&(state.outdoors.litter.includes(n.id)||state.sim<state.outdoors.recycleNext))continue;
        let dx = n.x - p.x, dz = n.z - p.z, d = Math.hypot(dx, dz), dot = (Math.sin(p.yaw) * dx - Math.cos(p.yaw) * dz) / (d || 1);
        if (d < 3.5 && dot > -.35) {
            let s = d - dot * .6;
            if (s < score) {
                score = s;
                best = n;
            }
        }
    } return best; }
    function interact() { if(fall)return;if(state.life.seat&&!panel){openPanel('restaurant');return;}if (panel) {
        closePanel(false);
        return;
    } nearest = nearestPoint(); if (nearest)
        openPanel(MZPeople.injured(nearest)?'npcCare':nearest.type, nearest);
    else
        toast('Move closer to a person, counter, or piece of equipment. Look for the E prompt.'); }
    function updateHUD() {
        $('guideHint').textContent=isFreeMode()?'Phone > Contacts: choose anyone to trade with. Map > Explore districts: choose where to go.':MZGuide.hint(state.story.chapter,!!touch?.enabled);
        $('mobileObjective').querySelector('span').textContent=isFreeMode()?'FREE ROAM / TAP FOR HELP':'NEXT STEP / TAP FOR HELP';
        $('pinnedLesson').classList.toggle('hidden',!state.settings.guidePinned);
        $('interaction').querySelector('kbd').textContent=touch?.enabled?'USE':'E';
        if (!started)
            return;
        $('seatedBar').classList.toggle('hidden',!state.life.seat||!!panel);
        document.body.classList.toggle('seated-mode',!!state.life.seat);
        $('seatStatus').textContent=state.life.meal?'Enjoying '+MZLife.MEALS[state.life.meal.id].name+' / '+Math.ceil(state.life.meal.remaining)+'s':'Seated at '+(state.life.seat||'').replace('table','Table ');
        $('knockdownBanner').classList.toggle('hidden',!fall||!!panel);
        $('knockdownText').textContent=fall?(fall.knockout?'Help is on the way...':'Knocked down / getting back up...'):'';
        const patrolStatus=MZPolice.status(world);
        $('policeBanner').classList.toggle('hidden',patrolStatus==='patrol'||!!panel||!!fall);
        $('policeState').textContent=({warning:'POLICE / PLEASE STOP',chase:'POLICE / PURSUIT',search:'POLICE / SEARCHING LAST-SEEN AREA',stop:'POLICE / STOP'})[patrolStatus]||'';
        $('cooperateBtn').classList.toggle('hidden',!['warning','chase'].includes(patrolStatus));
        $('devBadge').classList.toggle('hidden',!devUnlocked); 
        $('healthValue').textContent=state.health+'/100';
        $('healthFill').style.width=state.health+'%';
        $('healthBlock').classList.toggle('low-health',state.health<25);
        $('healthOpen').setAttribute('aria-label','Health '+state.health+' of 100. Open first aid.');
        const ride=state.rides.equipped?MZMobility.RIDES[state.rides.equipped]:null;
        $('rideName').textContent=ride?ride.name:'On foot';
        const activeRide=state.rides.riding?MZMobility.RIDES[state.rides.equipped]:null;document.body.classList.toggle('driving-car',!!activeRide?.car);document.body.classList.toggle('riding-display',!!activeRide);
        $('cameraActions').classList.toggle('hidden',!activeRide?.car);
        $('speedometer').classList.toggle('hidden',!activeRide||!!panel);$('speedValue').textContent=Math.round(Math.abs(rideMotion.speed)*3.6);$('speedGear').textContent=activeRide?.car?((rideMotion.gear==='D'?'D'+(rideMotion.driveGear||1):(rideMotion.gear||'N'))+' | '+MZVehicle.condition(state.rides.damage?.[state.rides.equipped])+'%'):activeRide?.kind||'';
        $('touchJump').textContent=activeRide?.car?'BRAKE':'JUMP';$('touchJump').setAttribute('aria-label',activeRide?.car?'Hold handbrake':'Jump');
        $('coopStatus').classList.toggle('hidden',!coop.active||!!panel);$('coopStatus').textContent=coop.active?('ROOM '+coop.data.code+' / '+(coop.stalled?'RECONNECTING':coop.data.members.filter(m=>m.online).length+'/2')):'';
        $('rideSpeed').textContent=state.rides.riding?Math.round(Math.abs(rideMotion.speed)*3.6)+' km/h':ride?'READY TO RIDE':'VISIT UBUNTU WHEELS';
        $('rideToggle').textContent=state.rides.riding?'Get off [V]':ride?'Mount ride [V]':'My rides [G]';
        $('touchRide').textContent=state.rides.riding?'OFF':'RIDE';
        $('touchSprint').textContent=state.rides.riding?(MZMobility.RIDES[state.rides.equipped]?.car?'BRAKE':({skateboard:'PUSH',bicycle:'PEDAL',scooter:'GO'})[state.rides.equipped]):'RUN';
        $('mobileRideSpeed').textContent=state.rides.riding?Math.round(Math.abs(rideMotion.speed)*3.6)+' km/h / '+ride.kind:'';
        $('money').textContent = state.dev.unlimitedMoney?'UNLIMITED':money(state.cash);
        $('money').classList.toggle('unlimited',!!state.dev.unlimitedMoney);
        $('rep').textContent = rank() + ' / ' + state.rep + ' REP';
        let h = Math.floor(state.clock / 60), m = Math.floor(state.clock % 60);
        $('clock').textContent = 'DAY ' + state.day + ' / ' + String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
        let p = state.player, district = world.inHome(p.x, p.z) ? 'Your Yard' : p.x > 28 && p.z > 15 ? 'Workshop Quarter' : p.z < -29 && p.x > 25 ? 'Taxi Rank' : p.x > -16 && p.x < 10 && p.z > 12 ? 'Sunset Square' : 'Ubuntu Avenue';
        const area=MZNeighbourhood.districtAt(p.x,p.z);
        if(area!=='centre')district=MZNeighbourhood.districts.find(d=>d.id===area).name;
        if(world.inRestaurant(p.x,p.z))district='Inside Braai & Chill';
        $('district').textContent = district;
        $('mapStatus').textContent = district.toUpperCase();
        $('heatValue').textContent = Math.round(state.heat) + '%';
        $('heatFill').style.width = state.heat + '%';
        $('heatFill').style.background = state.heat >= 60 ? '#ed8175' : '#f2b965';
        $('heatLabel').textContent=MZLayout.compact?(patrolStatus==='patrol'?'ATTENTION':patrolStatus.toUpperCase()):(patrolStatus==='patrol'?'KEEPING A LOW PROFILE':'POLICE / '+patrolStatus.toUpperCase());
        $('staminaFill').style.width = stamina + '%';
        $('stockInfo').textContent = productCount() + ' PACKS';
        let ready = state.plants.filter(p => p && state.sim - p.start >= p.duration).length, growing = state.plants.filter(Boolean).length;
        $('growInfo').textContent = ready ? ready + ' READY TO HARVEST' : growing ? growing + ' PLANTS GROWING' : growSlots() + ' EMPTY PLANTERS';
        $('orderBadge').textContent = state.orders.length;
        let q = quest();
        $('jobNumber').textContent = isFreeMode() ? 'FREE' : MZStory.complete(state) ? 'DONE' : String(q.n).padStart(2, '0');
        $('jobNumber').parentNode.lastChild.textContent=isFreeMode()?' / YOUR NEIGHBOURHOOD':' / YOUR STORY';
        $('trackJob').textContent=isFreeMode()?'Explore districts':'Track objective';
        $('jobTitle').textContent = q.title;
        $('mobileTask').textContent = q.title;
        $('mobileObjective').setAttribute('aria-label', q.title + '. Tap to read full instructions.');
        $('jobText').textContent = q.text;
        $('jobProgress').textContent = q.progress || '';
        if (oldQuest !== q.n) {
            if (oldQuest !== -1) {
                toast('Next move: ' + q.title);
                state.track = q.target;
                sound('ready');
            }
            oldQuest = q.n;
        }
    }
    function mapTransform(target,large=false){
        const b=world.bounds,pad=large?34:9,scale=Math.min((target.width-2*pad)/(b.maxX-b.minX),(target.height-2*pad)/(b.maxZ-b.minZ));
        const ox=(target.width-(b.maxX-b.minX)*scale)/2,oz=(target.height-(b.maxZ-b.minZ)*scale)/2;
        return {scale,fx:x=>ox+(x-b.minX)*scale,fz:z=>oz+(z-b.minZ)*scale};
    }
    function drawMap(target,large=false){
        if(!target)return;
        const c=target.getContext('2d'),{scale,fx,fz}=mapTransform(target,large),b=world.bounds;
        c.fillStyle='#163338';c.fillRect(0,0,target.width,target.height);
        const rect=(x,z,w,d,col)=>{c.fillStyle=col;c.fillRect(fx(x-w/2),fz(z-d/2),w*scale,d*scale);};
        rect(-198,-10,144,240,'#65715b');rect(0,43,248,294,'#456457');rect(-53,123,142,132,'#587751');rect(71,123,105,132,'#72755e');rect(-92,-25,64,158,'#746954');rect(92,-25,64,158,'#637a6e');rect(0,-79,120,50,'#657656');
        rect(121,-25,6,158,'#79a9a2');
        for(const road of world.roads)rect(road.x,road.z,road.w,road.d,'#334b4c');
        for(const t of world.trees){c.beginPath();c.arc(fx(t.x),fz(t.z),large?4:1.7,0,Math.PI*2);c.fillStyle='#9cac85';c.fill();}
        for(const n of world.buildings){rect(n.x,n.z,n.w,n.d,n.name==='YOUR YARD'?'#9aaf81':'#a39072');c.strokeStyle='#efdab22b';c.lineWidth=1;c.strokeRect(fx(n.x-n.w/2),fz(n.z-n.d/2),n.w*scale,n.d*scale);}
        c.strokeStyle='#d7ce9d70';c.lineWidth=large?1.5:1;c.setLineDash([5,7]);
        for(const road of world.roads){c.beginPath();if(road.w>road.d){c.moveTo(fx(road.x-road.w/2),fz(road.z));c.lineTo(fx(road.x+road.w/2),fz(road.z));}else{c.moveTo(fx(road.x),fz(road.z-road.d/2));c.lineTo(fx(road.x),fz(road.z+road.d/2));}c.stroke();}c.setLineDash([]);
        const dot=(x,z,size,col)=>{c.beginPath();c.arc(fx(x),fz(z),size,0,Math.PI*2);c.fillStyle=col;c.fill();c.strokeStyle='#163338';c.lineWidth=1.5;c.stroke();};
        for(const n of world.customers)dot(n.x,n.z,large?5:2.4,state.sim<n.cooldown?'#afa796':'#fff0d2');
        for(const n of world.police)dot(n.x,n.z,large?4:2,'#78b2db');
        for(const n of world.points)if(!n.requires||state[n.requires])dot(n.x,n.z,large?5:2.4,'#efb36b');
        if(large){
            for(const [label,x,z] of [['ENTERPRISE QUARTER',-200,112],['RIVERSIDE COMMONS',-48,186],['HARBOUR WORKS',85,186],['MASAKHANE MARKET',-92,50],['SUNDOWN CENTRE',-22,50],['BAYFRONT WALK',94,50],['JACARANDA HEIGHTS',0,-101]]){
                c.font='700 12px Arial';c.textAlign='center';const xx=fx(x),yy=fz(z),tw=c.measureText(label).width;
                c.fillStyle='#143439ed';c.fillRect(xx-tw/2-8,yy-12,tw+16,22);c.fillStyle='#ebddbb';c.fillText(label,xx,yy+3);
            }
            c.fillStyle='#d5e8cc';c.font='bold 17px Arial';c.textAlign='right';c.fillText('N',target.width-12,22);c.fillText('\u2191',target.width-12,42);
        }
        if(large)MZAtlas.labels(c,world,{scale,fx,fz},atlasLayer);
        if(coop.active&&world.partner){dot(world.partner.pose.x,world.partner.pose.z,large?9:5,'#83d9f0');}
        const t=world.getPoint(state.track);
        if(t){dot(t.x,t.z,large?9:5,'#ffbd61');if(large){c.font='bold 14px Arial';c.textAlign='center';const text=t.name,tw=c.measureText(text).width,xx=clamp(fx(t.x),tw/2+8,target.width-tw/2-8),yy=clamp(fz(t.z)-17,20,target.height-25);c.fillStyle='#163338ed';c.fillRect(xx-tw/2-7,yy-14,tw+14,23);c.fillStyle='#ffe0a6';c.fillText(text,xx,yy+2);}}
        const p=state.player,size=large?9:5;c.save();c.translate(fx(p.x),fz(p.z));c.rotate(p.yaw);c.beginPath();c.moveTo(0,-size*1.7);c.lineTo(size,size);c.lineTo(0,size*.4);c.lineTo(-size,size);c.closePath();c.fillStyle='#a5f1bc';c.strokeStyle='#173f35';c.lineWidth=2;c.fill();c.stroke();c.restore();
    }
    function updateCompass() {
        const target = world.getPoint(state.track);
        if (!target) { $('compassArrow').textContent='\u25c7';$('compassArrow').style.transform='none';$('compassLabel').textContent='Explore Sundown Bay';$('compassDistance').textContent='40';$('compassDirection').textContent='PHONE > CONTACTS';$('compass').classList.toggle('hidden',!!panel);return;}
        $('compassArrow').textContent='\u2191';
        const p = state.player, dx = target.x - p.x, dz = target.z - p.z, d = Math.hypot(dx, dz);
        let a = Math.atan2(dx, -dz) - p.yaw;
        a = Math.atan2(Math.sin(a), Math.cos(a));
        $('compassArrow').style.transform = 'rotate(' + a + 'rad)';
        $('compassLabel').textContent = target.name;
        $('compassDistance').textContent = Math.round(d) + 'm';
        $('compassDirection').textContent = d < 3.5 ? 'LOOK FOR THE USE PROMPT' : Math.abs(a) > 2.1 ? 'TURN AROUND' : a > .35 ? 'TURN RIGHT' : a < -.35 ? 'TURN LEFT' : 'STRAIGHT AHEAD';
        $('compass').classList.toggle('hidden', !!panel);
    }
    function daylight() { let day = clamp(Math.sin((state.clock - 360) / 1440 * Math.PI * 2) * 1.6 + .22, .07, 1); renderer.daylight = day; renderer.ambient = .68; renderer.brightness = .62 + day * .48; let dusk = 1 - day; renderer.fog = [.28 + dusk * .0 + day * .43, .35 + day * .28, .38 + day * .17]; let top = day > .55 ? '#8ea9ac' : day > .23 ? '#667e91' : '#253e52', bottom = day > .55 ? '#e4b99b' : day > .23 ? '#b19291' : '#697584'; canvas.style.background = `linear-gradient(${top}, ${bottom} 72%, #a7a58d)`; }
    let lastWorldDraw = -1000;
    function frame(t) {
        frameHandle = requestAnimationFrame(frame);
        if (contextLost)
            return;
        if (t - lastRender < 1000 / (state?.settings.maxFps || 60) - .5)
            return;
        lastRender = t;
        let dt = Math.min(.5, (t - lastTime) / 1000 || .016);
        lastTime = t;
        realTime += dt;
        if (started && !paused && !document.hidden) {
            let remaining = dt;
            while (remaining > 0.000001 && !paused) {
                const step = Math.min(.05, remaining);
                simulate(step);
                remaining -= step;
            }
        }
        if (refreshQueued && panel)
            refresh();
        if (started) {
            if(!fall)maybeBrief();
            updateCompass();
        }
        let cam;
        if (started) {
            cam = { ...state.player, y: 1.76 + lookBounce + jumpState.height + (state.rides.riding?MZMobility.RIDES[state.rides.equipped].height:0) };
            if(state.life.seat)cam.y=1.27;
            const pose=MZLife.fallPose(fall,state.settings.reducedMotion);cam.y+=pose.height;cam.roll=pose.roll;cam.pitch+=pose.pitch;
            if(state.rides.riding&&MZMobility.RIDES[state.rides.equipped]?.car)cam=MZCamera.pose(carCamera,state.player,rideMotion,world,state,dt);
            if(state.life.meal&&!state.settings.reducedMotion)cam.pitch-=Math.sin(state.sim*3.7)*.012;
            daylight();
        }
        else {
            cam = { x: -.5 + Math.sin(realTime * .04) * 2, y: 2.6, z: 12.5, yaw: -.40 + Math.sin(realTime * .027) * .08, pitch: -.045 };
            renderer.fog = [.73, .66, .59];
            renderer.daylight = .94;
            renderer.brightness = 1;
        }
        // Menus pause or obscure the scene. Keep timers/input at normal speed,
        // but redraw the covered 3D scene only five times per second.
        if ((!panel && started) || t-lastWorldDraw >= (panel ? 200 : 50)) {
            renderer.carLight=activeCar()?[state.player.x,state.player.z,rideMotion.heading,1]:[0,0,0,0];renderer.roadWet=state.settings.roadWet;
            world.lastCamera={...cam};renderer.begin(cam);
            world.render(state, realTime);
            if(started)MZCarWorld.effects(renderer,world,state,rideMotion,realTime);
            if(started)renderPartner(dt);
            lastWorldDraw = t;
        }
        if (started) {
            nearest = !panel&&!fall&&!state.life.seat ? nearestPoint() : null;
            $('interaction').classList.toggle('hidden', !nearest || !!panel);
            if (nearest) {
                $('interactKind').textContent = MZPeople.injured(nearest)?'HURT / CHECK ON THEM':nearest.kind;
                $('interactText').textContent = nearest.name;
            }
            $('lookHint').classList.toggle('hidden', locked || !!panel || !!drag || matchMedia('(pointer:coarse)').matches);
            let n = world.getPoint(state.track), show = false;
            if (n && !panel) {
                let pos = renderer.project(n.x, 2.7, n.z), d = Math.hypot(n.x - state.player.x, n.z - state.player.z);
                if (pos && pos.x > 35 && pos.x < MZLayout.viewport.width - 35 && pos.y > 100 && pos.y < MZLayout.viewport.height - 155 && d > 4) {
                    show = true;
                    $('waypoint').style.left = pos.x + 'px';
                    $('waypoint').style.top = pos.y + 'px';
                    $('waypointText').textContent = n.name + ' / ' + Math.round(d) + 'm';
                }
            }
            $('waypoint').classList.toggle('hidden', !show);
            if (realTime - lastHUD > .16) {
                updateHUD();
                lastHUD = realTime;
            }
            if (realTime - lastMap > .12) {
                drawMap($('minimap'));
                if (panel === 'map')
                    drawMap($('largeMap'), true);
                lastMap = realTime;
            }
            updatePanelTimers();
        }
        // Next frame was already scheduled at the start.
    }

    $('modalBody').addEventListener('input',e=>{
        if(e.target.id==='v11Stake')cityUi.stake=Number(e.target.value);
        if(e.target.id?.startsWith('v11Qty-')){const id=e.target.id.slice(7),g=MZNightlife.goods[id];if(g&&$('v11Total-'+id))$('v11Total-'+id).textContent='Total '+money(Math.max(0,Number(e.target.value)||0)*(id==='flower'?2:1)*g.price);}
    });
    $('modalBody').addEventListener('change',e=>{
        if(e.target.id==='v11Car'){cityUi.car=e.target.value;refresh();}
        if(e.target.id==='v11Business'){cityUi.business=e.target.value;const d=MZCommerceData.byId[e.target.value];if(d){$('v11Contribution').value=Math.ceil(d.price*.2);$('v11FinanceQuote').textContent=money(d.price)+' opening price. At least '+money(Math.ceil(d.price*.2))+' contribution. The remainder is a restricted loan with a one-time 5% game fee. Stock is separate.';}}
    });
    $('cameraResetBtn').addEventListener('click',resetCamera);
    $('cameraOptionsBtn').addEventListener('click',()=>openPanel('cameraSettings'));
    canvas.addEventListener('wheel',e=>{if(!started||panel||!activeCar())return;e.preventDefault();state.settings.carCameraDistance=MZCamera.zoom(carCamera,carCamera.distance+Math.sign(e.deltaY)*.55);save();},{passive:false});
    $('titleCoop').addEventListener('click',()=>openPanel('coop'));
    $('coopStatus').addEventListener('click',()=>openPanel('coop'));
    $('touchJump').addEventListener('pointerdown',e=>{e.preventDefault();if(panel)return;if(state.rides.riding&&MZMobility.RIDES[state.rides.equipped]?.car){handbrake=true;e.currentTarget.setPointerCapture(e.pointerId);}else jump();});
    for(const type of ['pointerup','pointercancel','lostpointercapture'])$('touchJump').addEventListener(type,()=>handbrake=false);
    window.addEventListener('blur',()=>handbrake=false);
    window.addEventListener('mz:layoutchange',()=>handbrake=false);
    $('titleSettings').addEventListener('click',()=>openPanel('launcherSettings'));
    $('titleDev').addEventListener('click',()=>openPanel('dev'));
    $('titleFullscreen').addEventListener('click',()=>setFullscreen());
    $('bootFullscreen').addEventListener('click',()=>setFullscreen());
    $('tableMenuBtn').addEventListener('click',()=>action('tableMenu'));
    $('standBtn').addEventListener('click',()=>action('stand'));
    $('cooperateBtn').addEventListener('click',()=>action('policeCooperate'));
    document.addEventListener('fullscreenchange',()=>{MZLayout.refresh();keys={};touch?.clear();});
    // Desktop controls. Touch pointer ownership lives in touch.js.
    document.addEventListener('keydown', e => {
        if (e.ctrlKey || e.metaKey || e.altKey)
            return;
        if (panel && e.code === 'Tab') {
            const focusable = [...$('modal').querySelectorAll('button:not(:disabled),input,select,summary,[tabindex="0"]')].filter(el => el.offsetParent !== null);
            if (focusable.length) {
                const first = focusable[0], last = focusable[focusable.length - 1];
                if (e.shiftKey && document.activeElement === first) {
                    e.preventDefault();
                    last.focus();
                }
                else if (!e.shiftKey && document.activeElement === last) {
                    e.preventDefault();
                    first.focus();
                }
            }
            return;
        }
        if(e.code==='Enter'&&e.target.id==='developerCode'){e.preventDefault();action('unlockDev');return;}
        if (e.target.matches('input,select,textarea')) {
            if (e.code === 'Escape')
                closePanel(false);
            return;
        }
        if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code) && started && !panel)
            e.preventDefault();
        if (!started) {
            if (e.code === 'Escape' && panel)
                closePanel(false);
            return;
        }
        if (e.repeat) {
            if (!panel)
                keys[e.code] = true;
            return;
        }
        keys[e.code] = true;
        if(e.code==='Space'&&!panel&&!MZMobility.RIDES[state.rides.riding?state.rides.equipped:null]?.car){e.preventDefault();jump();return;}
        if(e.code==='KeyC'&&!panel&&activeCar()){resetCamera();return;}
        if(e.code==='KeyT'&&!panel&&activeCar()){v8Action('horn',{});return;}
        if(e.code==='KeyV' && !panel){e.preventDefault();toggleRide();return;}
        if(e.code==='KeyB' && !panel){e.preventDefault();healWithKit();return;}
        if (e.code === 'KeyE') {
            interact();
            return;
        }
        if (e.code === 'Escape') {
            if (panel)
                closePanel(false);
            else
                openPanel('pause');
            return;
        }
        if(e.code==='KeyH'){openPanel('chapter');lessonPage=1;renderPanel();return;}
        if (e.code === 'F2') {
            e.preventDefault();
            if (panel === 'dev')
                closePanel(false);
            else
                openPanel('dev');
            return;
        }
        if (e.code === 'Space' && panel === 'bench') {
            e.preventDefault();
            const j = state.jobs.find(j => j.taps < 3);
            if (j)
                action('steady', { id: String(j.id) });
            return;
        }
        const k = { KeyP: 'phone', KeyI: 'inventory', KeyM: 'map', KeyG: 'garage' }[e.code];
        if (k) {
            if (panel === k)
                closePanel(false);
            else
                openPanel(k);
        }
    });
    document.addEventListener('keyup', e => keys[e.code] = false);
    function loseFocus() { keys = {}; drag = null; touch?.clear(); save(); if (started && !panel && !contextLost)
        openPanel('pause'); }
    window.addEventListener('blur', loseFocus);
    document.addEventListener('visibilitychange', () => { if (document.hidden)
        loseFocus(); lastTime = performance.now(); });
    window.addEventListener('pagehide', () => save());
    window.addEventListener('beforeunload', () => save());
    document.addEventListener('pointerlockchange', () => { locked = document.pointerLockElement === canvas; keys = {}; if (locked)
        drag = null; });
    document.addEventListener('pointerlockerror', () => { });
    document.addEventListener('mousemove', e => { if (!started || panel)
        return; if (locked)
        lookBy(e.movementX, e.movementY);
    else if (drag) {
        lookBy((e.clientX - drag.x) * 1.9, (e.clientY - drag.y) * 1.9);
        drag.x = e.clientX;
        drag.y = e.clientY;
    } });
    canvas.addEventListener('mousedown', e => { if (started && !panel && e.button === 0 && !touch?.enabled) {
        drag = { x: e.clientX, y: e.clientY };
        requestLock();
    } });
    document.addEventListener('mouseup', () => drag = null);
    canvas.addEventListener('contextmenu', e => e.preventDefault());
    window.addEventListener('mz:layoutchange',e=>{if(e.detail.major){keys={};drag=null;touch?.clear();stopRide();}});
    document.querySelectorAll('[data-device]').forEach(b=>b.addEventListener('click',()=>{titleMode=b.dataset.device;state.settings.mobileControls=titleMode;device.remember(titleMode);applySettings();}));
    $('rideToggle').addEventListener('click',toggleRide);
    $('touchRide').addEventListener('click',toggleRide);
    $('healthOpen').addEventListener('click',()=>openPanel('health'));
    $('titleSaves').addEventListener('click',()=>openPanel('saveCenter'));
    $('saveWarning').addEventListener('click',exportSave);
    window.addEventListener('storage',e=>{if(started&&e.key===MZSave.KEY&&device.newer(state)){saveConflict=true;openPanel('saveConflict');$('saveStatus').textContent='NEWER SAVE FOUND';}});
    document.querySelectorAll('[data-play-mode]').forEach(b=>b.addEventListener('click',()=>{titlePlayMode=b.dataset.playMode;updatePlayModeLabel();}));
    $('startBtn').addEventListener('click', () => {if(state.settings.autoFullscreen)setFullscreen();startGame(false);});
    $('newBtn').addEventListener('click', () => openPanel('newConfirm'));
    $('titleHelp').addEventListener('click', () => openPanel('help'));
    $('closeModal').addEventListener('click', () => closePanel(false));
    $('modalBackdrop').addEventListener('click', e => { if (e.target === $('modalBackdrop') && !['chapter','mentor','lesson'].includes(panel))
        closePanel(false); });
    document.querySelectorAll('[data-panel]').forEach(b => b.addEventListener('click', () => openPanel(b.dataset.panel)));
    $('interaction').addEventListener('click', interact);
    $('mobileObjective').addEventListener('click', () => {openPanel(isFreeMode()?'freeGuide':'chapter');lessonPage=1;renderPanel();});
    $('readChapterBtn').addEventListener('click', () => {openPanel('chapter');lessonPage=1;renderPanel();});
    $('mapBtn').addEventListener('click', () => openPanel('map'));
    $('trackJob').addEventListener('click', () => { if(isFreeMode()){openPanel('districts');return;} state.track = quest().target; storyEvent('track', { id: state.track }); toast('Tracking ' + world.getPoint(state.track).name + '.'); });
    $('modal').addEventListener('click', e => { let b = e.target.closest('[data-action]'); if (b && !b.disabled)
        action(b.dataset.action, b.dataset); if (e.target.id === 'largeMap') {
        const rect=e.target.getBoundingClientRect(),x=(e.clientX-rect.left)/rect.width*e.target.width,y=(e.clientY-rect.top)/rect.height*e.target.height;
        const {fx,fz}=mapTransform(e.target,true),n=[...world.points,...world.customers].filter(n=>!n.requires||state[n.requires]).sort((a,b)=>Math.hypot(fx(a.x)-x,fz(a.z)-y)-Math.hypot(fx(b.x)-x,fz(b.z)-y))[0];
        if(n&&Math.hypot(fx(n.x)-x,fz(n.z)-y)<24)action('track',{id:n.id});
    } });
    $('modalBody').addEventListener('input', e => { if(e.target.id==='atlasSearch'){const start=e.target.selectionStart;atlasQuery=e.target.value;refresh();$('atlasSearch').focus();$('atlasSearch').setSelectionRange(start,start);return;} if (['tradeProduct', 'tradeQty', 'tradePrice'].includes(e.target.id))
        updateTrade(e.target.id === 'tradeProduct'); if (e.target.id === 'sensitivitySetting')
        state.settings.sensitivity = Number(e.target.value); });
    $('modalBody').addEventListener('change', async (e) => {
        if(e.target.id==='bizFilter'){bizFilter=e.target.value;refresh();return;}
        const el = e.target;
        if(el.id==='atlasLayer'){atlasLayer=el.value;refresh();return;}
        if(el.id==='growVariety'){growVariety=el.value;refresh();return;}
        if(el.id==='historyCategory'){historyCategory=el.value;refresh();return;}
        for(const key of ['autoFullscreen','largeText','reducedMotion','analyticsConsent'])if(el.id===key)state.settings[key]=el.checked;
        if(el.id==='analyticsConsent')MZMetrics.consentChanged();
        if(el.id==='contactDistrict'){contactDistrict=el.value;renderPanel();return;}
        if(el.id==='receiveOrders')state.settings.receiveOrders=el.checked;
        if(el.id==='tipsSetting')state.settings.tipSeconds=Number(el.value);
        if(el.id==='pinSetting')state.settings.guidePinned=el.checked;
        if (el.id === 'soundSetting') {
            state.settings.sound = el.checked;
            sound();
        }
        if (el.id === 'bobSetting')
            state.settings.headbob = el.checked;
        if (el.id === 'qualitySetting')
            state.settings.quality = Number(el.value);
        if (el.id === 'touchSetting')
            state.settings.mobileControls = el.value;
        if (el.id === 'fpsSetting')
            state.settings.maxFps = Number(el.value);
        if (el.id === 'touchSensitivitySetting')
            state.settings.touchSensitivity = Number(el.value);
        if (el.id === 'importSave' && el.files[0]) {
            try {
                const file = el.files[0];
                if (file.size > 1000000)
                    throw new Error('This save file is too large.');
                pendingImport = validSave(JSON.parse(await file.text()));
                openPanel('importConfirm');
            }
            catch (err) {
                toast('Could not import save: ' + err.message, true);
                el.value = '';
            }
        }
        if(!started)launchSettings={...state.settings};
        device.remember(state.settings.mobileControls);
        applySettings();
        save();
    });
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); contextLost = true; release(); save(); $('recoveryOverlay').classList.remove('hidden'); $('recoveryText').textContent = 'Graphics were interrupted. Your progress has been saved when storage is available. Waiting for the browser to restore graphics...'; });
    canvas.addEventListener('webglcontextrestored', () => { try {
        renderer = new MZ.Renderer(canvas);
        world = createWorld(renderer);
        applySettings();
        applyCooldowns();
        contextLost = false;
        lastTime = performance.now();
        $('recoveryOverlay').classList.add('hidden');
        if (started)
            openPanel('pause');
    }
    catch (err) {
        reportError(err);
    } });
    function reportError(err) { diagnostics.push({ message: String(err?.message || err), at: new Date().toISOString() }); if (diagnostics.length > 20)
        diagnostics.shift(); contextLost = true; release(); save(); $('recoveryOverlay').classList.remove('hidden'); $('recoveryText').textContent = 'The game paused after an unexpected error. Export your save below before reloading. ' + String(err?.message || err); }
    window.addEventListener('error', e => { if (state && started)
        reportError(e.error || e.message); });
    window.addEventListener('unhandledrejection', e => { if (state && started)
        reportError(e.reason); });
    $('emergencySave').addEventListener('click', () => { if (state)
        exportSave(); });
    $('reloadGame').addEventListener('click', () => location.reload());
    async function bootGame(){
    const paint=()=>new Promise(resolve=>requestAnimationFrame(resolve));
    try {
        await paint();$('bootText').textContent='Preparing the graphics renderer...';$('bootProgress').value=15;
        renderer = new MZ.Renderer(canvas);await paint();
        $('bootText').textContent='Building the streets, customers and restaurant...';$('bootProgress').value=40;await paint();
        world = createWorld(renderer);$('bootProgress').value=85;await paint();
        state = load() || initial();
        if(!state.meta.savedAt)state.settings.mobileControls=device.profile.mode;
        updateSaveCard();device.retention();$('bootProgress').value=100;
        state.dev=devFlags;
        touch = createTouchControls(canvas, { active: () => started && !panel && !contextLost, settings: () => state.settings, onMode: enabled => { MZLayout.setTouch(enabled); updateDeviceLabel(); }, look: (x, y) => lookBy(x, y, true), interact });
        applySettings();
        applyCooldowns();
        $('boot').classList.add('hidden');
        $('titleScreen').classList.remove('hidden');
        if (load()) {
            $('startBtn').innerHTML = 'Continue your story <span>&#8599;</span>';
            $('newBtn').classList.remove('hidden');
        }
        updatePlayModeLabel();
        requestAnimationFrame(frame);
        // Opt-in test interface. It is enabled only by ?debug=1 or a test-harness flag.
        if (new URLSearchParams(location.search).get('debug') === '1' || window.MZ_TEST_MODE)
            window.GameDebug = {get camera(){return carCamera;},get realTime(){return realTime;},resetCamera,jump, get jumpState(){return jumpState;},get coop(){return coop;},carCrash, get state() { return state; }, get world() { return world; }, get renderer() { return renderer; }, get panel() { return panel; }, get nearest() { return nearest; }, get touch() { return touch; }, get paused() { return paused; }, get fall(){return fall;},get devUnlocked(){return devUnlocked;},get draft(){return craftingDraft;},get rideMotion(){return rideMotion;},get device(){return device;},toggleRide,takeTrafficHit,healWithKit, get contextLost() { return contextLost; }, newOrder, storyEvent, syncStory, registerSale, spareStock, interact, lookBy, applySettings, start: (fresh = true) => startGame(fresh), open: openPanel, close: () => closePanel(false), action, save, load, quest, teleport: (x, z, yaw = 0) => { state.player.x = x; state.player.z = z; state.player.yaw = yaw; state.player.pitch = 0; updateHUD(); }, advance: seconds => { for (let n = 0; n < seconds; n += .05)
                    simulate(Math.min(.05, seconds - n)); updateHUD(); if (panel)
                    refresh(); }, setState: patch => { Object.assign(state, patch); syncStory(); updateHUD(); if (panel)
                    refresh(); }, snapshot: () => JSON.parse(JSON.stringify(state)), validate: validSave };
    }
    catch (err) {
        $('boot').classList.remove('hidden');
        $('bootText').textContent = err.message + ' Try Chrome or Edge with graphics acceleration enabled.';
        diagnostics.push({ message: String(err.message), at: new Date().toISOString() });
    }
    }
    bootGame();
})();
