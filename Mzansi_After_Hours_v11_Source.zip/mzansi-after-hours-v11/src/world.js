'use strict';
/* Procedural, original neighbourhood: geometry, props, people and navigation. */
(() => {
    const { Geometry: G, M } = MZ;
    window.createWorld = function (renderer) {
        const world = { colliders: [], buildings: [], points: [], customers: [], pedestrians: [], police: [], cars: [], signs: [], trees: [], growPositions: [[-25.7, 23.3], [-25.7, 27.1], [-29.1, 23.3], [-29.1, 27.1]], homeSpawn: { x: -32, z: 15.8, yaw: -2.5 } };
        let s = new G(), seed = 7331;
        const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
        const box = (...a) => s.box(...a), col = (x, z, w, d, kind = 'solid') => world.colliders.push({ x1: x - w / 2, x2: x + w / 2, z1: z - d / 2, z2: z + d / 2, kind });
        const sign = (text, sub, x, y, z, w, h, bg = '#214548', fg = '#f5e6be', ry = 0, lit = false) => world.signs.push({ text, x, y, z, ry, lit, quad: renderer.makeSign(text, sub, w, h, bg, fg) });
        const point = (id, type, name, x, z, kind, extra = {}) => world.points.push({ id, type, name, x, z, kind, ...extra });
        const line = (x1, z1, x2, z2, y, w, color) => box((x1 + x2) / 2, y, (z1 + z2) / 2, w, .06, Math.hypot(x2 - x1, z2 - z1), color, Math.atan2(x2 - x1, z2 - z1));
        function tree(x,z,size=1,purple=false){
            s.cylinder(x,1.9*size,z,.13*size,.27*size,3.8*size,0x706454,10);
            for(let j=0;j<8;j++){
                const a=j*2.399, radius=(j%3===0?.55:1.25)*size;
                const ex=x+Math.cos(a)*radius,ez=z+Math.sin(a)*radius,ey=(3.9+(j%3)*.40)*size;
                s.beam([x,2.1*size,z],[ex,ey,ez],.073*size,0x786e59,7);
                s.ellipsoid(ex,ey+.15*size,ez,(1.0+(j%2)*.26)*size,.83*size,1.02*size,
                    (purple?[0x9885a9,0xb09bbc,0x847a99,0xa48db0]:[0x7d9c6b,0x97ae76,0x769269,0xa8b583])[j%4],6,10);
            }
            s.cylinder(x,.06,z,1.8*size,1.8*size,.035,purple?0xa7979f:0x92a08b,12);
            col(x,z,.5*size,.5*size);world.trees.push({x,z});
        }
        function lamp(x, z) { box(x, 2.95, z, .12, 5.9, .12, 0x435659); box(x + .45, 5.87, z, 1.03, .11, .15, 0x435659); box(x + .83, 5.76, z, .57, .12, .35, 0xf9d49a); s.cylinder(x, .21, z, .26, .35, .38, 0x788381, 6); }
        function bench(x, z, r = 0) { box(x, .62, z, 2.6, .15, .7, 0x936c4e, r); box(x, .99, z + .3, 2.6, .55, .13, 0x9d7755, r); box(x - .95, .3, z, .13, .6, .55, 0x354e50); box(x + .95, .3, z, .13, .6, .55, 0x354e50); col(x, z, 2.6, .65); }
        function crate(x, y, z, color = 0x9f7f58) { box(x, y + .45, z, .88, .9, .88, color); for (let a of [-.28, .28])
            box(x + a, y + .45, z + .451, .06, .88, .035, 0x705e49); box(x, y + .18, z + .465, .87, .07, .035, 0xb1946a); }
        function building(x, z, w, d, h, color, name, sub, front = 'south') { box(x, h / 2, z, w, h, d, color); col(x, z, w, d); world.buildings.push({ x, z, w, d, color, name }); box(x, h + .13, z, w + .5, .26, d + .5, 0x697c7b); box(x, .23, z, w + .15, .4, d + .15, 0xa69a85); let frontz = z + d / 2 + .025, ry = 0; if (front === 'north') {
            frontz = z - d / 2 - .025;
            ry = Math.PI;
        } let windowZ = frontz; for (let xx of [x - w * .3, x + w * .3]) {
            box(xx, 1.75, windowZ, 2.05, 1.65, .1, 0x41585b);
            box(xx, 1.75, windowZ + (ry ? -.055 : .055), .06, 1.64, .03, 0xbdd0c3);
            box(xx, 1.75, windowZ + (ry ? -.055 : .055), 2.02, .06, .03, 0xbdd0c3);
        } box(x, 1.4, windowZ, 1.5, 2.8, .1, 0x546867); if (name)
            sign(name, sub, x, h - .78, frontz + (ry ? -.06 : .06), w * .88, 1.4, '#24474a', '#f7e8c9', ry); return { x, z, w, d, h }; }
        // Ground, pavements and avenues.
        box(0, -.34, 0, 370, .6, 370, 0xb7ad92);
        box(0, -.015, 0, 123, .12, 112, 0xa1a992);
        box(0, .005, 0, 122, .11, 12, 0x566368);
        box(18, .008, 0, 12, .11, 110, 0x566368);
        for (let z of [-8, 8])
            box(0, .095, z, 121, .24, 3.8, 0xbfc0a9);
        for (let x of [10, 26])
            box(x, .095, 0, 3.8, .24, 109, 0xbfc0a9);
        for (let z of [-6.08, 6.08])
            box(0, .17, z, 122, .18, .17, 0xd1c8b1);
        for (let x of [11.9, 24.1])
            box(x, .17, 0, .16, .18, 110, 0xd1c8b1);
        for (let x = -58; x < 60; x += 6) {
            if (Math.abs(x - 18) > 8)
                box(x, .075, 0, 2.9, .022, .12, 0xdad6b7);
        }
        for (let z = -50; z < 53; z += 6) {
            if (Math.abs(z) > 7)
                box(18, .075, z, .12, .022, 2.8, 0xdad6b7);
        }
        for (let x = 12.8; x < 24; x += 1.5) {
            box(x, .076, 8.9, .75, .023, 2.15, 0xeee6c9);
            box(x, .076, -8.9, .75, .023, 2.15, 0xeee6c9);
        }
        for (let z = -5; z < 6; z += 1.5) {
            box(8.6, .076, z, 2.05, .023, .75, 0xeee6c9);
            box(27.1, .076, z, 2.05, .023, .75, 0xeee6c9);
        }
        // Starting yard, open and fully walkable.
        box(-32, .07, 21.5, 24, .18, 21, 0xbca98a);
        box(-32, .18, 22, 22, .2, 19, 0x958774);
        box(-43, 2, 22, .3, 4, 19, 0xbdbea1);
        col(-43, 22, .3, 19);
        box(-21, 2, 22, .3, 4, 19, 0xbdbea1);
        col(-21, 22, .3, 19);
        box(-32, 2, 31.5, 22, 4, .3, 0xa7b397);
        col(-32, 31.5, 22, .3);
        for (let x of [-38.7, -25.3]) {
            box(x, 2, 12.5, 8.7, 4, .3, 0xd0b395);
            col(x, 12.5, 8.7, .3);
        }
        box(-32, 3.5, 12.5, 4.8, 1, .3, 0xd0b395);
        box(-32, 4.15, 22, 23, .25, 20.5, 0x59736c);
        for (let x = -43; x < -20; x += .8)
            box(x, 4.31, 22, .08, .12, 20.5, 0x6c8177);
        box(-32, 2.8, 12.25, 4.7, .1, 2.2, 0x6b8378);
        sign('THE YARD', 'YOUR PLACE. YOUR RULES.', -32, 3.61, 12.28, 5.25, .87, '#33534d', '#f3d6a1', Math.PI, true);
        // Window glass and warm interior wall accents.
        for (let x of [-39, -25]) {
            box(x, 2.05, 12.29, 2.9, 1.35, .08, 0x547879);
            box(x, 2.05, 12.23, .08, 1.4, .1, 0xe6dac2);
            box(x, 2.05, 12.23, 2.95, .07, .1, 0xe6dac2);
        }
        box(-38.6, 1, 21.8, 4.7, .2, 1.5, 0x90765c);
        for (let x of [-40.5, -36.7])
            box(x, .6, 21.8, .14, 1.1, 1.15, 0x374f4c);
        col(-38.6, 21.8, 4.7, 1.5);
        box(-38.5, 1.48, 21.8, 1.4, .73, .9, 0x91ac9a);
        box(-38.5, 1.9, 21.8, 1.1, .12, .8, 0x526f67);
        s.cylinder(-38.5, 1.92, 21.8, .38, .38, .23, 0xbcdeb9, 10);
        box(-37.4, 1.19, 21.6, .35, .22, .4, 0xe2ba66);
        sign('THE MIXING BENCH', 'GLOWLEAF / SMALL BATCHES', -38.5, 2.45, 23, 4.9, .88, '#254b45', '#eadbb6', Math.PI, true);
        point('mentor', 'mentor', 'Auntie Zanele', -34.8, 18.1, 'YOUR NEIGHBOUR / STORY GUIDE');
        point('bench', 'bench', 'Mixing bench', -38.5, 20.8, 'YOUR YARD');
        for (let [x, z] of world.growPositions) {
            box(x, .42, z, 1.9, .58, 1.9, 0x8f7260);
            box(x, .73, z, 1.7, .08, 1.7, 0x655b4c);
            col(x, z, 1.9, 1.9);
        }
        point('grow', 'grow', 'Glowleaf planters', -27.4, 25.15, 'YOUR YARD');
        sign('GROW ROOM', 'PLANT. WAIT. HARVEST.', -25.5, 2.8, 30.7, 4.4, .85, '#395a45', '#e6e8ba', Math.PI);
        box(-32, .57, 28.8, 2.2, .52, 3.2, 0x755f53);
        box(-32, .9, 28.8, 2.05, .18, 3.1, 0x82989b);
        box(-32, 1.03, 29.9, 1.8, .2, .72, 0xe9dfc5);
        box(-32, 1.04, 28.4, 2.05, .1, 1.9, 0xc69d71);
        col(-32, 28.8, 2.2, 3.2);
        point('bed', 'bed', 'Rest until morning', -32, 26.8, 'YOUR YARD');
        box(-40.8, 1.2, 28.5, 1.4, 2.2, 1.6, 0x627e78);
        box(-40.75, 1.3, 27.66, .1, .27, .07, 0xe4c775);
        col(-40.8, 28.5, 1.4, 1.6);
        point('locker', 'inventory', 'Storage & backpack', -40.8, 27, 'YOUR YARD');
        sign('SUNDOWN 14', 'HOME SWEET HOME', -42.2, 1.6, 10.8, 2.3, .6, '#31504a', '#e9d5ad', Math.PI);
        world.buildings.push({ x: -32, z: 22, w: 22, d: 19, color: 0xbfa789, name: 'YOUR YARD' });
        // Supplier and hardware stores.
        building(-30, -18.5, 23, 17, 5.2, 0xd2a975, 'SUNSET SPAZA', 'SUPPLIES / SEEDS / PACKAGING');
        box(-30, 2.4, -9.38, 12, 2.8, .3, 0x638e86);
        for (let x = -35.5; x < -24; x += .38)
            box(x, 2.4, -9.15, .055, 2.7, .04, 0x476f6b);
        box(-30, 3.5, -8.5, 15, .16, 2.7, 0xe6c893);
        box(-30, .70, -8.2, 6.2, 1.1, 1, 0x826e50);
        for (let x of [-32.5, -31.3, -30.1, -28.9, -27.7]) {
            s.cylinder(x, 1.42, -8.2, .22, .25, .45, 0xb1c989, 7);
        }
        col(-30, -8.2, 6.2, 1);
        point('supplier', 'shop', 'Nandi / buy supplies', -30, -6.8, 'SUNSET SPAZA');
        sign('OPEN LATE', 'LOCAL SUPPLIES', -39, 2.25, -9.75, 3.2, 1.1, '#ba7653', '#f8e5c0');
        crate(-40, 0, -8);
        crate(-38.9, 0, -8);
        crate(-40, .9, -8);
        building(-5, -17.8, 18, 15.5, 6, 0x77969b, 'BAY HARDWARE', 'UPGRADE YOUR EVERYDAY');
        box(-5, 2, -9.87, 6, 3, .12, 0x4e7379);
        sign('TOOLS / LIGHTS / SOLAR', 'BUILD SOMETHING BIGGER', -5, 2.5, -9.7, 7.2, 1.1, '#ecbd79', '#29464a');
        point('hardware', 'upgrades', 'Aadil / upgrades', -5, -7.9, 'BAY HARDWARE');
        for (let x of [-12, 2]) {
            s.cylinder(x, 1, -8.8, .4, .4, 1.6, 0x7a8c78, 8);
            s.sphere(x, 1.9, -8.8, .6, .8, .6, 0x86a469, 4, 6);
        }
        // A small braai yard, with a fictional owner and a courtyard.
        MZInterior.restaurant(world, renderer, s);
        box(37, .18, -8.8, 20, .18, 4, 0xab9b82);
        for (let x of [31, 46]) {
            box(x, .88, -8.4, 2.5, .17, 1.4, 0x956d51);
            box(x, .45, -8.4, .18, .85, .18, 0x375455);
            col(x, -8.4, 2.4, 1.4);
        }
        s.cylinder(48, 1.1, -8.5, .68, .61, 1.3, 0x4b5351, 10);
        s.cylinder(48, 1.78, -8.5, .7, .7, .06, 0xd99661, 10);
        point('braai', 'food', 'Thabo / braai break', 48, -6.9, 'BRAAI & CHILL');
        for (let x = 28; x < 51; x += 4) {
            box(x, 3, -7, .07, 5.8, .07, 0x4a655f);
            s.sphere(x, 3.2, -7, .11, .14, .11, 0xffdc95, 4, 6);
        }
        line(28, -7, 51, -7, 3.2, .03, 0x435351);
        // Workshop property. Entrance is west-facing, with a shutter that opens when bought.
        box(40, .12, 26, 24, .2, 23, 0x909890);
        box(40, 2.65, 37.3, 24, 5.3, .4, 0x9baba2);
        col(40, 37.3, 24, .4);
        box(52, 2.65, 26, .4, 5.3, 23, 0x9baba2);
        col(52, 26, .4, 23);
        box(40, 2.65, 14.7, 24, 5.3, .4, 0xb2b8a1);
        col(40, 14.7, 24, .4);
        for (let z of [17.95, 32.6]) {
            let d = z === 17.95 ? 6.3 : 9.2;
            box(28, 2.65, z, .4, 5.3, d, 0xb5bca8);
            col(28, z, .4, d);
        }
        box(28, 4.75, 24.5, .4, 1.1, 7, 0xb5bca8);
        box(40, 5.4, 26, 25, .23, 24, 0x5e7c7b);
        for (let z = 14; z < 39; z += 1)
            box(40, 5.58, z, 25, .12, .06, 0x79908b);
        col(28, 24.5, .45, 7, 'gate');
        let gate = new G();
        gate.box(0, 2.05, 0, .32, 4.1, 6.6, 0x657c79);
        for (let y = .3; y < 4; y += .25)
            gate.box(-.19, y, 0, .03, .06, 6.6, 0x91a29a);
        world.gateMesh = renderer.mesh(gate);
        sign('WORKSHOP 02', 'ROOM FOR A BIGGER STORY', 27.72, 4.55, 25, 9.2, 1.28, '#305554', '#f2d28f', -Math.PI / 2, true);
        point('workshop', 'property', 'Workshop 02', 26.5, 24.5, 'PROPERTY FOR SALE');
        world.buildings.push({ x: 40, z: 26, w: 24, d: 23, color: 0x98aaa0, name: 'WORKSHOP 02' });
        box(46, 1.1, 28, 7, .25, 2.2, 0x8e9b90);
        for (let x of [44, 47]) {
            box(x, 1.8, 28, 1.8, 1.2, 1.5, 0x647f73);
            s.cylinder(x, 2.6, 28, .5, .6, .4, 0xbccda5, 8);
        }
        col(46, 28, 7, 2.2);
        point('workBench', 'bench', 'Workshop mixing line', 46, 26.5, 'WORKSHOP 02', { requires: 'workshop' });
        crate(48, 0, 34);
        crate(49, 0, 34);
        crate(48, .9, 34);
        crate(49, .9, 34);
        point('runner', 'runner', 'Dispatch desk', 34, 32, 'WORKSHOP 02', { requires: 'workshop' });
        box(34, 1, 33, 3, .25, 1.4, 0x997555);
        box(34, 1.6, 33, .8, .8, .5, 0x5c8983);
        sign('DISPATCH', 'GIVE YOUR RUNNER STOCK', 34, 2.8, 35, 4.6, .8, '#335649', '#e6e7bb', Math.PI, true);
        // Taxi rank and non-interactive neighbourhood buildings.
        box(41, .1, -37, 26, .19, 15, 0x888f85);
        for (let x of [32, 38, 44, 50])
            box(x, .215, -37, .09, .022, 13, 0xd9d3b6);
        sign('SUNDOWN TAXI RANK', 'LOCAL RUNS / ALL DAY', 40, 3.1, -29.3, 10, 1.45, '#254a4c', '#efdb9c');
        box(35, 1.6, -29.3, .12, 3.2, .12, 0x405558);
        box(45, 1.6, -29.3, .12, 3.2, .12, 0x405558);
        point('taxi', 'taxi', 'Bongani / taxi ride', 31, -31, 'TAXI RANK');
        building(-50, -18, 11, 17, 4.4, 0xab9d8a, 'UBUNTU WHEELS', 'BOARDS / BIKES / SCOOTERS');
        building(-48, -38, 18, 16, 5.7, 0x93a59e, 'SUNDOWN ROOMS', 'A PLACE TO COME HOME TO');
        building(-24, -38, 21, 14, 4.2, 0xb79086, 'FRESH CUTS', 'NEIGHBOURHOOD BARBER');
        building(-4, -38, 15, 16, 7.9, 0xa5b6b5, 'BAY HOUSE', 'LOCAL CREATIVE SPACES');
        building(-51, 26, 10, 23, 4, 0xb9967b, 'CORNER HOUSE', '14 WEST LANE', 'north');
        building(-33, 44, 22, 14, 4.5, 0x9baa91, '', '', 'north');
        building(-6, 46, 22, 12, 4.2, 0xc1a091, '', '', 'north');
        // Small park beside home.
        box(-5, .08, 25, 25, .15, 28, 0x98a187);
        box(-3, .15, 25, 2, .09, 26, 0xbaa98c);
        box(-4, .16, 24, 22, .09, 2, 0xbaa98c);
        bench(-9, 18);
        bench(3, 31);
        tree(-9, 31, 1.1, true);
        tree(4, 17, .9, true);
        tree(5, 38, .9, true);
        tree(-13, 38, .8, false);
        sign('SUNSET SQUARE', 'TAKE A BREATHER', -1, 1.8, 12, 4.1, .8, '#476c58', '#ece1b1', Math.PI);
        box(-1, .8, 12, .14, 1.6, .14, 0x455c52);
        for (let [x, z, sz, p] of [[-44, 7, .84, true], [-17, -8, .78, true], [7, -26, 1.1, true], [-56, -35, 1.1, false], [55, -8, 1.15, false], [54, 41, 1.2, true], [-20, 36, 1, true], [-43, 35, .8, false], [-55, 44, .9, false], [31, 42, .95, false], [7, -46, .9, true], [55, -41, .9, false], [-56, 11, .9, true]])
            tree(x, z, sz, p);
        for (let [x, z] of [[-43, -7], [-16, 7], [7, -7], [27, 8], [54, -7], [10, 36], [25, -32], [-55, 7]])
            lamp(x, z);
        // Street sign, utility poles, bins and local colour.
        sign('UBUNTU AVENUE', 'SUNDOWN BAY', 9.6, 3.8, -7.1, 4, .65, '#3c6059', '#f2e5c8');
        box(9.6, 2, -7.1, .1, 4, .1, 0x4d5d59);
        sign('YARD LANE', 'HOME / WORKSHOP', 25.6, 3.4, 9.5, 3.5, .6, '#3c6059', '#f2e5c8', -Math.PI / 2);
        box(25.6, 1.75, 9.5, .1, 3.5, .1, 0x4d5d59);
        for (let x = -55; x <= 56; x += 24) {
            box(x, 4.1, -8.3, .18, 8.2, .18, 0x7d6a53);
            box(x, 7.65, -8.3, 2, .12, .16, 0x7d6a53);
            if (x < 56) {
                line(x, -8.3, x + 24, -8.3, 7.8, .027, 0x545956);
                line(x, -7.6, x + 24, -7.6, 7.6, .025, 0x545956);
            }
        }
        for (let [x, z] of [[-19, -8], [-16, 8], [8, 13], [28, -28], [51, -7]]) {
            box(x, .57, z, .7, 1.12, .7, 0x476c61);
            box(x, 1.17, z, .77, .12, .77, 0x284d48);
            col(x, z, .7, .7);
        }
        // Abstract, hand-drawn South African flag in the town square.
        box(6, 5, -31, .1, 10, .1, 0x647271);
        let fc = document.createElement('canvas');
        fc.width = 384;
        fc.height = 256;
        let f = fc.getContext('2d');
        f.fillStyle = '#dd604f';
        f.fillRect(0, 0, 384, 128);
        f.fillStyle = '#3d659b';
        f.fillRect(0, 128, 384, 128);
        const poly = (pts, c) => { f.fillStyle = c; f.beginPath(); pts.forEach(([x, y], i) => i ? f.lineTo(x, y) : f.moveTo(x, y)); f.closePath(); f.fill(); };
        poly([[0, 0], [160, 92], [384, 92], [384, 164], [160, 164], [0, 256]], '#ece9d3');
        poly([[0, 8], [167, 106], [384, 106], [384, 150], [167, 150], [0, 248]], '#438566');
        poly([[0, 25], [160, 128], [0, 231]], '#ebbd54');
        poly([[0, 47], [126, 128], [0, 209]], '#263839');
        world.signs.push({ quad: renderer.textureQuad(fc, 3, 2), x: 7.55, y: 8.8, z: -31, ry: 0 });
        // Decorative background skyline and far ridges.
        for (let i = 0; i < 35; i++) {
            let x = -120 + i * 7.5, z = -125 - rnd() * 18, h = 4 + rnd() * 15, w = 4 + rnd() * 5;
            box(x, h / 2, z, w, h, 7, 0x979e98);
            box(x, h + .2, z, w + .4, .4, 7.4, 0x83928d);
        }
        for (let i = 0; i < 12; i++) {
            let x = -160 + i * 28, sz = 22 + rnd() * 22, h = 12 + rnd() * 14;
            s.cylinder(x, h / 2 - 1, -160 - rnd() * 22, 0, sz, h, 0x9d9394, 5);
        }
        // Original edge walls removed: roads now join the outer districts.
        // The sky is rendered by the v3 atmosphere shader.

        // Character models, each assembled from original low-poly geometry.
        function person(skin, shirt, pants, hat = false, style = '') {
            const a = new G(), female = ['zanele','nandi','lerato','aisha','zoe','thandi'].includes(style);
            // Rounded silhouettes and smooth facial normals; small consistent eyes.
            a.ellipsoid(0,1.07,0,.31,.39,.19,shirt,9,14);
            a.cylinder(0,.78,0,.28,.25,.12,pants,12);
            a.cylinder(0,1.42,0,.09,.10,.18,skin,12);
            a.ellipsoid(0,1.68,.012,.207,.266,.195,skin,12,18);
            for (const side of [-1,1]) {
                a.ellipsoid(side*.205,1.67,0,.049,.080,.048,skin,7,9);
                a.ellipsoid(side*.090,1.721,.180,.058,.035,.020,0xcaa990,8,12);
                a.ellipsoid(side*.090,1.710,.192,.046,.022,.012,0xeee6d6,7,10);
                a.ellipsoid(side*.090,1.711,.204,.020,.021,.009,0x493a2c,7,10);
                a.ellipsoid(side*.090,1.712,.211,.011,.014,.005,0x243131,7,10);
                a.ellipsoid(side*.083,1.717,.216,.004,.004,.003,0xfdf4d4,5,7);
                a.beam([side*.050,1.76,.178],[side*.14,1.77,.162],.014,0x47352d,7);
                /* Shoulder and arm geometry is articulated below. */
                
                
                
                a.box(side*.067,1.337,.173,.11,.16,.028,0xe2ceb0,side*.32);
            }
            a.ellipsoid(0,1.654,.200,.042,.065,.050,skin,8,12);
            a.beam([-.052,1.569,.183],[0,1.56,.196],.010,0x765044,7);
            a.beam([0,1.56,.196],[.052,1.569,.183],.010,0x765044,7);
            a.ellipsoid(0,1.879,-.014,.209,.080,.187,0x3f332e,9,14);
            a.ellipsoid(0,1.798,-.138,.183,.163,.080,0x3f332e,8,12);
            if(female) {
                if(['zanele','nandi'].includes(style)) {
                    a.ellipsoid(0,1.893,-.005,.230,.132,.207,style==='zanele'?0xd6a35e:0x987ba1,9,16);
                    a.ellipsoid(-.10,1.976,-.03,.120,.13,.120,style==='zanele'?0xe7c18b:0xb096b1,8,12);
                    for (let i=0;i<7;i++) a.beam([-.19+i*.06,1.86,.15],[-.11+i*.047,1.975,.03],.008,0xe6d0a7,5);
                } else {
                    a.ellipsoid(.13,1.80,-.13,.15,.21,.13,0x3b2f2d,8,12);
                    for(let j=0;j<6;j++) a.ellipsoid(-.17+j*.06,1.87,.10,.06,.059,.072,0x4a3830,6,9);
                }
                for(let side of [-1,1]) a.ellipsoid(side*.216,1.605,.021,.023,.036,.016,0xe8c681,7,9);
            }
            if(style==='nandi'||style==='thabo') {
                a.box(0,1.01,.180,.41,.53,.025,0x335a55);
                a.box(0,.925,.2,.28,.14,.028,0x729688);
                a.box(0,1.22,.199,.13,.04,.02,0xefdab0);
            } else {
                for(let y=.9;y<1.3;y+=.10) a.ellipsoid(.017,y,.189,.013,.013,.012,0xdfd7b8,4,7);
                a.box(-.17,1.18,.167,.14,.11,.02,0xede0b0);
            }
            if(hat&&!female){a.cylinder(0,1.948,-.01,.204,.226,.16,shirt,14);a.ellipsoid(0,1.904,.193,.246,.033,.154,shirt,7,14);a.box(0,1.971,.203,.08,.055,.015,0xe7d3a1);}
            const l=new G();l.cylinder(0,.46,0,.112,.088,.64,pants,12);
            l.ellipsoid(0,.16,.08,.119,.11,.23,0x364a47,8,12);
            l.box(0,.072,.087,.24,.04,.405,0xc9c5b0);
            l.box(0,.228,.13,.12,.018,.06,0xbbbcab);
            const arms=[-1,1].map(side=>{const q=new G();q.ellipsoid(0,0,0,.12,.145,.16,shirt,7,10);q.beam([side*.03,.01,0],[side*.09,-.27,.018],.081,shirt,9);q.beam([side*.09,-.28,.018],[side*.085,-.50,.063],.062,skin,9);q.ellipsoid(side*.083,-.52,.065,.064,.09,.051,skin,7,9);return renderer.mesh(q);});const phone=new G();phone.box(0,0,0,.115,.22,.025,0x243c44);phone.box(0,0,.015,.088,.174,.01,0x78a9a2);return {body:renderer.mesh(a),leg:renderer.mesh(l),arms,phone:renderer.mesh(phone)};
        }
        const skins = [0x855c41, 0xba8d65, 0xe1b99a, 0xa7714e, 0x694e3c, 0xc4936b, 0x946847, 0xe4bb9b];
        const people = [['sipho', 'Sipho', -13.5, 8, 0x669f89, 'Just finished my shift. Got anything interesting?'], ['aisha', 'Aisha', .3, -7.5, 0xc88d66, 'Word gets around fast in this neighbourhood.'], ['lerato', 'Lerato', 7, 21, 0x9b83b2, 'I like something a little different.'], ['pieter', 'Pieter', 26.25, -23, 0x7c9ea7, 'I have a few minutes before my taxi.'], ['ravi', 'Ravi', 49, 9, 0xc9b46f, 'Keep the quality good and I will be back.'], ['zoe', 'Zoe', -10, 32, 0xca9794, 'The square is my favourite place after work.'], ['musa', 'Musa', -47, 8, 0x729c9b, 'First time seeing you around here. Welcome.'], ['thandi', 'Thandi', 26, 38.4, 0xd3b397, 'Everyone starts somewhere, hey.']];
        people.forEach((p, i) => world.customers.push({ id: p[0], name: p[1], x: p[2], z: p[3], homeX: p[2], homeZ: p[3], ry: Math.PI * .3, kind: 'CUSTOMER', type: 'customer', greeting: p[5], model: person(skins[i], p[4], 0x3f5657, i % 3 === 0, p[0]), phase: rnd() * 6, walk: false, cooldown: 0 }));
        world.pedestrians.push({ name: 'Zanele', x: -34.8, z: 18.1, ry: Math.PI, model: person(0x946747, 0x5c9688, 0x536d66, false, 'zanele'), phase: 2, stationary: true });
        world.pedestrians.push({ name: 'Nandi', x: -32.5, z: -8.1, ry: 0, model: person(0x8d5e43, 0xdfb877, 0x4d6660, false, 'nandi'), phase: 0, stationary: true });
        world.pedestrians.push({ name: 'Aadil', x: -7.8, z: -8.5, ry: 0, model: person(0xb78c63, 0x86a7a0, 0x4b5c5f, false), phase: 1, stationary: true });
        world.pedestrians.push({ name: 'Thabo', x: 49.8, z: -8.2, ry: 0, model: person(0x73543e, 0xf0d6a4, 0x4e6969, false, 'thabo'), phase: 2, stationary: true });
        for (let i = 0; i < 5; i++) {
            let path = i % 2 ? [[-51, -7], [-18, -7], [8, -7]] : [[-48, 7], [-18, 7], [8, 7]];
            world.pedestrians.push({ name: 'Neighbour', x: path[0][0] + i * 5, z: path[0][1], ry: 0, model: person(skins[i], [0xb3a392, 0x90aab0, 0xa194ad, 0xa5ad88, 0xc09670][i], 0x525f5d, i % 2 === 0), phase: rnd() * 6, path, index: 1, speed: .6 + rnd() * .25 });
        }
        world.pedestrians.push({name:'Kabelo',x:35.3,z:31.5,ry:Math.PI,model:person(0x916340,0xbb8c57,0x40585b,true,'kabelo'),phase:1,stationary:true,requires:'workshop'});
        const patrolPaths = [[[-52, 3], [8, 3], [20, 3], [20, -43], [16, -43], [16, -3], [-52, -3]], [[21, 44], [21, 7], [21, -22], [15, -22], [15, 44]]];
        patrolPaths.forEach((path, i) => world.police.push({ id: 'patrol' + i, x: path[0][0], z: path[0][1], ry: 0, phase: i, model: person(skins[i + 3], 0x426273, 0x293f50, true), path, index: 1, speed: 1.55, chase: false }));
        function taxi(color = 0xe4e2ca) { let a = new G(); a.box(0, .9, 0, 2.15, 1.1, 4.5, color); a.box(0, 1.74, -.1, 2.05, .7, 3.7, color); a.box(0, 2.13, -.1, 2.08, .12, 3.8, 0xe9e4d3); a.box(0, 1.67, 1.77, 1.79, .57, .06, 0x456b74); a.box(0, 1.65, -1.99, 1.77, .54, .055, 0x456b74); for (let x of [-1.04, 1.04]) {
            for (let z of [-1.23, -.3, .65])
                a.box(x, 1.68, z, .03, .51, .75, 0x476d74);
            a.box(x, 1.22, 0, .035, .19, 4.13, 0xdbb765);
            a.box(x, 1.03, 0, .038, .12, 4.1, 0x689a7e);
        } a.box(0, .54, 2.28, 2.19, .19, .15, 0x405658); for (let x of [-.76, .76]) {
            a.box(x, .99, 2.274, .34, .22, .035, 0xf3d69a);
            a.box(x, 1, -2.273, .24, .31, .035, 0xad6756);
            for (let z of [-1.45, 1.42]) {
                a.sphere(x < 0 ? -1.1 : 1.1, .43, z, .19, .43, .43, 0x33413f, 6, 10);
                a.sphere(x < 0 ? -1.24 : 1.24, .43, z, .035, .23, .23, 0x9ba79c, 5, 8);
            }
        } return renderer.mesh(a); }
        world.pedestrians.push({name:'Tumi',x:-46.25,z:-8.65,ry:0,phase:0,stationary:true,model:person(0x986b50,0x5b899c,0x344b54,true,'tumi')});
        world.taxiMesh = taxi();
        world.parkedTaxis = [{ x: 34, z: -37, ry: 0 }, { x: 41, z: -39, ry: 0 }, { x: 48, z: -36.5, ry: .1 }];
        world.cars = [{ x: -30, z: -3, ry: Math.PI / 2, speed: 5.6 }, { x: 32, z: 3, ry: -Math.PI / 2, speed: -4.5 }];
        let plant = new G();
        plant.cylinder(0, .55, 0, .06, .09, 1.1, 0x759d83, 6);
        for (let i = 0; i < 7; i++) {
            let a = i * 2.4, y = .2 + i * .12;
            plant.sphere(Math.cos(a) * .25, y, Math.sin(a) * .25, .35, .12, .25, [0x9bc89a, 0x86b69a, 0xb4d6a0][i % 3], 3, 5);
        }
        plant.sphere(0, 1.25, 0, .2, .27, .2, 0xa8d3b3, 4, 6);
        world.plantMesh = renderer.mesh(plant);
        let pack = new G();
        pack.box(0, .3, 0, .35, .55, .18, 0x9ecbad);
        pack.box(0, .58, 0, .37, .035, .2, 0xd7dbc0);
        pack.box(0, .34, .097, .24, .2, .012, 0xe9d294);
        world.packMesh = renderer.mesh(pack);
        MZExpansion.build({world,renderer,box,col,sign,point,tree,bench,crate,building,person,rnd});
        MZOutdoorWorld.build({world,renderer,box,col,sign,point,tree,bench,crate,building,person,rnd});
        MZCommerceWorld.build({world,renderer,box,col,sign,point,tree,bench,crate,building,person,rnd});
        MZNightWorld.build({world,renderer,box,col,sign,point,tree,bench,crate,building,person,rnd});
        world.static = renderer.mesh(s);
        world.isFree = (x, z, state, r = .31) => { if (x < world.bounds.minX+r || x > world.bounds.maxX-r || z < world.bounds.minZ+r || z > world.bounds.maxZ-r)
            return false; return !world.colliders.some(c => (c.kind !== 'gate' || !state.workshop) && x > c.x1 - r && x < c.x2 + r && z > c.z1 - r && z < c.z2 + r); };
        world.inHome = (x, z) => x > -42.7 && x < -21.3 && z > 13 && z < 31.2;
        world.getPoint = id => world.points.find(p => p.id === id) || world.customers.find(p => p.id === id);
        // Small substeps prevent tunnelling through thin walls, even on slow devices.
        world.move = (obj, dx, dz, state, r = .32) => {
            if (!Number.isFinite(dx) || !Number.isFinite(dz))
                return;
            const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dz)) / .18));
            for (let i = 0; i < steps; i++) {
                if (world.isFree(obj.x + dx / steps, obj.z, state, r))
                    obj.x += dx / steps;
                if (world.isFree(obj.x, obj.z + dz / steps, state, r))
                    obj.z += dz / steps;
            }
        };
        world.drawPerson=(p,time)=>MZPeople.draw(renderer,world,p,time);
        world.render = (state, time) => { renderer.draw(world.static); if (!state.workshop)
            renderer.draw(world.gateMesh, M.model(28, 0, 24.5)); for (let p of [...world.customers, ...world.pedestrians, ...world.police])
            if((!p.requires||state[p.requires])&&Math.hypot(p.x-state.player.x,p.z-state.player.z)<140)world.drawPerson(p, time); for (let c of [...world.parkedTaxis, ...world.cars])
            renderer.draw(world.taxiMesh, M.model(c.x, .1, c.z, c.ry)); state.plants.forEach((p, i) => { if (p) {
            let q = world.growPositions[i], size = .23 + .77 * Math.min(1, (state.sim - p.start) / p.duration);
            renderer.draw(world.plantMesh, M.model(q[0], .8, q[1], i, size));
        } }); if (state.jobs.length || Object.values(state.products).some(n => n > 0)) {
            for (let i = 0; i < 3; i++)
                renderer.draw(world.packMesh, M.model(-40 + i * .5, 1.13, 21.3));
        } renderer.drawSigns(world.signs); };
        MZVisuals.install(renderer, world);
        MZRideWorld.install(renderer, world);MZCarWorld.install(renderer,world);
        MZInterior.install(renderer, world);
        MZOutdoorWorld.install(renderer,world);
        MZCommerceWorld.install(renderer,world);MZNightWorld.install(renderer,world);
        return world;
    };
})();
