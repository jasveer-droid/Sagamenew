'use strict';
/** Shared map, contacts and mode rules. One source of truth for saves, UI and world. */
(function(root){
 const bounds=Object.freeze({minX:-270,maxX:124,minZ:-130,maxZ:190});
 const districts=[
  {id:'enterprise',name:'Enterprise Quarter',target:'enterpriseQuarter',short:'Enterprise',description:'Twenty walk-in workplaces, business ownership, a bank and a careers centre.'},
  {id:'commons',name:'Riverside Commons',target:'commons',short:'Commons',description:'A garden park, basketball court, postcards and a recycling project.'},
  {id:'harbour',name:'Harbour Works',target:'harbour',short:'Harbour',description:'A working parcel depot, public mural route and waterside lookout.'},
  {id:'centre',name:'Sundown Centre',target:'bench',short:'Centre',description:'Your yard, familiar shops, the square and Ubuntu Wheels.'},
  {id:'market',name:'Masakhane Market',target:'marketSquare',short:'Market',description:'Colourful market stalls, a supply kiosk and eight new customers.'},
  {id:'bayfront',name:'Bayfront Walk',target:'bayfront',short:'Bayfront',description:'A seaside promenade, outdoor cafe and eight new customers.'},
  {id:'heights',name:'Jacaranda Heights',target:'heights',short:'Heights',description:'Tree-lined streets, a community green and eight new customers.'}
 ];
 const rows=[
  ['nomsa','Nomsa',-103,-7,'market','glow','My stall is packed away. What have you brought today?','Flower seller'],
  ['dev','Dev',-91,8,'market','sunburst','I am taking a break from the repair counter. Show me your stock.','Phone technician'],
  ['busi','Busi',-110,21,'market','mist','A little variety would be lovely. Let us see your offer.','Tailor'],
  ['yusuf','Yusuf',-95,29,'market','prism','I like the premium blends, but I will look at anything.','Shopkeeper'],
  ['naledi','Naledi',-67,25,'market','mist','All finished at the studio. Time to browse the market.','Designer'],
  ['andre','Andre',-67,-15,'market','sunburst','You have come a long way from The Yard. Let us trade.','Mechanic'],
  ['precious','Precious',-98,-35,'market','glow','Keep it simple and fair. What is your asking price?','Baker'],
  ['kiran','Kiran',-70,-44,'market','prism','A new face on this side of town. Welcome to the market.','Courier'],
  ['lwazi','Lwazi',92,-7,'bayfront','sunburst','The promenade is a good place to take a break.','Cafe manager'],
  ['sasha','Sasha',108,8,'bayfront','mist','The sea breeze is perfect. What is in your bag?','Photographer'],
  ['themba','Themba',110,22,'bayfront','glow','A fair price and a friendly chat. That is my kind of deal.','Boat repairer'],
  ['fatima','Fatima',115,39,'bayfront','prism','I enjoy something unusual. Show me your best blend.','Architect'],
  ['johan','Johan',84,31,'bayfront','glow','I am off duty now. Let us see what you have.','Bus driver'],
  ['anele','Anele',90,-31,'bayfront','sunburst','Busy morning at the office. Good to get outside.','Accountant'],
  ['meera','Meera',111,-27,'bayfront','mist','I am waiting for a friend, but there is time for a trade.','Illustrator'],
  ['sizwe','Sizwe',84,-48,'bayfront','prism','You can find me here after my deliveries.','Delivery rider'],
  ['noxolo','Noxolo',-52,-79,'heights','mist','The community green is peaceful after work.','Librarian'],
  ['owen','Owen',-32,-78,'heights','glow','You made it up to the Heights. What are you offering?','Carpenter'],
  ['zandile','Zandile',-12,-79,'heights','sunburst','I like a bit of colour. Show me your range.','Ceramic artist'],
  ['imran','Imran',4,-78,'heights','prism','Quality matters, but the price must be right.','IT technician'],
  ['elsa','Elsa',30,-79,'heights','mist','A walk before supper is my favourite routine.','Florist'],
  ['mpho','Mpho',48,-78,'heights','glow','Good evening, neighbour. Let us see your stock.','Electrician'],
  ['karabo','Karabo',-54,-58,'heights','prism','The new road makes the whole town feel closer.','Music producer'],
  ['rani','Rani',46,-56,'heights','sunburst','I have closed my shop for the day. What have you made?','Bookshop owner']
 ];
 const customers=rows.map(([id,name,x,z,district,favourite,greeting,role])=>({id,name,x,z,district,favourite,greeting,role}));
 const south=[['nathi','Nathi',-91,114,'commons','glow','Good to see someone enjoying the court.','Court volunteer'],['farah','Farah',-18,132,'commons','mist','The gardens look lovely today.','Gardener'],['lucas','Lucas',-86,174,'commons','sunburst','We painted this mural together.','Mural artist'],['gugu','Gugu',-65,94,'commons','prism','A clean park makes everyone feel welcome.','Community organiser'],['simon','Simon',52,113,'harbour','glow','A quick break between parcel runs.','Parcel clerk'],['aya','Aya',88,115,'harbour','mist','I love looking out across the harbour.','Designer'],['bongiwe','Bongiwe',109,152,'harbour','prism','Just finished at the work yard.','Fabricator'],['arjun','Arjun',29,168,'harbour','sunburst','The studios keep this place busy.','Sound technician']];
 for(let i=0;i<south.length;i++){const [id,name,x,z,district,favourite,greeting,role]=south[i];customers.push({id,name,x,z,district,favourite,greeting,role,localIndex:i%4});}
 const originalIds=['sipho','aisha','lerato','pieter','ravi','zoe','musa','thandi'];
 const ids=[...originalIds,...customers.map(n=>n.id)];
 const points=['communityBank','commerceATM','careerCentre','enterpriseQuarter','enterpriseTaxi','commons','harbour','commonsTaxi','harbourTaxi','court','depot','recycling','parkRest','postGarden','postMural','postHarbour','recycle0','recycle1','recycle2','recycle3','recycle4','recycle5','parcel0','parcel1','parcel2','carShop','restaurant','table1','table2','table3','table4','marketSquare','marketSupply','marketTaxi','bayfront','bayFood','bayTaxi','heights','heightsTaxi'];
 const taxiStops={enterprise:[-129,-84,Math.PI],commons:[9,79,Math.PI/2],harbour:[83,157,-Math.PI/2],home:[-32,9.4,Math.PI],spaza:[-30,-6.7,0],shop:[26,24.5,Math.PI/2],square:[-3,17,Math.PI],market:[-82,7,-Math.PI/2],bayfront:[102,12,Math.PI],heights:[8,-73,-Math.PI/2]};
 function districtAt(x,z){return x<-124?'enterprise':z>57?(x<18?'commons':'harbour'):z<-53?'heights':x<-60?'market':x>60?'bayfront':'centre';}
 function isFree(s){return s.mode==='free';}
 function canCraft(s,r){return isFree(s)||s.rep>=r.rep;}
 function streetValue(r,n){return r.value*(n?.favourite&&root.MZData.RECIPES[n.favourite]===r?1.10:1);}
 function setMode(s,mode){
  if(!['story','free'].includes(mode))return false;
  s.mode=mode;
  if(mode==='free'){s.track=null;s.freeGuideSeen=false;}
  else {
   if(!s.story.flags.siphoDelivered&&s.story.chapter<=6&&!s.orders.some(o=>o.npc==='sipho')){
    if(s.orders.length>=8)s.orders.pop();
    s.orders.push({id:++s.orderSeq,npc:'sipho',recipe:'glow',qty:2,pay:170});
   }
   s.track=root.MZStory.current(s).target;
  }
  return true;
 }
 root.MZNeighbourhood={bounds,districts,customers,ids,points,taxiStops,districtAt,isFree,canCraft,streetValue,setMode};
})(typeof window==='undefined'?globalThis:window);
