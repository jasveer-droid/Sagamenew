'use strict';
/** Original 3D ride models, showroom, and actual-model shop previews. */
(function(root){
    const {Geometry:G,M,V}=MZ;
    function wheel(g,z,radius,y,tyre=0x283f42){
        const rings=28,sides=8,tube=radius*.16;
        const p=(a,b)=>[Math.cos(b)*tube,y+Math.cos(a)*(radius+Math.sin(b)*tube),z+Math.sin(a)*(radius+Math.sin(b)*tube)];
        for(let i=0;i<rings;i++)for(let j=0;j<sides;j++)
            g.quad(p(i*2*Math.PI/rings,j*2*Math.PI/sides),p((i+1)*2*Math.PI/rings,j*2*Math.PI/sides),p((i+1)*2*Math.PI/rings,(j+1)*2*Math.PI/sides),p(i*2*Math.PI/rings,(j+1)*2*Math.PI/sides),tyre);
        g.ellipsoid(0,y,z,.10,.065,.065,0xe4d6b4,7,10);
        for(let i=0;i<10;i++){let a=i*Math.PI/5;g.beam([0,y,z],[0,y+Math.cos(a)*radius*.86,z+Math.sin(a)*radius*.86],.009,0xacbdb5,4);}
    }
    function model(id){
        if(MZMobility.RIDES[id].car)return MZCarWorld.model(id);
        const g=new G(),c=MZMobility.RIDES[id].colour,metal=0xb6c6b7,dark=0x2a4349;
        if(id==='skateboard'){
            g.box(0,.22,0,.31,.075,.94,0xba8c56);g.ellipsoid(0,.228,-.44,.154,.05,.16,0xd6b57b,6,12);g.ellipsoid(0,.228,.44,.154,.05,.16,0xd6b57b,6,12);
            g.box(0,.264,0,.286,.012,.90,0x354c4e);for(let i=0;i<3;i++)g.box(0,.272,-.19+i*.17,.24,.008,.05,c,-.35);
            for(let z of [-.33,.33]){g.beam([-.21,.12,z],[.21,.12,z],.032,metal,8);for(let x of [-.20,.20]){g.ellipsoid(x,.115,z,.065,.10,.10,0xeaca91,8,14);g.ellipsoid(x*1.32,.115,z,.007,.036,.036,0x789e95,7,10);}}
        }else if(id==='bicycle'){
            wheel(g,-.76,.34,.39);wheel(g,.76,.34,.39);
            const back=[0,.39,.76],front=[0,.39,-.76],pedal=[0,.4,.15],seat=[0,.99,.38],head=[0,1.04,-.57];
            for(let [a,b] of [[back,pedal],[back,seat],[pedal,seat],[seat,head],[pedal,head],[head,front]])g.beam(a,b,.037,c,9);
            g.beam([0,.92,.38],[0,1.11,.37],.025,metal);g.ellipsoid(0,1.14,.35,.14,.05,.21,dark,7,12);
            g.beam(head,[0,1.28,-.64],.027,metal);g.beam([-.36,1.27,-.69],[.36,1.27,-.69],.025,metal);
            for(let x of [-.32,.32])g.beam([x,1.27,-.64],[x,1.27,-.80],.046,dark,9);
            g.beam([-.23,.4,.15],[.23,.4,.15],.024,metal);for(let x of [-.25,.25])g.box(x,.4,.15,.11,.065,.20,dark);
            g.box(0,.87,-.83,.45,.32,.29,0x456960);g.box(0,1.034,-.83,.40,.012,.24,0x233c41);for(let x of [-.20,.20])g.box(x,.89,-.99,.016,.23,.018,metal);
            g.ellipsoid(0,1.01,-1.005,.075,.07,.012,0xffe1a5,7,12);
        }else{
            wheel(g,-.72,.20,.235);wheel(g,.64,.20,.235);
            g.box(0,.245,.1,.32,.14,1.03,c);g.box(0,.325,.1,.26,.025,.88,dark);
            g.beam([0,.26,-.71],[0,1.29,-.59],.055,c,12);g.beam([-.36,1.29,-.62],[.36,1.29,-.62],.03,metal);
            for(let x of [-.29,.29])g.beam([x,1.29,-.68],[x,1.29,-.53],.05,dark,10);
            g.box(0,1.26,-.63,.16,.07,.13,dark);g.box(0,1.302,-.63,.10,.008,.07,0x99e1c4);
            g.ellipsoid(0,1.1,-.692,.06,.062,.025,0xffdc8f,8,12);g.box(0,.42,.65,.19,.06,.17,c);
            g.box(0,.455,.733,.08,.035,.015,0xf08972);
        }
        return g;
    }
    function preview(r,mesh,id){
        const gl=r.gl,c=r.c;
        r.canvas.width=r.canvas.height=300;gl.viewport(0,0,300,300);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(r.cp);
        const car=MZMobility.RIDES[id].car,spec=MZMobility.RIDES[id],dist=car?spec.halfLength*3.0:1;const eye=car?[dist*.70,2.35+(spec.body==='minibus'?.25:0),-dist*.85]:id==='skateboard'?[1.4,1.05,-1.7]:[2.25,1.85,-2.8];const targetY=car?.91:id==='skateboard'?.16:.66;
        gl.uniformMatrix4fv(c.uP,false,M.perspective(.7,1,.1,20));
        gl.uniformMatrix4fv(c.uV,false,M.lookAt(eye,[0,targetY,0]));
        gl.uniform3fv(c.uSun,V.norm([-.5,.9,-.6]));gl.uniform3fv(c.uFog,[.12,.24,.25]);gl.uniform1f(c.uBright,1.18);gl.uniform1f(c.uAmbient,.70);r.bindVisuals();gl.uniform1f(c.uShadowOn,0);
        if(c.uEye)gl.uniform3fv(c.uEye,eye);r.draw(mesh,M.model());
        if(car){
            // Fit the complete rendered car instead of clipping a fixed crop.
            const raw=document.createElement('canvas');raw.width=raw.height=300;
            const rx=raw.getContext('2d',{willReadFrequently:true});rx.drawImage(r.canvas,0,0);
            const pixels=rx.getImageData(0,0,300,300).data;let x0=300,y0=300,x1=-1,y1=-1;
            for(let y=0;y<300;y++)for(let x=0;x<300;x++)if(pixels[(y*300+x)*4+3]>8){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
            const out=document.createElement('canvas');out.width=360;out.height=220;
            if(x1>=x0){const w=x1-x0+1,h=y1-y0+1,scale=Math.min(332/w,194/h);out.getContext('2d').drawImage(raw,x0,y0,w,h,(360-w*scale)/2,(220-h*scale)/2,w*scale,h*scale);}
            return out.toDataURL('image/png');
        }
        return r.canvas.toDataURL('image/png');
    }
    function install(r,w){
        w.rideMeshes={};w.ridePreviews={};
        for(const id of Object.keys(MZMobility.RIDES)){w.rideMeshes[id]=r.mesh(model(id));w.ridePreviews[id]=preview(r,w.rideMeshes[id],id);}
        const a=new G();
        // Counter and a clean, street-facing display next to Sunset Spaza.
        a.box(-50,.89,-8.50,8.5,1.6,.68,0x325d60);a.box(-50,1.72,-8.5,8.7,.12,.9,0xdcc293);
        for(let x of [-53,-50.7,-48.4]){a.box(x,.32,-7.87,1.75,.38,1.04,0x3b6565);a.box(x,.524,-7.87,1.79,.04,1.08,0xa2b5a1);}
        a.box(-50,3.28,-8.35,10.4,.18,2.6,0x4a8a81);a.box(-50,3.06,-7.03,10.4,.38,.08,0x9bcaaf);
        for(let x of [-54.95,-45.05])a.box(x,1.6,-7.95,.10,3.2,.10,0x789f88);
        // Flat sign behind the display; never cover the customer interaction target.
        w.signs.push({x:-50,y:2.47,z:-8.92,lit:true,quad:r.makeSign('UBUNTU WHEELS','BOARDS / BIKES / SCOOTERS',9.2,1.14,'#214c51','#f7d9a2')});
        w.signs.push({x:-50,y:1.03,z:-8.135,lit:true,quad:r.makeSign('OWN THE JOURNEY','RIDES FROM R250 / REPAIRS & FIRST AID',7.1,.69,'#325d60','#e7e0b9')});
        // Home parking markings: owned rides remain yours after every session.
        for(let z of [16.4,18.1,19.8]){a.box(-23.0,.31,z,1.6,.012,1.2,0x7a9e84);a.box(-23.0,.322,z-.6,1.6,.016,.035,0xe2c993);}
        w.garageMesh=r.mesh(a);w.shadowMeshes.push(w.garageMesh);
        w.colliders.push({x1:-54.25,x2:-45.75,z1:-8.85,z2:-8.15,kind:'solid'});
        w.points.push({id:'rideShop',type:'rideShop',name:'Ubuntu Wheels / ride shop',x:-46.25,z:-6.65,kind:'TUMI / RIDES & FIRST AID'});
        const original=w.render;
        w.render=function(s,time){
            r.draw(w.garageMesh);
            Object.keys(w.rideMeshes).filter(id=>!MZMobility.RIDES[id].car).forEach((id,i)=>{
                r.draw(w.rideMeshes[id],M.model(-53+i*2.3,.56,-7.87,Math.PI/2,.80));
                if(s.rides.owned[id] && !(s.rides.riding && s.rides.equipped===id))r.draw(w.rideMeshes[id],M.model(-23,.34,16.4+i*1.7,Math.PI/2,.83));
            });
            if(s.rides.riding && w.rideMeshes[s.rides.equipped]){
                const isCar=MZMobility.RIDES[s.rides.equipped]?.car;const mat=M.model(s.player.x,(isCar?.105+(w.rideDynamics?.heave||0):.22)+(w.jumpHeight||0),s.player.z,-(w.rideHeading??s.player.yaw));
                if(MZMobility.RIDES[s.rides.equipped]?.car&&!s.settings.reducedMotion){
                    const pitch=Math.max(-.08,Math.min(.08,w.ridePitch||0)),roll=Math.max(-.10,Math.min(.10,w.rideRoll||0)),cp=Math.cos(pitch),sp=Math.sin(pitch),cr=Math.cos(roll),sr=Math.sin(roll),local=[cr,cp*sr,sp*sr,-sr,cp*cr,sp*cr,0,-sp,cp],base=mat.slice();
                    for(let col=0;col<3;col++)for(let row=0;row<3;row++)mat[col*4+row]=base[row]*local[col*3]+base[4+row]*local[col*3+1]+base[8+row]*local[col*3+2];
                }
                if(isCar)MZCarWorld.drawVehicle(r,w,s,w.rideDynamics||{},mat,time);else r.draw(w.rideMeshes[s.rides.equipped],mat);
            }
            original(s,time);
        };
        r.resize();
    }
    root.MZRideWorld={install,preview};
})(window);
