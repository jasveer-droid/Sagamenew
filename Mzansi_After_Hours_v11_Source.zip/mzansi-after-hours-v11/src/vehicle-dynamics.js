'use strict';
/** Roadcraft: small, bounded vehicle helpers, not BeamNG or a full soft-body car.
 * A rigid chassis handles contact. A spring-linked 63-node visual cage skins the
 * car body; four plastic crush zones persist in the save. Wheels remain attached.
 * All dimensions and tuning are invented game values. No external dependencies.
 */
(function(root){
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 const finite=(x,f=0)=>Number.isFinite(x)?x:f;
 const ZONES=['front','rear','left','right'];
 function clean(d){const out={};for(const k of ZONES)out[k]=clamp(finite(d?.[k]),0,1);return out;}
 function condition(d){d=clean(d);const v=ZONES.map(k=>d[k]);return Math.round(clamp(100-Math.max(...v)*48-v.reduce((a,b)=>a+b,0)*13,5,100));}
 function crush(d,speed,x=0,z=-1){d=clean(d);if(!Number.isFinite(speed)||speed<3)return d;const axis=Math.abs(z)>=Math.abs(x)?(z<0?'front':'rear'):(x<0?'left':'right');const amount=clamp((speed-2)/30,.04,.72);d[axis]=clamp(d[axis]+amount*(1-d[axis]*.35),0,1);return d;}
 function damaged(d){return condition(d)<100;}
 function surface(world,x,z,wet=false){
  if(!Array.isArray(world.roads))return {name:wet?'Wet asphalt':'Asphalt',mu:wet?.64:1.06,rough:.002,drag:.18};
  for(const a of world.roads)if(Math.abs(x-a.x)<=a.w/2&&Math.abs(z-a.z)<=a.d/2)return {name:wet?'Wet asphalt':'Asphalt',mu:wet?.64:1.06,rough:.003,drag:.18};
  for(const a of world.roads)if(Math.abs(x-a.x)<=a.w/2+3.2&&Math.abs(z-a.z)<=a.d/2+3.2)return {name:'Paving',mu:wet?.68:.95,rough:.013,drag:.28};
  // Courtyards/forecourts are firm; open ground beyond streets is loose.
  if((x<-44&&x>-65&&z>27&&z<50)||(x>-45&&x<-20&&z>11&&z<33))return {name:'Forecourt',mu:.95,rough:.006,drag:.25};
  return {name:'Loose ground',mu:wet?.47:.65,rough:.038,drag:.62};
 }
 function spring(value,velocity,target,k,c,dt){const a=(target-value)*k-velocity*c;velocity+=a*dt;value+=velocity*dt;return [value,velocity];}
 function updateSuspension(m,r,accel,lateral,road,h){
  m.suspension??=[0,0,0,0];m.suspensionV??=[0,0,0,0];m.wheelSpin??=0;
  const moving=Math.min(1,Math.abs(m.speed||0)/2),rough=road.rough*moving;
  for(let i=0;i<4;i++){const target=Math.sin(m.distance*4.8+(i%2)*1.3+Math.floor(i/2)*2.2)*rough;
   const s=spring(m.suspension[i],m.suspensionV[i],target,140,17,h);m.suspension[i]=clamp(s[0],-.14,.14);m.suspensionV[i]=clamp(s[1],-2,2);}
  const k=(r.spring||34)*3,c=(r.damping||9)*1.65;
  let t=spring(m.pitch||0,m.pitchV||0,clamp(accel*.012,-.15,.13),k,c,h);m.pitch=clamp(t[0],-.2,.2);m.pitchV=t[1];
  t=spring(m.roll||0,m.rollV||0,clamp(-lateral*.018,-.16,.16),k,c,h);m.roll=clamp(t[0],-.23,.23);m.rollV=t[1];
  m.heave=m.suspension.reduce((a,b)=>a+b,0)/4;
 }
 function bodyHeight(r){return ['van','minibus'].includes(r.body)?2.17:r.body==='suv'?1.90:r.body==='coupe'?1.28:r.body==='classic'?1.43:r.body==='electric'?1.45:1.56;}
 function deformPoint(x,y,z,r,d){const w=r.halfWidth,l=r.halfLength,H=bodyHeight(r);const nose=Math.pow(clamp(-z/l,0,1),2),tail=Math.pow(clamp(z/l,0,1),2),left=Math.pow(clamp(-x/w,0,1),2),right=Math.pow(clamp(x/w,0,1),2);
  const lo=clamp((1.55-y)/1.15,0,1),fold=Math.sin(z*7+x*3.3)*.07;
  return [x+(d.left*left-d.right*right)*.46*(.55+lo*.45),y+(d.front*nose+d.rear*tail)*(.11+fold)*lo,z+(d.front*nose-d.rear*tail)*Math.min(.88,l*.43)*(.4+.6*lo)];
 }
 function createCage(r,damage){
  const d=clean(damage),nodes=[],beams=[],nx=3,ny=3,nz=7,w=r.halfWidth,l=r.halfLength,H=bodyHeight(r),idx=(i,j,k)=>(k*ny+j)*nx+i;
  for(let k=0;k<nz;k++)for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const base=[-w+2*w*i/(nx-1),.34+(H-.34)*j/(ny-1),-l+2*l*k/(nz-1)],target=deformPoint(...base,r,d);nodes.push({base,target,p:target.slice(),v:[0,0,0]});}
  for(let k=0;k<nz;k++)for(let j=0;j<ny;j++)for(let i=0;i<nx;i++)for(const [di,dj,dk]of [[1,0,0],[0,1,0],[0,0,1],[1,1,0],[1,0,1],[0,1,1],[-1,1,0],[0,-1,1],[-1,0,1]]){if(i+di<0||i+di>=nx||j+dj<0||j+dj>=ny||k+dk>=nz)continue;const a=idx(i,j,k),b=idx(i+di,j+dj,k+dk);beams.push({a,b,length:Math.hypot(...nodes[a].target.map((v,q)=>v-nodes[b].target[q]))});}
  return {nodes,beams,r,damage:d,age:3,nx,ny,nz,revision:0};
 }
 function setCrush(c,d,impulse=0){c.damage=clean(d);for(const n of c.nodes){const t=deformPoint(...n.base,c.r,c.damage);for(let i=0;i<3;i++){n.v[i]=clamp((t[i]-n.p[i])*Math.min(8,2+impulse*.25),-3,3);n.target[i]=t[i];}}for(const b of c.beams)b.length=Math.hypot(...c.nodes[b.a].target.map((v,i)=>v-c.nodes[b.b].target[i]));c.age=0;c.revision++;}
 function cageStep(c,dt){if(!Number.isFinite(dt)||dt<=0||c.age>=3)return;let left=Math.min(dt,.08);while(left>1e-6){const h=Math.min(left,1/120);left-=h;c.age+=h;
  // Damp toward the plastic shape, then solve the structural links. This is
  // a visual spring cage anchored to a rigid chassis, not independent chassis physics.
  for(const n of c.nodes)for(let q=0;q<3;q++){n.v[q]+=((n.target[q]-n.p[q])*95-n.v[q]*14)*h;n.p[q]+=n.v[q]*h;}
  for(let it=0;it<2;it++)for(const b of c.beams){const a=c.nodes[b.a],n=c.nodes[b.b],v=n.p.map((x,i)=>x-a.p[i]),len=Math.hypot(...v)||1;const scale=clamp((len-b.length)/len,-.3,.3)*.12;for(let q=0;q<3;q++){const d=v[q]*scale;a.p[q]+=d;n.p[q]-=d;}}
  for(const n of c.nodes)for(let q=0;q<3;q++)n.p[q]=clamp(n.p[q],n.target[q]-.14,n.target[q]+.14);
 }}
 function weights(c,x,y,z){const r=c.r,coords=[(x+r.halfWidth)/(2*r.halfWidth)*(c.nx-1),(y-.34)/(bodyHeight(r)-.34)*(c.ny-1),(z+r.halfLength)/(2*r.halfLength)*(c.nz-1)],sz=[c.nx,c.ny,c.nz],cell=coords.map((v,i)=>Math.min(sz[i]-2,Math.floor(clamp(v,0,sz[i]-1)))),f=coords.map((v,i)=>clamp(v-cell[i],0,1)),out=[];for(let k=0;k<2;k++)for(let j=0;j<2;j++)for(let i=0;i<2;i++){const id=((cell[2]+k)*c.ny+cell[1]+j)*c.nx+cell[0]+i;out.push([id,(i?f[0]:1-f[0])*(j?f[1]:1-f[1])*(k?f[2]:1-f[2])]);}return out;}
 function skin(c,base,bindings,out){for(let i=0;i<base.length;i+=9){const b=bindings[i/9];for(let q=0;q<3;q++){let delta=0;for(const [id,w]of b)delta+=(c.nodes[id].p[q]-c.nodes[id].base[q])*w;out[i+q]=base[i+q]+delta;}for(let q=3;q<9;q++)out[i+q]=base[i+q];}
  // Flat normals for the newly deformed panels; do not keep pristine normals on dents.
  for(let i=0;i<out.length;i+=27){const ax=out[i+9]-out[i],ay=out[i+10]-out[i+1],az=out[i+11]-out[i+2],bx=out[i+18]-out[i],by=out[i+19]-out[i+1],bz=out[i+20]-out[i+2];let nx=ay*bz-az*by,ny=az*bx-ax*bz,nz=ax*by-ay*bx;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;for(let q=0;q<3;q++){out[i+q*9+3]=nx;out[i+q*9+4]=ny;out[i+q*9+5]=nz;}}
  return out;
 }
 root.MZVehicle={clean,condition,crush,damaged,surface,spring,updateSuspension,bodyHeight,createCage,setCrush,cageStep,weights,skin,REPAIR_PRICE:180};
})(typeof window==='undefined'?globalThis:window);
