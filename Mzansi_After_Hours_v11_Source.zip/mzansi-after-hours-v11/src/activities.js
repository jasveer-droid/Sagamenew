'use strict';
/** Shared, deterministic outdoor activity rules. Used by solo and room servers.
 * No real-world cultivation, accounts, rewards or financial transactions. */
(function(root){
 const POSTS=[{id:'postGarden',name:'Riverside gardens',x:-25,z:94},{id:'postMural',name:'Together in Colour mural',x:-111,z:172},{id:'postHarbour',name:'Harbour sunset',x:107,z:177}];
 const LITTER=[[-67,88],[-87,129],[-46,150],[30,124],[64,175],[111,160]].map(([x,z],i)=>({id:'recycle'+i,name:'Recyclable bottle '+(i+1),x,z}));
 const ROUTE=[{id:'parcel0',name:'Mural studio delivery',x:-98,z:174},{id:'parcel1',name:'Community garden delivery',x:-20,z:130},{id:'parcel2',name:'Harbour yard delivery',x:110,z:145}];
 const HUBS=[{id:'commons',name:'Riverside Commons',x:-8,z:106},{id:'harbour',name:'Harbour Works',x:44,z:118},{id:'court',name:'Ubuntu basketball court',x:-106,z:109},{id:'depot',name:'Neighbourhood parcel depot',x:47,z:103},{id:'recycling',name:'Riverside recycling kiosk',x:-109,z:146},{id:'parkRest',name:'Garden rest stop',x:-40,z:139}];
 const points=[...HUBS,...POSTS,...LITTER,...ROUTE];
 function initial(){return {postcards:[],postReward:false,litter:[],recycleNext:0,recycleRuns:0,courierStep:-1,courierNext:0,courierRuns:0,hoops:0,shots:0,restNext:0};}
 function clean(raw){const s=initial(),n=(v,max=1e9)=>Number.isFinite(v)?Math.max(0,Math.min(max,Math.floor(v))):0;
  if(!raw||typeof raw!=='object')return s;
  s.postcards=POSTS.filter(p=>Array.isArray(raw.postcards)&&raw.postcards.includes(p.id)).map(p=>p.id);s.postReward=raw.postReward===true&&s.postcards.length===POSTS.length;
  s.litter=LITTER.filter(p=>Array.isArray(raw.litter)&&raw.litter.includes(p.id)).map(p=>p.id);
  for(const k of ['recycleRuns','courierRuns','shots','hoops'])s[k]=n(raw[k]);for(const k of ['recycleNext','courierNext','restNext'])s[k]=Number.isFinite(raw[k])?Math.max(0,Math.min(1e9,raw[k])):0;s.hoops=Math.min(s.hoops,s.shots);
  s.courierStep=Number.isInteger(raw.courierStep)&&raw.courierStep>=0&&raw.courierStep<ROUTE.length?raw.courierStep:-1;return s;
 }
 function ready(s){s.outdoors??=initial();return s.outdoors;}
 function near(p,id){const q=points.find(p=>p.id===id);return !!q&&p&&Number.isFinite(p.x)&&Number.isFinite(p.z)&&Math.hypot(p.x-q.x,p.z-q.z)<4.5;}
 function tick(s){const a=ready(s);if(a.recycleNext&&s.sim>=a.recycleNext){a.recycleNext=0;a.litter=[];}}
 function perform(s,player,kind,id){const a=ready(s);tick(s);const fail=text=>({ok:false,text});const ok=(text,reward=0)=>{if(reward)s.cash=Math.min(1e9,s.cash+reward);root.MZLife?.log(s,'exploring',text,reward);return {ok:true,text,reward};};
  if(kind==='postcard'){
   if(!POSTS.some(p=>p.id===id)||!near(player,id))return fail('Go to the marked viewpoint first.');if(a.postcards.includes(id))return fail('You already collected this postcard.');
   a.postcards.push(id);let reward=0;if(a.postcards.length===POSTS.length&&!a.postReward){a.postReward=true;reward=180;}return ok(reward?'Postcard trail complete. R180 community bonus.':'Postcard collected / '+a.postcards.length+' of 3.',reward);
  }
  if(kind==='pickup'){
   if(!LITTER.some(p=>p.id===id)||!near(player,id))return fail('Move closer to the bottle.');if(a.recycleNext>s.sim)return fail('The neighbourhood is clean. More bottles appear later.');if(a.litter.includes(id))return fail('This bottle has already been collected.');a.litter.push(id);return ok('Bottle collected / '+a.litter.length+' of 6.');
  }
  if(kind==='recycle'){
   if(!near(player,'recycling'))return fail('Visit the recycling kiosk.');if(a.recycleNext>s.sim||a.litter.length!==6)return fail('Bring all six bottles to the kiosk.');a.recycleNext=s.sim+180;a.recycleRuns++;return ok('Six bottles recycled. R150 community payment.',150);
  }
  if(kind==='courierStart'){
   if(!near(player,'depot'))return fail('Visit the parcel depot.');if(a.courierStep>=0)return fail('Finish your current parcel route first.');if(a.courierNext>s.sim)return fail('The next delivery route is not ready yet.');a.courierStep=0;return ok('Three parcels loaded. Follow the route in Activities.');
  }
  if(kind==='parcel'){
   if(a.courierStep<0||ROUTE[a.courierStep]?.id!==id)return fail('Deliver to the highlighted stop first.');if(!near(player,id))return fail('Move closer to the delivery counter.');a.courierStep++;
   if(a.courierStep===ROUTE.length){a.courierStep=-1;a.courierNext=s.sim+120;a.courierRuns++;return ok('All parcels delivered. R240 route payment.',240);}return ok('Parcel delivered. Next: '+ROUTE[a.courierStep].name+'.');
  }
  if(kind==='rest'){
   if(!near(player,'parkRest'))return fail('Visit the garden rest stop.');if(a.restNext>s.sim)return fail('You have just rested. Enjoy the park for a while.');a.restNext=s.sim+90;return {...ok('A peaceful break. +15 health.'),heal:15};
  }
  return fail('That activity is not available.');
 }
 function shot(t){const aim=(Math.sin(t*2.4)+1)/2;return {aim,hit:Math.abs(aim-.5)<=.14};}
 root.MZActivities={POSTS,LITTER,ROUTE,HUBS,points,initial,clean,ready,tick,near,perform,shot};
})(typeof window==='undefined'?globalThis:window);
