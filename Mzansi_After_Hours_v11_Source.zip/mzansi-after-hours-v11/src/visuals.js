'use strict';
/** Visual edition. Original procedural artwork: no remote assets or libraries.
 * Static sun shadows are baked once; performance mode uses the same world without
 * PCF sampling. Every GPU resource is recreated after context restoration.
 */
(function(root){
 const {Geometry:G, M,V,Renderer,compile,color}=MZ;
 M.ortho=(l,r,b,t,n,f)=>new Float32Array([2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1]);
 M.multiply=(a,b)=>{const out=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)out[c*4+r]+=a[k*4+r]*b[c*4+k];return out;};
 // Cylinder between arbitrary points, used for tree branches, railings and pipes.
 G.prototype.beam=function(a,b,r,col,n=7){let dir=V.norm(V.sub(b,a)),u=V.norm(V.cross(dir,Math.abs(dir[1])>.9?[1,0,0]:[0,1,0])),v=V.cross(dir,u);const p=(a,t)=>a.map((x,i)=>x+r*(u[i]*Math.cos(t)+v[i]*Math.sin(t)));for(let i=0;i<n;i++){let t=i*2*Math.PI/n,t1=(i+1)*2*Math.PI/n;this.quad(p(a,t),p(b,t),p(b,t1),p(a,t1),col);}return this;};
 // Smooth ellipsoid with per-vertex normals for faces and rounded clothing.
 G.prototype.ellipsoid=function(x,y,z,rx,ry,rz,col,lat=9,lon=14){const rgb=color(col),p=(a,b)=>[Math.sin(a)*Math.cos(b),Math.cos(a),Math.sin(a)*Math.sin(b)];const push=q=>{let norm=V.norm([q[0]/rx,q[1]/ry,q[2]/rz]);this.v.push(x+q[0]*rx,y+q[1]*ry,z+q[2]*rz,...norm,...rgb);};for(let i=0;i<lat;i++)for(let j=0;j<lon;j++){let a=p(i*Math.PI/lat,j*2*Math.PI/lon),b=p((i+1)*Math.PI/lat,j*2*Math.PI/lon),c=p((i+1)*Math.PI/lat,(j+1)*2*Math.PI/lon),d=p(i*Math.PI/lat,(j+1)*2*Math.PI/lon);[a,b,c,a,c,d].forEach(push);}return this;};
 const VS=`attribute vec3 aPos,aNorm,aCol;
 uniform mat4 uP,uV,uM,uLight; uniform vec3 uSun;
 varying vec3 vCol,vNormal,vWorld; varying vec4 vShadow; varying float vDist;
 void main(){vec4 world=uM*vec4(aPos,1.);vec4 view=uV*world;gl_Position=uP*view;
 vCol=aCol;vNormal=normalize(mat3(uM)*aNorm);vWorld=world.xyz;vShadow=uLight*world;vDist=length(view.xyz);}`;
 const FS=`precision highp float;
 varying vec3 vCol,vNormal,vWorld; varying vec4 vShadow; varying float vDist;
 uniform vec3 uSun,uFog,uEye;uniform vec4 uCar;uniform float uFinish,uWet;uniform float uBright,uAmbient,uShadowOn,uNight,uDetail;uniform sampler2D uShadow;
 float readDepth(vec2 uv){return dot(texture2D(uShadow,uv),vec4(1.,1./255.,1./65025.,1./16581375.));}
 float testDepth(vec2 uv,float z){return z-.0028>readDepth(uv)?0.:1.;}
 void main(){vec3 n=normalize(vNormal);float sun=max(dot(n,uSun),0.);float shadow=1.;
 if(uShadowOn>.5){vec3 sc=vShadow.xyz/vShadow.w*.5+.5;
 if(sc.x>0.&&sc.x<1.&&sc.y>0.&&sc.y<1.&&sc.z<1.){float d=.0014;shadow=(testDepth(sc.xy,sc.z)*2.+testDepth(sc.xy+vec2(d,d),sc.z)+testDepth(sc.xy+vec2(-d,d),sc.z)+testDepth(sc.xy+vec2(d,-d),sc.z)+testDepth(sc.xy-vec2(d,d),sc.z))/6.;}}
 vec3 hemi=mix(vec3(.49,.47,.47),vec3(.76,.87,.91),n.y*.5+.5);
 vec3 lighting=hemi*.77+vec3(1.,.87,.67)*sun*(.37+.08*uDetail)*mix(.25,1.,shadow);
 if(uFinish<-.5){gl_FragColor=vec4(vec3(.035,.05,.065),vCol.r*.42);return;}
 float grain=fract(sin(dot(floor(vWorld.xz*23.+vWorld.y*17.),vec2(12.9898,78.233)))*437.5453);
 float wall=(1.-abs(n.y))*.022*(step(.94,fract(vWorld.y*2.6))+step(.97,fract((vWorld.x+vWorld.z)*1.3+floor(vWorld.y*2.6)*.5)));
 float contact=mix(.86,1.,smoothstep(.14,1.35,vWorld.y));
 vec3 c=vCol*lighting*(.979+grain*.04-wall)*uBright*contact;
 if(uFinish>.5){vec3 eye=normalize(uEye-vWorld),halfDir=normalize(eye+uSun);float fres=pow(1.-max(dot(n,eye),0.),4.);
  float spec=pow(max(dot(n,halfDir),0.),uFinish>1.8?110.:64.);vec3 env=mix(vec3(.16,.22,.25),vec3(.44,.66,.83),clamp(n.y*.5+.5,0.,1.));
  c=vCol*lighting*uBright*.95+env*(.09+fres*.38)+vec3(1.,.94,.80)*spec*(.55+.30*uDetail)*uNight;
  if(uFinish>1.8&&uFinish<2.5)c=mix(vCol*.45,env,.43+fres*.50)+spec*.75*uNight;
  if(uFinish>2.5)c=vCol*(1.02+(1.-uNight)*.38);
 }
 if(uWet>.5&&n.y>.95&&vWorld.y<.16){float sheen=pow(max(dot(reflect(-normalize(uEye-vWorld),n),uSun),0.),34.);c=c*.86+vec3(.4,.53,.64)*sheen*.38;}

 float night=1.-uNight;float glow=0.;
 glow+=max(0.,1.-length(vWorld-vec3(-38.5,2.,21.8))/7.);
 glow+=max(0.,1.-length(vWorld-vec3(-30.,3.,-8.))/8.);
 glow+=max(0.,1.-length(vWorld-vec3(40.,3.,25.))/10.);
 glow+=max(0.,1.-length(vWorld-vec3(39.,3.,-8.))/9.);
 c+=vCol*vec3(1.,.6,.25)*glow*night*.5;
 if(uCar.w>.5&&vWorld.y<2.){vec2 delta=vWorld.xz-uCar.xy,fw=vec2(sin(uCar.z),-cos(uCar.z));float ahead=dot(delta,fw),side=abs(delta.x*fw.y-delta.y*fw.x);float beam=smoothstep(1.,2.5,ahead)*(1.-smoothstep(14.,28.,ahead))*(1.-smoothstep(1.4+ahead*.10,2.+ahead*.23,side));c+=vec3(.72,.70,.54)*beam*(1.-uNight)*.75;}
 c=mix(c,uFog,smoothstep(65.,185.,vDist)*.96);gl_FragColor=vec4(c,1.);}`;
 const skyVS=`attribute vec2 aPos;varying vec2 uv;void main(){uv=aPos;gl_Position=vec4(aPos,.9999,1.);}`;
 const skyFS=`precision highp float;varying vec2 uv;uniform vec3 forward,right,up;uniform float aspect,day,time;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
 void main(){vec3 ray=normalize(forward+right*uv.x*aspect*.7002+up*uv.y*.7002);
 float h=max(ray.y,0.);vec3 horizon=mix(vec3(.16,.23,.32),vec3(.95,.70,.48),day);
 vec3 top=mix(vec3(.035,.075,.15),vec3(.25,.53,.69),day);vec3 c=mix(horizon,top,pow(clamp(h*1.9,0.,1.),.58));
 vec3 sd=normalize(vec3(-.60,.86,.39));float sdv=dot(ray,sd);
 c+=vec3(1.,.72,.35)*pow(max(sdv,0.),80.)*.25*day;
 float disc=smoothstep(.999,.9996,sdv);c=mix(c,vec3(1.,.92,.7),disc*day);
 if(ray.y>.025){vec2 p=ray.xz/(ray.y+.26)*2.0+vec2(time*.008,0.);float cloud=noise(p)*.6+noise(p*2.1)*.26+noise(p*4.2)*.14;
 float a=smoothstep(.52,.79,cloud)*smoothstep(.025,.22,ray.y);c=mix(c,mix(vec3(.25,.3,.38),vec3(1.,.90,.80),day),a*.72);
 vec2 starCell=floor(ray.xz/(ray.y+.15)*190.);float star=step(.998,hash(starCell));c+=star*(1.-day)*.38;}
 gl_FragColor=vec4(c,1.);}`;
 function setupRenderer(r){
  const gl=r.gl;const highp=gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER,gl.HIGH_FLOAT).precision>0;const safe=s=>highp?s:s.replace(/precision highp float;/g,'precision mediump float;');r.hasHighp=highp;gl.deleteProgram(r.cp);r.cp=compile(gl,VS,safe(FS));
  r.c=r.locations(r.cp,['aPos','aNorm','aCol'],['uP','uV','uM','uSun','uAmbient','uFog','uBright','uLight','uShadow','uShadowOn','uNight','uDetail','uEye','uFinish','uWet','uCar']);
  r.lightMatrix=M.multiply(M.ortho(-155,155,-135,135,1,460),M.lookAt([-145,200,76],[0,0,-25]));
  r.skyProgram=compile(gl,skyVS,safe(skyFS));r.sky=r.locations(r.skyProgram,['aPos'],['forward','right','up','aspect','day','time']);
  r.skyBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,r.skyBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,1,1,-1,-1,1,1,-1,1]),gl.STATIC_DRAW);
  r.visualQuality=1;r.visualTime=0;r.shadowReady=false;
  // White fallback satisfies sampler completeness even without an allocated map.
  r.shadowTexture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,r.shadowTexture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
  r.drawSky=function(cam){let s=this.sky,g=this.gl;g.disable(g.DEPTH_TEST);g.depthMask(false);for(let i=0;i<3;i++)g.disableVertexAttribArray(i);g.useProgram(this.skyProgram);g.bindBuffer(g.ARRAY_BUFFER,this.skyBuffer);g.enableVertexAttribArray(s.aPos);g.vertexAttribPointer(s.aPos,2,g.FLOAT,false,0,0);let f=[Math.sin(cam.yaw)*Math.cos(cam.pitch),Math.sin(cam.pitch),-Math.cos(cam.yaw)*Math.cos(cam.pitch)],right=[Math.cos(cam.yaw),0,Math.sin(cam.yaw)],up=V.cross(right,f);g.uniform3fv(s.forward,f);g.uniform3fv(s.right,right);g.uniform3fv(s.up,up);g.uniform1f(s.aspect,this.canvas.width/this.canvas.height);g.uniform1f(s.day,this.daylight);g.uniform1f(s.time,this.visualTime);g.drawArrays(g.TRIANGLES,0,6);g.enable(g.DEPTH_TEST);g.depthMask(true);};
  r.bindVisuals=function(){let g=this.gl,c=this.c;g.uniformMatrix4fv(c.uLight,false,this.lightMatrix);g.activeTexture(g.TEXTURE1);g.bindTexture(g.TEXTURE_2D,this.shadowTexture);g.uniform1i(c.uShadow,1);g.uniform1f(c.uShadowOn,this.shadowReady&&this.visualQuality>0?1:0);g.uniform1f(c.uNight,this.daylight);g.uniform1f(c.uDetail,this.visualQuality);g.uniform3fv(c.uEye,[this.cameraPosition?.x||0,this.cameraPosition?.y||2,this.cameraPosition?.z||5]);g.uniform1f(c.uWet,this.roadWet?1:0);g.uniform4fv(c.uCar,this.carLight||[0,0,0,0]);g.activeTexture(g.TEXTURE0);};
  r.bakeShadows=function(meshes){if(this.shadowReady||!this.hasHighp)return;let size=1024;const g=this.gl;const fbo=g.createFramebuffer(),depth=g.createRenderbuffer();g.bindTexture(g.TEXTURE_2D,this.shadowTexture);g.texImage2D(g.TEXTURE_2D,0,g.RGBA,size,size,0,g.RGBA,g.UNSIGNED_BYTE,null);g.texParameteri(g.TEXTURE_2D,g.TEXTURE_WRAP_S,g.CLAMP_TO_EDGE);g.texParameteri(g.TEXTURE_2D,g.TEXTURE_WRAP_T,g.CLAMP_TO_EDGE);g.bindFramebuffer(g.FRAMEBUFFER,fbo);g.framebufferTexture2D(g.FRAMEBUFFER,g.COLOR_ATTACHMENT0,g.TEXTURE_2D,this.shadowTexture,0);g.bindRenderbuffer(g.RENDERBUFFER,depth);g.renderbufferStorage(g.RENDERBUFFER,g.DEPTH_COMPONENT16,size,size);g.framebufferRenderbuffer(g.FRAMEBUFFER,g.DEPTH_ATTACHMENT,g.RENDERBUFFER,depth);
   if(g.checkFramebufferStatus(g.FRAMEBUFFER)!==g.FRAMEBUFFER_COMPLETE){g.bindFramebuffer(g.FRAMEBUFFER,null);g.deleteFramebuffer(fbo);g.deleteRenderbuffer(depth);return;}
   let program=compile(g,`attribute vec3 aPos;uniform mat4 light;void main(){gl_Position=light*vec4(aPos,1.);}`,`precision highp float;void main(){vec4 d=fract(gl_FragCoord.z*vec4(1.,255.,65025.,16581375.));d-=d.yzww*vec4(1./255.,1./255.,1./255.,0.);gl_FragColor=d;}`);let loc=g.getAttribLocation(program,'aPos');for(let i=0;i<3;i++)g.disableVertexAttribArray(i);g.useProgram(program);g.uniformMatrix4fv(g.getUniformLocation(program,'light'),false,this.lightMatrix);g.viewport(0,0,size,size);g.clearColor(1,1,1,1);g.clear(g.COLOR_BUFFER_BIT|g.DEPTH_BUFFER_BIT);g.disable(g.BLEND);g.enableVertexAttribArray(loc);for(let mesh of meshes){g.bindBuffer(g.ARRAY_BUFFER,mesh.buffer);g.vertexAttribPointer(loc,3,g.FLOAT,false,36,0);g.drawArrays(g.TRIANGLES,0,mesh.count);}g.enable(g.BLEND);g.bindFramebuffer(g.FRAMEBUFFER,null);g.clearColor(0,0,0,0);g.deleteProgram(program);g.deleteFramebuffer(fbo);g.deleteRenderbuffer(depth);this.shadowReady=true;this.resize();};
 }
 const portraits=new Map(), icons=new Map();
 // Render portraits from the actual character meshes, not unrelated stock images.
 function portrait(r,model,name){
  if(portraits.has(name))return portraits.get(name);
  let g=r.gl,c=r.c;r.canvas.width=300;r.canvas.height=300;g.viewport(0,0,300,300);g.clearColor(0,0,0,0);g.clear(g.COLOR_BUFFER_BIT|g.DEPTH_BUFFER_BIT);g.useProgram(r.cp);
  g.uniformMatrix4fv(c.uP,false,M.perspective(.60,1,.1,20));g.uniformMatrix4fv(c.uV,false,M.lookAt([.16,1.69,1.98],[0,1.54,0]));g.uniform3fv(c.uSun,V.norm([-.5,.8,1.]));g.uniform3fv(c.uFog,[.1,.2,.22]);g.uniform1f(c.uBright,1.2);g.uniform1f(c.uAmbient,.7);r.bindVisuals();g.uniform1f(c.uShadowOn,0);r.draw(model.body,M.model(0,0,0,-.08));
  let out=r.canvas.toDataURL('image/png');portraits.set(name,out);return out;
 }
 function icon(id){if(icons.has(id))return icons.get(id);const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');let colours={glow:'#92d9a7',mist:'#98cbe7',sunburst:'#edb957',prism:'#c8a5eb',leaf:'#93c48b',seed:'#bc8d63',pouch:'#d9cfae',dew:'#93cce0',sun:'#e3b95d',lamp:'#f3df96',mixer:'#adcabe',bag:'#d9ad76',solar:'#80afcc'};let col=colours[id]||'#a6c9bc';x.shadowColor='#0008';x.shadowBlur=12;x.shadowOffsetY=6;
  const round=(a,b,w,h,r,fill)=>{x.fillStyle=fill;x.beginPath();x.roundRect(a,b,w,h,r);x.fill();};
  if(['leaf','seed'].includes(id)){x.save();x.translate(64,64);x.rotate(-.5);x.fillStyle=col;x.beginPath();x.ellipse(0,0,22,40,0,0,Math.PI*2);x.fill();x.shadowBlur=0;x.strokeStyle='#ebf6c4';x.lineWidth=3;x.beginPath();x.moveTo(0,34);x.lineTo(0,-30);x.stroke();for(let j=-18;j<20;j+=12){x.beginPath();x.moveTo(0,j);x.lineTo(16,j-12);x.stroke();}x.restore();}
  else if(['dew','sun','prism'].includes(id)){round(40,35,48,68,12,col);round(48,18,32,23,4,'#d9cbb5');x.shadowBlur=0;round(47,62,34,22,2,'#faf2d1');x.fillStyle='#315b59';x.font='bold 15px Arial';x.textAlign='center';x.fillText(id==='dew'?'M':id==='sun'?'S':'P',64,79);}
  else if(['lamp','mixer','bag','solar'].includes(id)){round(26,30,76,78,12,col);x.shadowBlur=0;round(34,40,60,43,6,'#244745');x.strokeStyle='#e8d8ac';x.lineWidth=4;x.beginPath();x.arc(64,59,12,0,Math.PI*2);x.stroke();round(48,16,32,20,5,'#b5bcaa');round(40,93,48,4,2,'#f6e6c5');}
  else {round(31,23,66,85,8,col);x.shadowBlur=0;round(29,20,70,9,2,'#eee0b8');round(32,94,64,6,2,'#577b7066');round(38,45,52,34,4,'#f4ecd4');x.fillStyle='#264b47';x.font='900 21px Arial';x.textAlign='center';x.fillText(({glow:'OG',mist:'MM',sunburst:'SB',prism:'NP',pouch:'+'})[id]||'NP',64,69);x.fillStyle='#ffffff88';x.fillRect(37,31,5,10);}
  let out=c.toDataURL('image/png');icons.set(id,out);return out;
 }
 // Main visual decoration batch. Kept clear of doors and existing interaction nodes.
 function decorate(w,r){
  const replaced=new Set(['BAY HARDWARE','TOOLS / LIGHTS / SOLAR']);
  for(const old of w.signs.filter(s=>replaced.has(s.text))){r.gl.deleteTexture(old.quad.texture);r.gl.deleteBuffer(old.quad.buffer);}
  w.signs=w.signs.filter(s=>!replaced.has(s.text));
  const s=new G();let seed=937;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};const box=(...v)=>s.box(...v), sign=(text,sub,x,y,z,width,height,bg='#224d52',rot=0)=>w.signs.push({x,y,z,ry:rot,lit:true,quad:r.makeSign(text,sub,width,height,bg,'#f5dfb4')});
  function pot(x,z,sz=1){s.cylinder(x,.40*sz,z,.4*sz,.31*sz,.8*sz,0xb66d49,12);s.cylinder(x,.8*sz,z,.43*sz,.43*sz,.12*sz,0xd09c70,12);for(let j=0;j<7;j++){let a=j*2.4;let end=[x+Math.cos(a)*.62*sz,(1.2+rnd()*.6)*sz,z+Math.sin(a)*.62*sz];s.beam([x,.8*sz,z],end,.045*sz,0x567947);s.ellipsoid(...end,.16*sz,.36*sz,.12*sz,0x789958,5,8);}}
  function rail(x,z,length){box(x,.7,z,length,.09,.08,0x465f5e);for(let xx=x-length/2;xx<=x+length/2+.1;xx+=1.2)box(xx,.55,z,.08,1.1,.08,0x4c6665);}
  function parasol(x,z,col){s.cylinder(x,1.8,z,.035,.055,3.5,0x776b58,7);s.cylinder(x,3.25,z,0,2.15,.8,col,10);s.cylinder(x,2.85,z,2.15,2.18,.13,col,10);}
  // Store-front architecture, roof edge bands, window trims and roof equipment.
  for(const b of w.buildings){if(['YOUR YARD','WORKSHOP 02'].includes(b.name))continue;let front=b.z+b.d/2+.12,h=b.name==='BAY HARDWARE'?6:b.name==='SUNSET SPAZA'?5.2:4.7;
   box(b.x,h+.30,b.z,b.w+.5,.2,b.d+.5,0xd8c6a2);box(b.x,.53,front,b.w,.13,.09,0xe4d4b4);
   for(let xx of [b.x-b.w/2+.5,b.x+b.w/2-.5]){box(xx,2.2,front,.48,4.3,.33,0xe0caac);for(let yy=.65;yy<4;yy+=.65)box(xx,yy,front+.18,.5,.09,.02,0xbca589);}
   for(let xx of [b.x-b.w*.3,b.x+b.w*.3]){box(xx,2.62,front+.03,2.3,.12,.3,0xe8d4b2);box(xx,.91,front+.03,2.3,.13,.45,0xe8d4b2);for(let a of [-1.12,1.12])box(xx+a,1.75,front+.03,.09,1.75,.27,0xf1dcbc);}
   box(b.x+b.w*.3,h+.74,b.z,2.2,1.3,1.6,0x879596);for(let j=0;j<7;j++)box(b.x+b.w*.3,h+.5+j*.13,b.z+.81,1.9,.04,.035,0x435e60);
  }
  // Spaza striped canvas awning and baskets of produce.
  for(let i=0;i<18;i++){let x=-37.2+i*.85;box(x,3.54,-8.1,.85,.14,2.6,i%2?0xdd9b5c:0xf3d5a0);box(x,3.32,-6.82,.85,.35,.08,i%2?0xcf8953:0xe6c58e);}
  for(let k=0;k<3;k++){let x=-34.5+k*2.2;box(x,1.31,-8.25,1.5,.12,.8,0x9a7953);for(let i=0;i<10;i++)s.ellipsoid(x-.6+(i%5)*.3,1.46+Math.floor(i/5)*.04,-8.55+Math.floor(i/5)*.35,.14,.16,.14,[0xefb849,0x90ab56,0xbe775d][k],4,6);}
  sign('GROWN HERE. SHARED HERE.','YOUR NEIGHBOURHOOD SPAZA',-30,4.5,-9.80,11,.8,'#355e56');
  // Street canopy and inset shop shelves.
  for(let i=0;i<7;i++){let xx=-36+i*2.0;box(xx,1.2,-9.01,1.7,2.0,.09,0x375c5b);for(let y of [.55,1.25,1.92]){box(xx,y,-8.88,1.72,.05,.17,0xa89873);for(let j=0;j<6;j++)box(xx-.68+j*.26,y+.16,-8.91,.16,.28,.15,[0xb9c581,0xca956d,0xd2ba73][(i+j)%3]);}}
  pot(-41,-9,1);pot(-19,-9,1);
  // Braai courtyard, seating, table setting and string lights.
  parasol(32,-9,0xd6a65e);parasol(44,-9,0xc07756);
  for(let xx of [31,38,45]){for(let zz of [-9.4,-7.5]){box(xx,.5,zz,2.4,.14,.45,0xcda574);box(xx-1,.27,zz,.09,.5,.35,0x4a6562);box(xx+1,.27,zz,.09,.5,.35,0x4a6562);}for(let j=0;j<2;j++){s.cylinder(xx-.6+j*1.2,1.01,-8.4,.28,.28,.04,0xeadfc1,12);s.cylinder(xx-.28+j*.8,1.19,-8.1,.08,.08,.3,0xd8c789,8);}}
  for(let x=28;x<=50;x+=2){let y=3.25-.25*Math.sin((x-28)/22*Math.PI);s.beam([x,y,-6.9],[x+2,y+.04,-6.9],.013,0x394f4c,5);s.ellipsoid(x,y-.16,-6.9,.08,.12,.08,0xffd18b,4,7);}
  rail(37,-11.1,20);sign('FIRE. FLAVOUR. FRIENDS.','BRAAI & CHILL / EST. 1998',39,3.32,-10.75,10,1.12,'#8a493d');
  // The Yard: furnishings, floor tiles, work surfaces, shelves, photos and plants.
  for(let x=-42;x<-21;x+=2)for(let z=14;z<31;z+=2)box(x,.299,z,1.97,.008,1.97,(Math.round(x+z)%4===0)?0xa7977c:0xae9b7d);
  box(-41.5,2.3,25.2,.35,1.7,3.6,0x967859);for(let yy of [1.56,2.05,2.52,3.02])box(-41.25,yy,25.2,.65,.09,3.5,0xb29970);
  for(let i=0;i<12;i++){let z=23.8+i%4*.85,y=1.76+Math.floor(i/4)*.49;s.cylinder(-41.2,y,z,.17,.17,.30,[0x9bb8a0,0xd5ba83,0x91b5bc][i%3],9);s.cylinder(-41.2,y+.17,z,.18,.18,.05,0xe8d9b5,9);}
  box(-35.0,.48,30.6,3.2,.8,.8,0x756151);box(-35,.91,30.6,3.3,.08,.84,0xc9a87c);pot(-22.4,29.8,1.2);
  box(-30,2.0,31.29,2.1,1.4,.07,0x6a5649);box(-30,2.0,31.24,1.88,1.18,.05,0xb9c0a7);sign('ONE SMALL START','SUNDOWN BAY / HOME',-30,2.0,31.20,1.8,1.06,'#65877e',Math.PI);
  box(-38.5,1.08,21.8,5,.10,1.7,0xd4c8a0);for(let x of [-40.7,-36.4]){s.cylinder(x,1.44,21.7,.22,.24,.6,0x7d9c8a,10);s.cylinder(x,1.75,21.7,.25,.25,.05,0xd7dec0,10);}
  box(-39.8,1.38,21.9,.6,.48,.32,0x324e52);box(-39.8,1.46,21.725,.48,.22,.01,0x98d8ba);for(let j=0;j<3;j++)s.ellipsoid(-40+j*.2,1.29,21.73,.045,.045,.023,0xe5bf73,4,6);
  s.beam([-37,1.1,22.3],[-37,2.9,22.3],.045,0x415b55);s.beam([-37,2.9,22.3],[-38.0,2.9,22.3],.05,0x415b55);s.cylinder(-38,2.83,22.3,.18,.48,.32,0x4b7466,12);s.cylinder(-38,2.65,22.3,.38,.38,.03,0xffdda0,12);
  // Roof solar plates remain visible from the street.
  for(let i=0;i<3;i++){box(-38+i*2,4.53,18.5,1.8,.16,3.8,0x304d60);for(let k=0;k<5;k++)box(-38+i*2,4.63,17+k*.7,1.72,.02,.025,0x85aab7);}
  // A workshop with real shelving, pipework and dispatch parcels.
  for(let x of [42,46,50]){for(let y of [1.0,2.1,3.2]){box(x,y,35.5,3.3,.14,1.4,0x9d937d);for(let k=0;k<3;k++)box(x-1+k,y+.37,35.5,.7,.65,.83,0xb99c71);}for(let side of [-1.55,1.55])box(x+side,1.7,35.5,.12,3.4,1.4,0x4e6a67);}
  for(let x=31;x<50;x+=5){s.beam([x,4.8,16],[x,4.8,36],.07,0x466761);box(x,4.83,26,1.3,.08,.34,0xf2df9f);}
  box(34,1.21,32.5,1.0,.05,.5,0x374f52);box(34,1.6,33,.86,.64,.06,0x243e47);box(34,1.61,32.963,.69,.45,.015,0x93c2b1);for(let k=0;k<4;k++)box(32.8+k*.4,1.4,33,.33,.5,.29,0xcbb079);
  // Taxi shelter, destination boards, tyres and detailed parked minibus lane.
  box(31,3.5,-31.9,7,.18,4,0x5f8177);for(let xx of [28,34])for(let zz of [-33.7,-30.2])box(xx,1.8,zz,.12,3.6,.12,0x466b65);
  sign('SUNDOWN BAY','LOCAL TAXIS / R20',30,2.7,-33.5,3.8,.82,'#2d6767');
  // Pavers, drain grilles, benches and jacaranda petals. No new blocking colliders.
  for(let x=-57;x<57;x+=3){if(Math.abs(x-18)>8){box(x,.226,-8, .035,.012,3.7,0xa4aaa0);box(x,.226,8,.035,.012,3.7,0xa4aaa0);}}
  for(let x of [-42,-15,34,52]){for(let j=0;j<7;j++)box(x+j*.16,.271,5.8,.07,.008,.6,0x384e4e);}
  for(let t of w.trees){for(let i=0;i<24;i++){let a=rnd()*6.28,d=.7+rnd()*2.4;box(t.x+Math.cos(a)*d,.19,t.z+Math.sin(a)*d,.06+rnd()*.1,.01,.06,[0xba9abe,0xaab18c,0xd1b3bd][i%3],a);}}
  for(let [x,z] of [[-42,-28],[-17,-9],[5,-9],[28,12],[50,12]])pot(x,z,.8);
  // Hanging shop lettering and a little street art, original geometric wall motif.
  sign('BAY HARDWARE','TOOLS FOR YOUR NEXT CHAPTER',-5,5.30,-9.83,14,1.0,'#387a82');
  for(let i=0;i<12;i++){let x=-12+i*.4;box(x,2.05,-9.98,.27,.7+(i%4)*.28,.1,[0xd19b61,0x679b8d,0xdec795][i%3]);}
  // Ubuntu Wheels uses a dedicated showroom sign in ride-world.js.
  w.detail=r.mesh(s);w.visualStats={detailVertices:s.v.length/9,shadowMap:1024,portraitCount:0};
 }
 function install(r,w){setupRenderer(r);decorate(w,r);w.shadowMeshes=[w.static,w.detail];
  const ring=new G();for(let i=0;i<40;i++){const a=i*Math.PI/20,b=(i+1)*Math.PI/20;if(i%5===4)continue;ring.quad([Math.cos(a)*.70,0,Math.sin(a)*.70],[Math.cos(b)*.70,0,Math.sin(b)*.70],[Math.cos(b)*.79,0,Math.sin(b)*.79],[Math.cos(a)*.79,0,Math.sin(a)*.79],0xe8c882,[0,1,0]);}w.targetRing=r.mesh(ring);
  const rotor=new G();rotor.box(0,0,0,.75,.035,.08,0xdfd7ac);rotor.box(0,0,0,.08,.04,.75,0xdfd7ac);w.rotor=r.mesh(rotor);
  const original=w.render;w.render=function(state,time){r.visualTime=time;r.visualQuality=state.settings.quality; r.draw(w.detail);const target=w.getPoint(state.track);if(target)r.draw(w.targetRing,M.model(target.x,.34,target.z,0,1+Math.sin(time*2)*.035));r.draw(w.rotor,M.model(-38.5,2.075,21.8,state.jobs.length?time*4:0));original(state,time);};
  w.portraitFor=name=>{let n=name.replace('Auntie ','');let p=[...w.customers,...w.pedestrians].find(p=>p.name===n)||w.pedestrians.find(p=>p.name==='Zanele');return portrait(r,p.model,n);};
  // The same portraits are reused in story, phone and customer panels.
  for(let name of ['Zanele','Nandi','Aadil','Thabo','Sipho','Aisha','Lerato','Pieter','Ravi','Zoe','Musa','Thandi','Kabelo'])w.portraitFor(name);
  w.visualStats.portraitCount=portraits.size;
  r.resize();
 }
 root.MZVisuals={install,icon,portraits};
})(window);
