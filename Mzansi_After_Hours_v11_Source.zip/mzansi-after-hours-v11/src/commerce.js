'use strict';
/** Shared game-economy rules. Integer rands; no external banking or real accounts. */
(function(root){
 const D=root.MZCommerceData,MAX=1e9,cap=(n,max=MAX)=>typeof n==='number'&&Number.isFinite(n)?Math.max(0,Math.min(max,Math.floor(n))):0;
 const text=(s,max=40)=>typeof s==='string'?s.replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,max):'';
 function initial(){return {bank:{opened:false,current:0,savings:0,goal:5000,seq:0,statement:[]},firms:{},work:null,task:null,sequence:0,workDays:{},shifts:0,wages:0,services:0,guideSeen:false};}
 function ready(s){return s.enterprise??=initial();}
 function clean(raw,sim=0,day=1){const e=initial();if(!raw||typeof raw!=='object')return e;const b=raw.bank||{};for(const k of ['current','savings','goal','seq'])e.bank[k]=cap(b[k]);if(!b.goal)e.bank.goal=5000;e.bank.opened=b.opened===true||e.bank.current>0||e.bank.savings>0;
  e.bank.statement=(Array.isArray(b.statement)?b.statement:[]).filter(r=>r&&typeof r.label==='string').slice(-250).map((r,i)=>({id:cap(r.id)||i+1,day:Math.max(1,cap(r.day,100000)),time:cap(r.time,1439),label:text(r.label,120),amount:cap(r.amount),from:text(r.from),to:text(r.to),current:cap(r.current),savings:cap(r.savings),cash:cap(r.cash),kind:text(r.kind,20)}));e.bank.seq=Math.max(e.bank.seq,e.bank.statement.length,...e.bank.statement.map(r=>r.id));
  for(const d of D.businesses){const r=raw.firms?.[d.id];if(!r||typeof r!=='object')continue;const f={name:text(r.name)||d.name,level:Math.max(1,cap(r.level,3)),stock:0,till:cap(r.till),staff:0,open:r.open===true,paidDay:cap(r.paidDay,100000),paidAmount:cap(r.paidAmount,300),nextSale:Math.max(sim,Math.min(sim+200,Number(r.nextSale)||sim)),sales:cap(r.sales),revenue:cap(r.revenue),expenses:cap(r.expenses),price:['value','standard','premium'].includes(r.price)?r.price:'standard',reason:text(r.reason,80)};f.stock=cap(r.stock,capacity(f));f.staff=cap(r.staff,f.level);if(f.paidDay!==day||!f.stock)f.open=false;e.firms[d.id]=f;}
  e.sequence=cap(raw.sequence);e.shifts=cap(raw.shifts);e.wages=cap(raw.wages);e.services=cap(raw.services);e.guideSeen=raw.guideSeen===true;
  for(const d of D.businesses)if(raw.workDays?.[d.id])e.workDays[d.id]=cap(raw.workDays[d.id],day);
  const w=raw.work,d=w&&Object.hasOwn(D.byId,w.biz)?D.byId[w.biz]:null;if(d&&['shift','service'].includes(w.kind)&&Number.isInteger(w.step)&&w.step>=0&&w.step<d.tasks.length&&(w.kind==='shift'||e.firms[w.biz])){
   e.work={id:cap(w.id)||++e.sequence,biz:w.biz,kind:w.kind,step:w.step,day:Math.max(1,Math.min(day,cap(w.day))),quote:w.kind==='shift'?d.wage:cap(w.quote,d.unitPrice*2),started:Math.max(0,Math.min(sim,Number(w.started)||0))};
   const t=raw.task;if(t&&Number.isInteger(t.step)&&t.step===w.step&&t.work===w.id&&Number.isFinite(t.until))e.task={id:cap(t.id)||++e.sequence,work:e.work.id,step:w.step,start:Math.max(0,Math.min(sim,Number(t.start)||0)),until:Math.max(0,Math.min(sim+d.tasks[w.step].seconds,t.until))};
  }
  e.sequence=Math.max(e.sequence,e.work?.id||0,e.task?.id||0);return e;
 }
 function capacity(f){return 30+f.level*10;}
 function bill(d,f){return d.overhead+(f.level-1)*5+f.staff*45;}
 function due(s,d,f){return Math.max(0,bill(d,f)-(f.paidDay===s.day?f.paidAmount:0));}
 function quote(d,f){return Math.round(d.unitPrice*(1+(f.level-1)*.10)*({value:.85,standard:1,premium:1.20}[f.price]||1));}
 function interval(f){return ({value:38,standard:55,premium:85}[f.price]||55)/Math.max(1,f.staff);}
 function near(p,id){const q=D.points.find(p=>p.id===id);return !!q&&!!p&&Number.isFinite(p.x)&&Number.isFinite(p.z)&&Math.hypot(p.x-q.x,p.z-q.z)<=5.5;}
 function log(s,label,amount=0,from='Business',to='Business',kind='business'){
  const e=ready(s),b=e.bank;b.statement.push({id:++b.seq,day:s.day,time:Math.floor(s.clock||0),label,amount,from,to,current:b.current,savings:b.savings,cash:s.cash,kind});if(b.statement.length>250)b.statement.splice(0,b.statement.length-250);root.MZLife?.log(s,kind==='wages'?'jobs':kind==='bank'?'bank':'business',label,from==='Employer'?amount:0);
 }
 function need(ok,message){if(!ok)throw new Error(message);}
 function amount(n){need(Number.isSafeInteger(n)&&n>0&&n<=MAX,'Enter a whole-rand amount between R1 and R1,000,000,000.');return n;}
 function depositCurrent(s,n){need(ready(s).bank.current+n<=MAX,'The game current-account balance limit would be exceeded.');ready(s).bank.opened=true;ready(s).bank.current+=n;}
 function spend(s,n,label,id){const e=ready(s);need(e.bank.opened,'Open your free game bank account first.');if(s.dev?.unlimitedMoney===true){log(s,label+' / developer cost waived',0,'Developer mode','Business');return;}need(e.bank.current>=n,'Not enough money in Current. Deposit pocket cash using the Banking app.');e.bank.current-=n;if(id)e.firms[id].expenses+=n;log(s,label,n,'Current',id?D.byId[id].name:'Business setup');}
 function tick(s){const e=ready(s);for(const [id,f]of Object.entries(e.firms)){const d=D.byId[id];if(!d)continue;if(f.open&&f.paidDay!==s.day){f.open=false;f.reason='A new day: reopen and pay the displayed daily costs.';log(s,d.name+' closed for the new day. Review costs before reopening.',0,'business',id);}
  if(f.open&&f.staff&&!(e.work?.kind==='service'&&e.work.biz===id)){
   let count=0;while(s.sim>=f.nextSale&&f.stock>0&&count<100){const pay=quote(d,f);if(f.till+pay>MAX){f.open=false;f.reason='Collect your till before serving more customers.';break;}f.stock--;f.till+=pay;f.sales++;f.revenue+=pay;f.nextSale+=interval(f);count++;}
   if(count)log(s,d.name+': staff served '+count+' customer'+(count===1?'':'s'),count*quote(d,f),'Customers',d.name+' till');
  }
  if(f.open&&f.stock===0&&!(e.work?.kind==='service'&&e.work.biz===id)){f.open=false;f.reason='Sold out. Restock before opening again.';}
 }}
 function perform(s,pose,a){const e=ready(s),b=e.bank,kind=String(a?.kind||''),id=String(a?.id||''),d=Object.hasOwn(D.byId,id)?D.byId[id]:null,f=Object.hasOwn(e.firms,id)?e.firms[id]:null;
  const done=(message,extra={})=>({ok:true,text:message,...extra});
  try{
   if(kind==='openAccount'){need(!b.opened,'Your game account is already open.');b.opened=true;log(s,'Free game account opened',0,'Bank','Current','bank');return done('Ubuntu Bank is ready. No real identity or bank details are used.');}
   if(['deposit','withdraw','save','unsave'].includes(kind)){
    need(b.opened,'Open your free game account first.');const n=amount(a.amount);const map={deposit:['cash','current'],withdraw:['current','cash'],save:['current','savings'],unsave:['savings','current']},[from,to]=map[kind];const read=k=>k==='cash'?s.cash:b[k];need(read(from)>=n,'Not enough money in '+(from==='cash'?'pocket cash':from)+'.');need(read(to)+n<=MAX,'The receiving account would exceed the game balance limit.');if(from==='cash')s.cash-=n;else b[from]-=n;if(to==='cash')s.cash+=n;else b[to]+=n;log(s,({deposit:'Cash deposited',withdraw:'Cash withdrawn',save:'Moved to savings',unsave:'Moved from savings'})[kind],n,from,to,'bank');return done('Transferred R'+n+'. Your total money is unchanged.');
   }
   if(kind==='goal'){need(b.opened,'Open your game account first.');b.goal=amount(a.amount);return done('Savings goal updated. There is no interest or real-money return.');}
   if(kind==='buy'){
    need(d&&!f,'Choose a business you do not already own.');need(near(pose,d.point.id),'Visit this business counter to sign the opening agreement.');need(!pose.ride,'Park your vehicle before opening a business.');need(b.opened,'Open your game Current account first.');
    let paid;if(root.MZNightlife){paid=root.MZNightlife.completePurchase(s,d,pose);}else{need(b.current>=d.price||s.dev?.unlimitedMoney===true,'Deposit enough game money into Current before signing.');paid=s.dev?.unlimitedMoney===true?0:d.price;b.current-=paid;}e.firms[id]={name:text(a.name)||d.name,level:1,stock:0,till:0,staff:0,open:false,paidDay:0,paidAmount:0,nextSale:s.sim+55,sales:0,revenue:0,expenses:root.MZNightlife?d.price:paid,price:'standard',reason:'Restock, then open for today.'};log(s,'Opened '+e.firms[id].name,paid,'Current','Business setup');return done('Your business is yours. Add stock, then open for today.');
   }
   if(['stock','open','close','hire','upgrade','price','collect','rename'].includes(kind)){
    need(d&&f,'Buy this business before managing it.');
    if(kind==='stock'){const n=amount(a.amount);need(n<=capacity(f)-f.stock-(e.work?.kind==='service'&&e.work.biz===id?1:0),'That delivery would exceed your storage capacity.');spend(s,n*d.unitCost,d.name+': supplier invoice / '+n+' units',id);f.stock+=n;return done('Stock delivered. '+f.stock+' units ready.');}
    if(kind==='open'){need(!f.open,'This business is already open.');need(f.stock>0,'Order stock before opening.');const fee=due(s,d,f);spend(s,fee,d.name+': daily premises and wages',id);f.paidDay=s.day;f.paidAmount=bill(d,f);f.open=true;f.reason='';f.nextSale=s.sim+interval(f);return done('Open for day '+s.day+'. '+(f.staff?'Staff will serve while you play.':'Serve customers yourself or hire an assistant.'));}
    if(kind==='close'){need(f.open,'The business is already closed.');f.open=false;f.reason='Closed by owner.';log(s,d.name+': closed for now');return done('Closed. No new orders or staff sales until you reopen.');}
    if(kind==='hire'){need(!f.open,'Close the business before changing staff.');need(f.staff<f.level,'Upgrade the premises to add another assistant.');spend(s,200,d.name+': assistant recruitment',id);f.staff++;return done('Assistant hired. Each assistant costs R45 per open game day.');}
    if(kind==='upgrade'){need(!f.open,'Close the business before upgrading.');need(f.level<3,'This business is already level 3.');spend(s,Math.round(d.price*.45*f.level),d.name+': premises upgrade',id);f.level++;return done('Upgraded to level '+f.level+'. More capacity and a higher sale value.');}
    if(kind==='price'){need(['value','standard','premium'].includes(a.price),'Choose one of the three pricing policies.');need(!f.open,'Close before changing the price policy.');f.price=a.price;return done('Pricing updated. Premium sales take longer; value sales are quicker.');}
    if(kind==='collect'){const n=amount(a.amount);need(f.till>=n,'There is not enough cash in this till.');need(b.current+n<=MAX,'Collect a smaller amount to stay inside the game limit.');f.till-=n;depositCurrent(s,n);log(s,d.name+': takings banked',n,d.name+' till','Current','bank');return done('R'+n+' transferred from the till to Current.');}
    if(kind==='rename'){need(text(a.name).length>=2,'Enter a name between 2 and 40 characters.');f.name=text(a.name);return done('Trading name changed. Map keeps the original location name.');}
   }
   if(kind==='startShift'||kind==='startService'){
    need(d&&near(pose,d.point.id),'Visit the business counter first.');need(!pose.ride,'Park before working at the counter.');need(!e.work,'Finish or cancel your current work ticket first.');
    if(kind==='startShift'){need(!f,'You own this business. Serve your own customers instead of collecting employer wages.');need(e.workDays[id]!==s.day,'You already worked here today. Try another employer or return tomorrow.');e.work={id:++e.sequence,kind:'shift',biz:id,step:0,started:s.sim,day:s.day,quote:d.wage};}
    else {need(f&&f.open&&f.stock>0,'Your shop must be open with stock before serving.');f.stock--;e.work={id:++e.sequence,kind:'service',biz:id,step:0,started:s.sim,day:s.day,quote:quote(d,f)};}
    e.task=null;return done(kind==='startShift'?'Shift started. Complete all three checklist steps for your wage.':'Customer order accepted. One stock unit is reserved.',{work:true});
   }
   if(kind==='beginTask'){
    const w=e.work,def=w&&D.byId[w.biz],t=def?.tasks[w.step];need(w&&t&&near(pose,def.point.id),'Return to your current workstation.');need(!pose.ride,'Park before working.');need(!e.task,'That work step is already in progress.');need(a.work===w.id&&a.step===w.step,'This ticket has changed. Read the current step.');need(a.choice===t.correct,'Check the brief: '+t.brief+' Try the matching choice.');
    e.task={id:++e.sequence,work:w.id,step:w.step,start:s.sim,until:s.sim+t.seconds};return done('Working: '+t.title+'. Keep this panel open or return when ready.');
   }
   if(kind==='finishTask'){
    const w=e.work,t=e.task,def=w&&D.byId[w.biz];need(w&&t&&a.token===t.id&&t.work===w.id,'This step is no longer available.');need(near(pose,def.point.id)&&!pose.ride,'Return to the workstation to finish.');need(s.sim+.001>=t.until,'The work step is still in progress.');
    if(w.step+1===def.tasks.length){if(w.kind==='shift')need(b.current+w.quote<=MAX,'Make space in Current before collecting your wage.');else need(e.firms[w.biz]&&e.firms[w.biz].till+w.quote<=MAX,'Collect the business till before finishing this order.');}
    e.task=null;w.step++;
    if(w.step<def.tasks.length)return done('Step complete. Read the next work card.');
    if(w.kind==='shift'){depositCurrent(s,w.quote);e.shifts++;e.wages+=w.quote;e.workDays[w.biz]=s.day;log(s,def.name+': three-step shift wage',w.quote,'Employer','Current','wages');const paid=w.quote;e.work=null;return done('Shift complete. R'+paid+' paid into Current.',{finished:true});}
    const firm=e.firms[w.biz];firm.till+=w.quote;firm.revenue+=w.quote;firm.sales++;e.services++;firm.nextSale=s.sim+interval(firm);log(s,def.name+': customer order completed',w.quote,'Customer',def.name+' till');const pay=w.quote;e.work=null;return done('Customer served. R'+pay+' is in your business till.',{finished:true});
   }
   if(kind==='cancelWork'){
    need(e.work,'No active work ticket.');const w=e.work;if(w.kind==='service'&&e.firms[w.biz])e.firms[w.biz].stock++;
    e.work=null;e.task=null;log(s,'Work ticket cancelled / no wage or customer payment');return done('Ticket cancelled. Any reserved business stock was returned.');
   }
   if(kind==='guideSeen'){e.guideSeen=true;return done('Everyday life guide read.');}
   return {ok:false,text:'That business action is not available.'};
  }catch(err){return {ok:false,text:err.message||'The transaction could not be completed.'};}
 }
 root.MZCommerce={MAX,initial,clean,ready,near,capacity,bill,due,quote,interval,tick,perform,log};
})(typeof window==='undefined'?globalThis:window);
