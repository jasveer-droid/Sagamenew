'use strict';
/** Original walk-in casino, hobby garage and fictional retail shop. */
(function(root){
 const locations=[{id:'casino',x:-215,z:141,w:38,d:38,name:'Sundown Social Casino',colour:0x566665},{id:'partsGarage',x:-158,z:141,w:34,d:38,name:'Ubuntu Custom Works',colour:0x7c8c89},{id:'leafShop',x:-250,z:140,w:24,d:34,name:'Leaf Lounge',colour:0x8da38b}];
 function build(a){const {world:w,renderer:r,box,col,sign,point,person}=a,G=MZ.Geometry,geo=new G();
  box(-198,.015,146,143,.12,83,0xa6a790);
  for(const road of [{x:-198,z:174,w:141,d:10,name:'After Hours Avenue'},{x:-129,z:137,w:10,d:82,name:'Enterprise South'},{x:-198,z:108,w:142,d:10,name:'Foundry Link'}]){box(road.x,.09,road.z,road.w,.12,road.d,0x505e63);w.roads.push(road);const hor=road.w>road.d;for(let q=-(hor?road.w:road.d)/2+3;q<(hor?road.w:road.d)/2;q+=7)box(road.x+(hor?q:0),.155,road.z+(hor?0:q),hor?2.7:.11,.014,hor?.11:2.7,0xd6ceae);}
  for(const b of locations){const {x,z,w:ww,d,colour}=b;box(x,.21,z,ww,.20,d,0xbdb6a2);for(const v of [-1,1]){box(x+v*ww/2,2.4,z,.3,4.8,d,colour);col(x+v*ww/2,z,.3,d);}box(x,2.4,z-d/2,ww,4.8,.3,colour);col(x,z-d/2,ww,.3);const gap=b.id==='partsGarage'?9:5,wing=(ww-gap)/2;for(const side of [-1,1]){const xx=x+side*(gap/2+wing/2);box(xx,2.4,z+d/2,wing,4.8,.3,colour);col(xx,z+d/2,wing,.3);box(xx,2.25,z+d/2+.16,wing-1,1.5,.05,0x35555d);}box(x,4.3,z+d/2,gap,1,.3,colour);box(x,4.95,z,ww+.4,.20,d+.4,0x314c50);sign(b.name.toUpperCase(),b.id==='casino'?'TABLES / THREE REELS / LOUNGE / GAME MONEY':b.id==='partsGarage'?'ENGINES / MODULAR PARTS / BUILD YOUR OWN':'FICTIONAL CANNABIS / INVENTORY ITEMS',x,4.0,z+d/2+.22,ww-1,1.1,'#183a3d','#e8c887',0,true);w.buildings.push({x,z,w:ww,d,color:colour,name:b.name});
   box(x,.28,z+d/2+3,gap+.4,.14,6,0xbbb395);
  }
  // Ceiling luminaires and wall trim are original low-cost geometry, not realtime ray tracing.
  for(const b of locations){const span=b.w*.75;for(const z of [b.z-8,b.z+5]){box(b.x,4.72,z,span,.12,.5,0x8a8067);box(b.x,4.63,z,span-.3,.07,.35,0xf0d7a2);}for(const side of [-1,1])box(b.x+side*(b.w/2-.2),1.05,b.z,.08,.10,b.d-.5,0xc1a46f);}
  // Warm carpet, real table shapes, wheels, chips and original slot cabinets.
  box(-215,.32,141,36.8,.025,36.8,0x4d3948);for(let x=-232;x<-197;x+=3)for(let z=124;z<159;z+=3)box(x,.338,z,.5,.015,.5,0x8e6f64,Math.PI/4);
  const table=(x,z,label)=>{geo.cylinder(x,1.05,z,2.8,2.8,.24,0x9c784f,24);geo.cylinder(x,1.19,z,2.55,2.55,.045,0x245e51,24);geo.cylinder(x,.66,z,.48,.72,.9,0x294344,12);col(x,z,5.5,5.5);sign(label,'FICTIONAL CHIPS / WALK TO THE PLAYER SIDE',x,2.85,z-3.8,7,.7,'#214b46','#f3d9a2',0,true);};
  table(-224,141,'SINGLE-ZERO ROULETTE');table(-208,141,'BLACKJACK / 3 TO 2');
  geo.cylinder(-224,1.25,140.6,1.04,1.04,.1,0xab8953,37);for(let i=0;i<37;i++){const aa=i*Math.PI*2/37,bb=(i+1)*Math.PI*2/37;geo.triangle([-224,1.31,140.6],[-224+Math.cos(aa),1.31,140.6+Math.sin(aa)],[-224+Math.cos(bb),1.31,140.6+Math.sin(bb)],i===0?0x547b5c:i%2?0x9b3946:0x26383c,[0,1,0]);}geo.sphere(-224,1.38,140.6,.14,.08,.14,0xe9d8a5,8,12);
  for(const x of [-209,-207]){box(x,1.235,142,.6,.015,.9,0xf2e5c9,.1);box(x,1.25,142,.13,.015,.15,0xb94c56);}
  for(const x of [-225,-224,-223,-209,-208,-207])for(let i=0;i<3;i++)geo.cylinder(x,1.23+i*.05,142.8,.13,.13,.05,i%2?0xe0b87b:0x828ac2,12);
  for(const x of [-230,-226,-222]){box(x,1.5,127,2.5,2.7,1.6,0x233c44);col(x,127,2.5,1.6);box(x,2.2,127.84,2.1,1.35,.09,0x3f7876);box(x,1.15,128.1,2.5,.2,1,0x57767a);for(const xx of [-.65,0,.65]){box(x+xx,2.1,127.91,.5,.8,.05,0xe7d8ad);geo.sphere(x+xx,2.08,127.97,.13,.15,.04,0xb65564,6,8);}sign('SUNDOWN REELS','94% THEORETICAL RETURN',x,3.3,127.9,2.9,.65,'#284958','#efcc8b',0,true);}
  box(-204,1.2,127,9.2,2.0,1.8,0x4d6a62);box(-204,2.25,127,9.5,.14,2,0xb29872);col(-204,127,9.5,2);for(const x of [-207,-205,-203,-201]){geo.cylinder(x,2.58,127,.18,.18,.56,0x95baa0,10);geo.cylinder(x,2.85,127,.19,.19,.025,0xd3bf82,10);}sign('THE SOCIAL BAR','WATER / COFFEE / COOLERS / GAME DRINKS',-204,3.5,122.3,10,.9,'#3d5650','#eed7ad',0,true);
  for(const p of [{id:'casino',type:'casino',name:'Sundown Social Casino',kind:'FICTIONAL MONEY ONLY'},{id:'roulette',type:'roulette',name:'Roulette table',kind:'SINGLE ZERO / 0-36'},{id:'blackjack',type:'blackjack',name:'Blackjack table',kind:'HIT / STAND / DOUBLE / SPLIT'},{id:'slots',type:'slots',name:'Sundown Reels',kind:'THREE INDEPENDENT REELS'},{id:'casinoBar',type:'casinoBar',name:'The Social Bar',kind:'DRINKS / GAME ITEMS'},{id:'partsGarage',type:'partsGarage',name:'Ubuntu Custom Works',kind:'ENGINES / MODULAR PARTS'},{id:'leafShop',type:'leafShop',name:'Leaf Lounge',kind:'FICTIONAL CANNABIS SHOP'}]){const pos=MZNightlife.points[p.id];point(p.id,p.type,p.name,pos.x,pos.z,p.kind);}
  // Workshop lift stays walkable at its front interaction marker.
  for(const x of [-161.2,-154.8]){box(x,2,142,.5,4,.65,0x3e7b7b);box(x,4.0,142,.7,.2,1,0xe0b768);col(x,142,.6,.8);}box(-158,.40,142,7.3,.14,8,0x6a8580);for(const x of [-166,-150]){box(x,1.2,128,5,2,1.4,0x426b68);col(x,128,5,1.4);for(let y=.6;y<2.2;y+=.4)box(x,y,128.75,4.7,.025,.03,0xd0be8e);}sign('BUILD / REMOVE / REFIT','PARTS ARE KEPT IN YOUR LOCKER',-158,3.0,122.3,13,1,'#2e4f52','#edc486',0,true);
  // Shop: packaged abstract goods; no real-world recipes or supplier details.
  box(-250,1.05,147,8,1.6,1.3,0x4d7660);box(-250,1.92,147,8.4,.13,1.6,0xc5b28c);col(-250,147,8,1.5);for(const x of [-257,-243])for(let y=.65;y<3;y+=.8){box(x,y,130,3.5,.12,1.1,0x6b7b62);for(let j=0;j<4;j++)geo.cylinder(x-1.25+j*.8,y+.28,130,.22,.22,.45,0xa2b597,10);}sign('LEAF LOUNGE','JOINTS / FLOWER / PACKS / GAME-ONLY STOCK',-250,3.1,123.3,15,1,'#355b46','#ead9b3',0,true);
  const models=[person(0x8b5b43,0x303d4a,0x253d43,false),person(0xb38460,0xb4bba4,0x2f454c,false),person(0x93654a,0x5f9990,0x29444a,false)];
  for(const [i,name,x,z]of [[0,'Masego / dealer',-208,138],[1,'Zuri / lounge host',-204,125],[2,'Ruben / mechanic',-152,151],[2,'Lindi / Leaf Lounge',-250,145]])w.pedestrians.push({name,x,z,ry:0,model:models[i],phase:i,stationary:true});
  w.nightlifeMesh=r.mesh(geo);w.nightlifeBuildings=locations;
  point('nightlifeTaxi','taxi','After Hours taxi stop',-130,173,'TAXI / CASINO / GARAGE');sign('AFTER HOURS AVENUE','CASINO / CUSTOM WORKS / LEAF LOUNGE',-129,3.5,172,11,1.1,'#2d4f55','#ead6a8',Math.PI/2,true);
 }
 function install(r,w){const M=MZ.M,G=MZ.Geometry,old=w.render;
  const hand=new G();hand.ellipsoid(0,0,0,.10,.09,.15,0xa67454,7,10);hand.beam([0,-.02,.06],[.02,-.08,.42],.065,0xa67454,8);const hm=r.mesh(hand),cg=new G();cg.cylinder(0,0,0,.10,.075,.28,0xd8b778,12);cg.cylinder(0,.145,0,.095,.095,.01,0xd39c55,12);const cup=r.mesh(cg);
  w.render=(s,t)=>{old(s,t);r.gl.useProgram(r.cp);r.draw(w.nightlifeMesh);if(Math.hypot(s.player.x+158,s.player.z-142)<65){const id=w.garagePreviewId&&s.rides.owned[w.garagePreviewId]?w.garagePreviewId:Object.keys(s.rides.owned).find(k=>s.rides.owned[k]&&MZMobility.RIDES[k].car);if(id&&!s.rides.riding){const ss={...s,rides:{...s.rides,equipped:id}};MZCarWorld.drawVehicle(r,w,ss,{},M.model(-158,.48,142,Math.PI),t);}}
   if(w.drinkUntil>t){const u=1-(w.drinkUntil-t)/4,cam=w.lastCamera;if(cam){const lift=Math.sin(Math.PI*clamp(u,0,1)),base=M.model(cam.x,cam.y,cam.z,-cam.yaw),local=M.model(.24,-.48+lift*.23,-.56+lift*.12);r.gl.clear(r.gl.DEPTH_BUFFER_BIT);r.draw(hm,M.multiply(base,local));r.draw(cup,M.multiply(base,M.model(.23,-.35+lift*.23,-.59+lift*.12)));}}
  };
 }
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 root.MZNightWorld={build,install,locations};
})(window);
