'use strict';
/** Readable map labels with a searchable complete index. Map coordinates are shared
 * with existing tracking and hit testing; labels never replace the real markers. */
(function(root){
 function entries(w){
  const business={supplier:'Sunset Spaza / Nandi',hardware:'Bay Hardware / Aadil',braai:'Braai & Chill / Thabo',taxi:'Sundown Taxi Rank / Bongani',rideShop:'Ubuntu Wheels / Tumi',carShop:'Ubuntu Motors',restaurant:'Braai & Chill / restaurant',marketSupply:'Market supply kiosk',bayFood:'Bayfront Cafe'};
  const points=w.points.filter(p=>!['seat','grow','bench','inventory','bed'].includes(p.type)).map(p=>({...p,group:'Places',label:business[p.id]||p.name}));
  const landmarks=w.buildings.map((n,i)=>({...n,id:'place'+i,group:'Places',label:n.name||'',name:n.name})).filter(n=>n.label&&!points.some(p=>p.label.toUpperCase().includes(n.label.toUpperCase())));
  return [...w.customers.map(n=>({...n,group:'People',label:n.name})),...points,...landmarks,...w.roads.map((r,i)=>({...r,id:'road'+i,group:'Streets',label:r.name}))];
 }
 function labels(c,w,transform,layer){const {fx,fz}=transform,boxes=[];c.font='600 15px Arial';c.textAlign='left';c.textBaseline='middle';
  const rows=entries(w).filter(n=>layer==='all'||n.group.toLowerCase()===layer);
  for(const n of rows){const text=n.label.split(' / ')[0],tw=Math.min(220,c.measureText(text).width+12),th=20,px=fx(n.x),py=fz(n.z);let rect=null;
   for(const [dx,dy] of [[8,-24],[8,5],[-tw-8,-24],[-tw-8,5],[8,-47],[8,28],[-tw/2,-70]]){const x=Math.max(3,Math.min(c.canvas.width-tw-3,px+dx)),y=Math.max(3,Math.min(c.canvas.height-th-3,py+dy));if(!boxes.some(b=>x<b.x+b.w+2&&x+tw+2>b.x&&y<b.y+b.h+2&&y+th+2>b.y)){rect={x,y,w:tw,h:th};break;}}
   if(!rect)rect={x:Math.max(3,Math.min(c.canvas.width-tw-3,px+8)),y:Math.max(3,Math.min(c.canvas.height-th-3,py+7)),w:tw,h:th};
   boxes.push(rect);c.strokeStyle='#c3d2aa77';c.lineWidth=.6;c.beginPath();c.moveTo(px,py);c.lineTo(rect.x+4,rect.y+10);c.stroke();c.fillStyle=n.group==='Streets'?'#365f5cf5':'#112d34f2';c.fillRect(rect.x,rect.y,rect.w,rect.h);c.fillStyle=n.group==='People'?'#ecf3df':n.group==='Streets'?'#bfe7e0':'#f7cc8d';c.fillText(text,rect.x+6,rect.y+10,tw-10);
  }c.textBaseline='alphabetic';
 }
 function panel(w,esc,zoom,layer,query){const rows=entries(w).filter(n=>(layer==='all'||n.group.toLowerCase()===layer)&&n.label.toLowerCase().includes(query.toLowerCase()));
  return `<div class="atlas-controls"><label>Names <select id="atlasLayer">${['all','people','places','streets'].map(k=>`<option value="${k}" ${k===layer?'selected':''}>${k==='all'?'All names':k[0].toUpperCase()+k.slice(1)}</option>`).join('')}</select></label><div>${[1,1.5,2.5].map(k=>`<button data-action="atlasZoom" data-id="${k}" class="${zoom===k?'primary':'secondary'}">${k}x</button>`).join('')}</div></div><div class="atlas-viewport"><canvas id="largeMap" width="1400" height="930" style="width:${zoom*100}%;max-width:none"></canvas></div><p class="panel-note">Drag/scroll the enlarged map to explore. Names are shown on the map; use the index below for a clear list. Gold marks your destination.</p><label class="atlas-search">Find a person, business or street<input id="atlasSearch" value="${esc(query)}" maxlength="60" placeholder="Try Sipho, Ubuntu or Jacaranda"></label><div id="atlasResults">${rows.map(n=>`<button class="atlas-row" data-action="${n.group==='Streets'?'trackRoad':'track'}" data-id="${n.id}"><span><small>${n.group}</small>${esc(n.label)}</span><b>Track &rarr;</b></button>`).join('')||'<p>No matching names.</p>'}</div>`;
 }
 root.MZAtlas={entries,labels,panel};
})(window);
