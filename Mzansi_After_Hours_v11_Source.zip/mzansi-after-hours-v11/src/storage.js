'use strict';
/** Save schema, validation and local persistence. No backend or account required.
 * Save files deliberately contain gameplay data only, never executable content.
 */
(function (root) {
    const KEY = 'mzansi_after_hours_save';
    const GAME = 'mzansi-after-hours';
    const IDS = MZNeighbourhood.ids;
    function initial(mobile = false) {
        return { version: 11, game: GAME, mode: 'story', freeGuideSeen: false, cash: 2500, rep: 0, heat: 0, sim: 0,
            enterprise: root.MZCommerce?.initial() || null,
            cityLife: root.MZNightlife?.initial() || null,
            outdoors: root.MZActivities?.initial() || {postcards:[],postReward:false,litter:[],recycleNext:0,recycleRuns:0,courierStep:-1,courierNext:0,courierRuns:0,hoops:0,shots:0,restNext:0},
            health: 100, medkits: 1, damageUntil: 0, life: MZLife.initial(), dev: {unlimitedMoney:false,godMode:false,noPolice:false},
            rides: { owned: { skateboard: false, bicycle: false, scooter: false, hatchback: false, bakkie: false, sedan: false, coupe: false, suv: false, van: false, minibus: false, rally: false, classic: false, electric: false }, damage: {}, equipped: null, riding: false, helmet: false },
            roadGuide: { riding: false, traffic: false },
            meta: { savedAt: 0, revision: 0, writer: '' },
            clock: 990, day: 1, inv: { seed: 3, leaf: 8, pouch: 12, dew: 2, sun: 1, prism: 0 },
            products: { glow: 0, mist: 0, sunburst: 0, prism: 0 }, plants: [null, null, null, null], jobs: [], jobSeq: 0,
            upgrades: { lamp: false, mixer: false, bag: false, solar: false }, workshop: false, runner: false,
            runnerActive: true, reserveOrders: true, runnerTick: 0,
            orders: [{ id: 1, npc: 'sipho', recipe: 'glow', qty: 2, pay: 170 }, { id: 2, npc: 'aisha', recipe: 'glow', qty: 1, pay: 90 }, { id: 3, npc: 'lerato', recipe: 'mist', qty: 3, pay: 345 }],
            orderSeq: 3, nextOrder: 55, totalRevenue: 0,
            stats: { crafted: 0, sales: 0, bought: 0, harvested: 0, delivered: 0, fines: 0, runnerSales: 0, trafficHits: 0, knockouts: 0, distanceRidden: 0 },
            track: 'mentor', lastSale: -100, caughtUntil: 0, victory: false, story: MZStory.initial(),
            recovery: { active: false, next: 0, count: 0 }, cooldowns: {},
            player: { x: -32, z: 14.8, yaw: -2.5, pitch: -.015 },
            settings: { receiveOrders: true, sound: true, sensitivity: 1, touchSensitivity: 1, quality: mobile ? 0 : 1,
                carCameraDistance:7, roadWet:false, stabilityAssist:true, autoFullscreen:false, largeText:false, reducedMotion:false, analyticsConsent:false, headbob: !mobile, guidePinned: true, tipSeconds: 16, mobileControls: 'auto', maxFps: mobile ? 30 : 60 } };
    }
    function validate(raw, mobile = false) {
        if (!raw || typeof raw !== 'object' || raw.game !== GAME || ![1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].includes(raw.version))
            throw new Error('Choose a Mzansi After Hours v1 through v11 JSON save.');
        const s = initial(mobile);
        s.mode = raw.mode === 'free' ? 'free' : 'story';
        s.freeGuideSeen = raw.freeGuideSeen === true;
        const n = (v, min = 0, max = 1e9, fallback = min) => typeof v === 'number' && Number.isFinite(v) ? Math.max(min, Math.min(max, v)) : fallback;
        const int = (v, min = 0, max = 1e6, fallback = min) => Math.floor(n(v, min, max, fallback));
        for (const k of ['cash', 'rep', 'sim', 'runnerTick', 'nextOrder', 'totalRevenue', 'caughtUntil'])
            s[k] = n(raw[k], 0, 1e9, s[k]);
        s.health = int(raw.health, 0, 100, 100);
        s.medkits = int(raw.medkits, 0, 99, raw.version < 4 ? 1 : 0);
        s.damageUntil = n(raw.damageUntil, 0, s.sim + 6);
        for (const id in s.rides.owned) s.rides.owned[id] = raw.rides?.owned?.[id] === true;
        s.rides.equipped = Object.hasOwn(s.rides.owned, raw.rides?.equipped) && s.rides.owned[raw.rides.equipped] ? raw.rides.equipped : null;
        // Resume stationary/on foot. Ownership and selection persist, not throttle.
        s.rides.riding = false;
        s.rides.helmet = raw.rides?.helmet === true;
        // Only bounded per-zone damage data is persisted, never simulation velocities.
        for(const id in s.rides.owned)if(s.rides.owned[id]){const d=raw.rides?.damage?.[id];if(d&&typeof d==='object')s.rides.damage[id]={front:n(d.front,0,1),rear:n(d.rear,0,1),left:n(d.left,0,1),right:n(d.right,0,1)};}
        s.roadGuide.riding = raw.roadGuide?.riding === true;
        s.roadGuide.traffic = raw.roadGuide?.traffic === true;
        s.meta = { savedAt: n(raw.meta?.savedAt, 0, 1e15), revision: int(raw.meta?.revision, 0, 1e12),
            writer: typeof raw.meta?.writer === 'string' && /^[a-zA-Z0-9_-]{0,80}$/.test(raw.meta.writer) ? raw.meta.writer : '' };
        s.cash = Math.floor(s.cash);
        s.rep = Math.floor(s.rep);
        s.heat = n(raw.heat, 0, 100);
        s.clock = n(raw.clock, 0, 1e9, 990) % 1440;
        s.day = int(raw.day, 1, 100000, 1);
        s.lastSale = n(raw.lastSale, -100, s.sim, -100);
        for (const group of ['inv', 'products', 'stats'])
            for (const k in s[group])
                s[group][k] = int(raw[group]?.[k]);
        for (const k in s.upgrades)
            s.upgrades[k] = raw.upgrades?.[k] === true;
        for (const k of ['workshop', 'runner', 'victory'])
            s[k] = raw[k] === true;
        s.runner = s.runner && s.workshop;
        s.runnerActive = raw.runnerActive !== false;
        s.reserveOrders = raw.reserveOrders !== false;
        let room = s.upgrades.bag ? 80 : 40;
        for (const k in s.products) {
            s.products[k] = Math.min(s.products[k], room);
            room -= s.products[k];
        }
        s.plants = s.plants.map((_, i) => {
            const p = raw.plants?.[i];
            return i < (s.workshop ? 4 : 2) && p && typeof p === 'object' ?
                { start: n(p.start, 0, s.sim), duration: n(p.duration, 1, 60, 35), notified: p.notified === true, variety: Object.hasOwn(MZLife.VARIETIES,p.variety)?p.variety:"classic", care:{mist:p.care?.mist===true,spark:p.care?.spark===true} } : null;
        });
        s.jobSeq = int(raw.jobSeq, 0, 1e9);
        // Reissue identifiers: imported duplicates can never address the wrong job.
        s.jobs = (Array.isArray(raw.jobs) ? raw.jobs : []).filter(j => j && Object.hasOwn(s.products, j.recipe))
            .slice(0, 1 + Number(s.upgrades.mixer) + Number(s.workshop))
            .map(j => ({ id: ++s.jobSeq, recipe: j.recipe, start: n(j.start, 0, s.sim), duration: n(j.duration, 1, 60, 10),
            taps: int(j.taps, 0, 3), hits: int(j.hits, 0, int(j.taps, 0, 3)), lastTap: n(j.lastTap, -10, s.sim, -10) }));
        s.orderSeq = int(raw.orderSeq, 3, 1e9, 3);
        const used = new Set();
        s.orders = (Array.isArray(raw.orders) ? raw.orders : s.orders)
            .filter(o => o && IDS.includes(o.npc) && Object.hasOwn(s.products, o.recipe) && !used.has(o.npc) && used.add(o.npc))
            .slice(0, 8).map(o => ({ id: ++s.orderSeq, npc: o.npc, recipe: o.recipe, qty: int(o.qty, 1, 5), pay: int(o.pay, 1, 2000) }));
        const p = raw.player || {};
        s.player = { x: n(p.x, MZNeighbourhood.bounds.minX+.5, MZNeighbourhood.bounds.maxX-.5, -32), z: n(p.z, MZNeighbourhood.bounds.minZ+.5, MZNeighbourhood.bounds.maxZ-.5, 14.8), yaw: n(p.yaw, -1e7, 1e7), pitch: n(p.pitch, -1.14, 1.14) };
        const points = ['mentor', 'bench', 'grow', 'bed', 'locker', 'supplier', 'hardware', 'braai', 'workshop', 'workBench', 'runner', 'taxi', 'rideShop', 'road0','road1','road2','road3','road4',...MZNeighbourhood.points, ...(root.MZCommerceData?.points.map(p=>p.id)||[]), ...IDS];
        s.track = raw.track===null ? null : (points.includes(raw.track)||/^(place|road)[0-9]{1,3}$/.test(raw.track)) ? raw.track : s.mode === 'free' ? null : 'mentor';
        if (raw.settings && typeof raw.settings === 'object') {
            for (const k of ['sound', 'headbob'])
                s.settings[k] = raw.settings[k] !== false;
            for(const k of ['autoFullscreen','largeText','reducedMotion','analyticsConsent'])s.settings[k]=raw.settings[k]===true;
            s.settings.guidePinned = raw.settings.guidePinned !== false;
            s.settings.receiveOrders = raw.settings.receiveOrders !== false;
            s.settings.tipSeconds = [8,16,30,0].includes(raw.settings.tipSeconds) ? raw.settings.tipSeconds : 16;
            s.settings.roadWet=raw.settings.roadWet===true; s.settings.stabilityAssist=raw.settings.stabilityAssist!==false;
            s.settings.carCameraDistance=n(raw.settings.carCameraDistance,3.5,11,7);
            s.settings.sensitivity = n(raw.settings.sensitivity, .3, 2.5, 1);
            s.settings.touchSensitivity = n(raw.settings.touchSensitivity, .4, 2, 1);
            s.settings.quality = int(raw.settings.quality, 0, 2, mobile ? 0 : 1);
            s.settings.mobileControls = ['auto', 'on', 'off'].includes(raw.settings.mobileControls) ? raw.settings.mobileControls : 'auto';
            s.settings.maxFps = raw.settings.maxFps === 30 ? 30 : 60;
        }
        for (const id of IDS)
            s.cooldowns[id] = n(raw.cooldowns?.[id], 0, s.sim + 8);
        s.recovery = { active: raw.recovery?.active === true, next: n(raw.recovery?.next, 0, s.sim + 90), count: int(raw.recovery?.count) };
        s.story = MZStory.validate(raw.story);
        if (raw.version === 1) {
            // Keep the old economy but start the new guided story. Infer completed work
            // only where the v1 save contains enough evidence; never discard progress.
            s.story.flags.glowMade = s.stats.crafted > 0;
            s.story.flags.siphoDelivered = s.stats.delivered > 0 && !s.orders.some(o => o.npc === 'sipho');
            if (s.story.flags.siphoDelivered)
                s.story.flags.phone = s.story.flags.trackedSipho = true;
            if (s.stats.bought > 0)
                s.story.flags.seedBought = s.story.flags.pouchBought = true;
            s.victory = false;
        }
        // A tutorial delivery cannot disappear forever, including imported v1 games.
        if (s.mode !== 'free' && !s.story.flags.siphoDelivered && s.story.chapter <= 6 && !s.orders.some(o => o.npc === 'sipho')) {
            if (s.orders.length >= 5)
                s.orders.pop();
            s.orders.push({ id: ++s.orderSeq, npc: 'sipho', recipe: 'glow', qty: 2, pay: 170 });
        }
        s.enterprise=root.MZCommerce?.clean(raw.enterprise,s.sim,s.day)||s.enterprise;
        s.outdoors=root.MZActivities?.clean(raw.outdoors)||s.outdoors;
        s.life=MZLife.clean(raw.life);
        s.cityLife=root.MZNightlife?.clean(raw.cityLife,s)||s.cityLife;
        if(s.cityLife&&!raw.cityLife&&raw.meta?.savedAt>0)s.cityLife.career.seen=true;
        // Refund an interrupted meal once from the saved snapshot. Resume standing.
        const meal=raw.life?.meal;
        if(raw.version>=6&&meal&&Object.hasOwn(MZLife.MEALS,meal.id)&&Number.isFinite(meal.paid)&&meal.paid>0){
            const refund=Math.min(MZLife.MEALS[meal.id].price,meal.paid);s.cash=Math.min(1e9,s.cash+refund);MZLife.log(s,'restaurant','Interrupted meal refunded on return',refund);
        }
        // Developer authorisation is intentionally session-only and never imported.
        s.dev={unlimitedMoney:false,godMode:false,noPolice:false};
        return s;
    }
    function read(storage, mobile = false) {
        const candidates = [KEY, KEY + '_backup1', KEY + '_backup2', 'mzansi_after_hours_v4', 'mzansi_after_hours_v3', 'mzansi_after_hours_v3_backup1', 'mzansi_after_hours_v3_backup2', 'mzansi_after_hours_v2', 'mzansi_after_hours_v2_backup1', 'mzansi_after_hours_v2_backup2', 'mzansi_after_hours_v1'];
        for (const key of candidates) {
            try {
                const raw = storage.getItem(key);
                if (raw)
                    return { state: validate(JSON.parse(raw), mobile), recovered: key !== KEY, key };
            }
            catch (_) { /* Try the next independent backup without overwriting it. */ }
        }
        return null;
    }
    function write(storage, state, rotate = false, writer = '') {
        const meta = { savedAt: Date.now(), revision: (state.meta?.revision || 0) + 1, writer };
        const serialized = JSON.stringify({ ...state, meta });
        // Do not rotate invalid data over valid backups.
        if (rotate) {
            const previous = storage.getItem(KEY);
            if (previous) {
                try {
                    validate(JSON.parse(previous));
                    const backup = storage.getItem(KEY + '_backup1');
                    if (backup)
                        storage.setItem(KEY + '_backup2', backup);
                    storage.setItem(KEY + '_backup1', previous);
                }
                catch (_) { /* Primary save can still be repaired below. */ }
            }
        }
        storage.setItem(KEY, serialized);
        state.meta = meta;
    }
    root.MZSave = { KEY, initial, validate, read, write };
})(typeof window === 'undefined' ? globalThis : window);
