'use strict';
/** Original car meshes and named road signs. No external art or licensed car brands. */
(function(root){
 function model(id){
  const r=MZMobility.RIDES[id],w=r.halfWidth,l=r.halfLength,wb=r.wheelbase,H=MZVehicle.bodyHeight(r),type=r.body||'hatch';
  const shell=new MZ.Geometry(),glass=new MZ.Geometry(),metal=new MZ.Geometry(),lamps=new MZ.Geometry(),trim=new MZ.Geometry();
  const paint=r.colour,dark=0x17252e,chrome=0xb6c8cc,parts=[];
  const tint=(c,f)=>[((c>>16)&255)/255*f,((c>>8)&255)/255*f,(c&255)/255*f];
  // A bevelled multi-section shell, rather than one box. Nose and tail taper.
  const zs=[-l,-l+.13,-l+.42,-wb*.36,wb*.34,l-.4,l-.12,l];
  const ring=(z,i)=>{const f=[.77,.94,1,1,1,1,.92,.79][i],nose=i<2?.09:0;
   return [[-.71*w,.43],[ -w,.59],[ -w,.83-nose],[-.79*w,.96-nose],[.79*w,.96-nose],[w,.83-nose],[w,.59],[.71*w,.43]].map(([x,y])=>[x*f,y,z]);};
  const rings=zs.map(ring);for(let k=0;k<rings.length-1;k++)for(let j=0;j<8;j++)shell.quad(rings[k][j],rings[k+1][j],rings[k+1][(j+1)%8],rings[k][(j+1)%8],tint(paint,j===0||j===6?.77:j===3?1.05:1));
  for(const k of [0,rings.length-1])for(let j=0;j<8;j++)shell.triangle([0,.65,zs[k]],rings[k][k?j:(j+1)%8],rings[k][k?(j+1)%8:j],paint);
  const long=['van','minibus'].includes(type),pickup=type==='pickup',sport=['coupe','electric','classic'].includes(type);
  const bf=long?-l+.20:pickup?-1.46:sport?-1.04:-1.20,br=pickup?.50:long?l-.20:sport?1.27:1.30;
  const rf=long?bf+.21:bf+.45,rr=pickup?.27:long?br-.10:br-.48,baseY=.94,topY=H,baseW=w*.91,roofW=w*(long?.86:.73);
  const A=[-baseW,baseY,bf],B=[baseW,baseY,bf],C=[baseW,baseY,br],D=[-baseW,baseY,br],a=[-roofW,topY,rf],b=[roofW,topY,rf],c=[roofW,topY,rr],d=[-roofW,topY,rr];
  shell.quad(A,B,b,a,paint);shell.quad(B,C,c,b,paint);shell.quad(C,D,d,c,paint);shell.quad(D,A,a,d,paint);shell.quad(a,b,c,d,tint(paint,1.06));
  // Sloping front and rear glass inset into the pillars.
  const lerp=(p,q,t)=>p.map((v,i)=>v+(q[i]-v)*t),off=(p,z)=>[p[0],p[1]+.006,p[2]+z];
  const qwindow=(bottomL,bottomR,topR,topL,z)=>{let bl=lerp(bottomL,topL,.15),tl=lerp(bottomL,topL,.90),br=lerp(bottomR,topR,.15),tr=lerp(bottomR,topR,.90);for(let p of [bl,tl,br,tr])p[0]*=.91;glass.quad(off(bl,z),off(br,z),off(tr,z),off(tl,z),0x344c61);};
  qwindow(A,B,b,a,-.012);qwindow(C,D,d,c,.012);
  for(const side of [-1,1]){
   const bottomF=[side*baseW,.97,bf+.10],bottomR=[side*baseW,.97,br-.10],topF=[side*roofW,H-.075,rf+.07],topR=[side*roofW,H-.075,rr-.07];
   const count=type==='minibus'?4:long?1:pickup||type==='coupe'||type==='classic'?1:2;
   for(let i=0;i<count;i++){const f0=i/count+.025,f1=(i+1)/count-.025,cap=type==='van'?.29:1;
    const p0=lerp(bottomF,bottomR,f0*cap),p1=lerp(bottomF,bottomR,f1*cap),p2=lerp(topF,topR,f1*cap),p3=lerp(topF,topR,f0*cap);for(let p of [p0,p1,p2,p3])p[0]+=side*.012;
    if(side>0)glass.quad(p0,p3,p2,p1,0x3d5666);else glass.quad(p0,p1,p2,p3,0x3d5666);
   }
   trim.beam([side*w*.95,.96,bf+.12],[side*w*.95,.96,br-.07],.014,dark,5);
   // Door seams, contrasting lower sill and handles.
   for(const z of [bf+.12,(bf+br)*.45,br-.12])trim.beam([side*w*1.006,.57,z],[side*w*1.006,.92,z],.006,0x253b40,4);
   trim.box(side*w*.99,.50,.06,.045,.095,l*1.55,dark);
   for(const z of [bf+.63,...(count>1?[(bf+br)*.5+.40]:[])])metal.box(side*w*1.013,.86,z,.018,.040,.19,chrome);
   // Side mirrors with separate reflective face.
   shell.box(side*w*1.10,1.03,bf+.30,.28,.13,.20,paint);glass.box(side*w*1.105,1.03,bf+.405,.21,.08,.013,0x93b2be);
  }
  trim.box(0,.53,-l-.012,w*1.76,.15,.075,dark);trim.box(0,.51,l+.016,w*1.76,.15,.075,dark);
  const grillH=type==='classic'?.21:.15,grillW=type==='electric'?.72:w*.92;
  trim.box(0,.73,-l-.025,grillW,grillH,.035,0x162731);
  for(let y=.67;y<.81;y+=.035)metal.box(0,y,-l-.046,grillW*.93,.010,.015,chrome);
  const round=type==='classic'||type==='rally';
  for(const side of [-1,1]){
   if(round){for(const x of [side*w*.57,side*w*.82])lamps.ellipsoid(x,.82,-l-.025,.12,.105,.035,0xffe7b3,7,12);}
   else lamps.box(side*w*.64,.82,-l-.027,w*.47,.102,.024,0xddeefe);
   lamps.box(side*w*.66,.82,l+.024,w*.40,.095,.022,0xd84043);
   metal.box(side*w*.66,.82,l+.040,w*.03,.095,.015,0xf9ba7b);
   trim.box(side*w*.6,.45,l+.08,.16,.10,.22,0x27393e);
  }
  metal.box(0,.51,-l-.056,.48,.12,.015,0xf0ecda);metal.box(0,.55,l+.064,.5,.12,.015,0xf0ecda);
  trim.box(0,.51,-l-.068,.29,.023,.009,0x29414a);trim.box(0,.55,l+.078,.29,.023,.009,0x29414a);
  if(type==='classic'){metal.box(0,.57,-l-.08,w*1.94,.092,.14,chrome);metal.box(0,.56,l+.08,w*1.94,.09,.15,chrome);shell.box(0,.985,-1.32,w*1.5,.025,.66,paint);}
  if(pickup){trim.box(0,.985,1.30,w*1.73,.03,1.54,0x344c51);for(const side of [-1,1])shell.box(side*w*.95,1.115,1.28,.11,.30,1.65,paint);shell.box(0,1.115,l-.04,w*1.93,.30,.10,paint);for(let x=-w*.6;x<w*.7;x+=.18)trim.box(x,1.004,1.3,.018,.014,1.37,0x74817b);}
  if(type==='rally'||type==='coupe'){for(const x of [-w*.62,w*.62])trim.box(x,H+.035,rr-.05,.07,.18,.14,dark);shell.box(0,H+.13,rr+.04,w*1.96,.06,.29,paint);}
  if(type==='suv'){for(const x of [-w*.66,w*.66])metal.beam([x,H+.06,rf+.1],[x,H+.06,rr-.1],.035,0x64757c,8);}
  if(type==='electric')glass.box(0,H+.012,(rf+rr)/2,roofW*1.80,.025,(rr-rf)*.9,0x293e50);
  if(type==='minibus'){for(const side of [-1,1]){shell.box(side*w*1.008,.65,.20,.010,.08,l*1.75,0xd1ac4f);trim.box(side*w*1.015,.76,.20,.014,.06,l*1.70,0x366e68);}lamps.box(0,H+.028,rf+.35,.28,.06,.07,0xefc367);}
  if(type==='van'){for(const side of [-1,1])shell.box(side*baseW*1.02,1.40,.72,.02,.36,1.20,0x396a69);}
  if(type==='rally'){for(const x of [-.34,.34]){trim.ellipsoid(x,.75,-l-.14,.16,.16,.05,dark,8,12);lamps.ellipsoid(x,.75,-l-.195,.12,.12,.015,0xf8e9b8,8,12);}for(const x of [-.13,.13])trim.box(x,.985,-1.32,.13,.016,.36,dark);}
  parts.push({geo:shell,finish:1,role:'shell',deform:true},{geo:glass,finish:2,role:'glass',deform:true},{geo:trim,finish:0,role:'trim',deform:true},{geo:metal,finish:1.6,role:'metal',deform:true},{geo:lamps,finish:3,role:'lamps',deform:true});
  const radius=['suv','pickup'].includes(type)?.395:.35;
  for(const [i,z]of [-wb/2,wb/2].entries())for(const side of [-1,1]){
   const tire=new MZ.Geometry(),rim=new MZ.Geometry(),segments=22,tube=radius*.23;
   const p=(a,b)=>[Math.cos(b)*.135,Math.sin(a)*(radius-tube+Math.sin(b)*tube),Math.cos(a)*(radius-tube+Math.sin(b)*tube)];
   for(let j=0;j<segments;j++)for(let k=0;k<8;k++)tire.quad(p(j*2*Math.PI/segments,k*Math.PI/4),p((j+1)*2*Math.PI/segments,k*Math.PI/4),p((j+1)*2*Math.PI/segments,(k+1)*Math.PI/4),p(j*2*Math.PI/segments,(k+1)*Math.PI/4),0x1c272d);
   for(let j=0;j<segments;j++){const a=j*2*Math.PI/segments; tire.beam([-.102,Math.sin(a)*radius,Math.cos(a)*radius],[.102,Math.sin(a+.028)*radius,Math.cos(a+.028)*radius],.007,0x3a4448,4);}
   const face=side*.141;rim.ellipsoid(face,0,0,.016,radius*.64,radius*.64,0x263943,7,18);
   for(let j=0;j<6;j++){const a=j*Math.PI/3;rim.beam([face+side*.013,Math.sin(a)*.035,Math.cos(a)*.035],[face+side*.008,Math.sin(a)*radius*.64,Math.cos(a)*radius*.64],.023,chrome,6);}
   rim.ellipsoid(face+side*.028,0,0,.014,.063,.063,chrome,6,10);
   const geo=new MZ.Geometry();geo.parts=[{geo:tire,finish:0},{geo:rim,finish:1.5}];geo.v=[...tire.v,...rim.v];
   parts.push({geo,role:'wheel',front:i===0,side,x:side*w*.985,y:radius,z,index:i*2+(side>0?1:0)});
  }
  const g=new MZ.Geometry();g.carId=id;g.parts=parts;g.v=[...shell.v,...glass.v,...trim.v,...metal.v,...lamps.v];return root.MZNightGarage?MZNightGarage.partition(g,r):g;
 }
 function drawVehicle(renderer,world,s,m,mat,time){
  const id=s.rides.equipped,mesh=world.rideMeshes[id];if(!mesh?.parts){renderer.draw(mesh,mat);return;}
  const r=MZMobility.RIDES[id];world.vehicleShells??={};let rec=world.vehicleShells[id];
  const damage=MZVehicle.clean(s.rides.damage?.[id]),key=JSON.stringify(damage);
  if(!rec){
   // Only the currently driven car needs a deforming skin. Keep the saved zone
   // damage, but release inactive copies/bindings to bound mobile memory use.
   for(const [other,cached]of Object.entries(world.vehicleShells))if(other!==id){for(const part of cached.parts)if(part)renderer.gl.deleteBuffer(part.mesh.buffer);delete world.vehicleShells[other];}
   const cage=MZVehicle.createCage(r,damage);rec=world.vehicleShells[id]={cage,key,parts:mesh.parts.map(p=>{if(!p.deform)return null;const base=p.mesh.source;return {base,out:base.slice(),bindings:Array.from({length:base.length/9},(_,i)=>MZVehicle.weights(cage,base[i*9],base[i*9+1],base[i*9+2])),mesh:renderer.mesh({v:base,finish:p.mesh.finish})};}),last:time,drawTime:-1};}
  if(rec.key!==key){MZVehicle.setCrush(rec.cage,damage,12);rec.key=key;rec.drawTime=-1;}
  MZVehicle.cageStep(rec.cage,Math.max(0,time-rec.last));rec.last=time;
  const updating=rec.drawTime<0||(rec.cage.age<2.8&&time-rec.drawTime>(s.settings.quality===0?1/15:1/30));
  if(updating){for(const p of rec.parts)if(p){MZVehicle.skin(rec.cage,p.base,p.bindings,p.out);const gl=renderer.gl;gl.bindBuffer(gl.ARRAY_BUFFER,p.mesh.buffer);gl.bufferSubData(gl.ARRAY_BUFFER,0,p.out);}rec.drawTime=time;}
  mesh.parts.forEach((part,i)=>{if(root.MZNightlife&&!MZNightlife.visible(s,id,part))return;if(part.role==='wheel'){
    let wheel=MZ.M.model(part.x,part.y+(m.suspension?.[part.index]||0),part.z,part.front?-(m.steer||0):0);
    const spin=m.wheelSpin||0,c=Math.cos(spin),sn=Math.sin(spin),rot=new Float32Array([1,0,0,0,0,c,sn,0,0,-sn,c,0,0,0,0,1]);
    wheel=MZ.M.multiply(wheel,rot);renderer.draw(part.mesh,MZ.M.multiply(mat,wheel));
   }else renderer.draw(rec.parts[i]?.mesh||part.mesh,mat);
  });
 }
 function effects(r,w,s,m,time){
  if(!s.rides.riding||!MZMobility.RIDES[s.rides.equipped]?.car)return;
  const v=MZMobility.RIDES[s.rides.equipped],road=MZVehicle.surface(w,s.player.x,s.player.z,s.settings.roadWet),y=road.name==='Paving'?.236:road.name==='Forecourt'?.345:.080;
  if(!w.carShadow){const g=new MZ.Geometry();for(let i=0;i<32;i++){const a=i*Math.PI/16,b=(i+1)*Math.PI/16,p=(a,rad)=>[Math.cos(a)*rad,0,Math.sin(a)*rad];const c=[0,0,0],n=p(a,.66),nn=p(b,.66),o=p(a,1),oo=p(b,1);g.triangle(c,n,nn,[.9,.9,.9],[0,1,0]);const start=g.v.length;g.quad(n,o,oo,nn,[0,0,0],[0,1,0]);for(let k=start;k<g.v.length;k+=9){const rr=Math.hypot(g.v[k],g.v[k+2]);g.v[k+6]=g.v[k+7]=g.v[k+8]=rr<.8?.9:0;}}g.finish=-1;w.carShadow=r.mesh(g);}
  const matrix=MZ.M.model(s.player.x,y,s.player.z,-m.heading);matrix[0]*=v.halfWidth*1.10;matrix[2]*=v.halfWidth*1.10;matrix[8]*=v.halfLength*1.05;matrix[10]*=v.halfLength*1.05;
  r.gl.useProgram(r.cp);r.draw(w.carShadow,matrix);
  w.skids??=[];const old=w.skidLast,sliding=(m.handBrake||m.traction>.10)&&Math.abs(m.speed)>3&&['Asphalt','Wet asphalt'].includes(road.name);
  if(sliding&&(!old||Math.hypot(old.x-s.player.x,old.z-s.player.z)>.55)){
   if(old&&Math.hypot(old.x-s.player.x,old.z-s.player.z)<4){for(const side of [-1,1]){const point=(p,h)=>[p.x+Math.sin(h)*v.wheelbase/2+Math.cos(h)*side*v.halfWidth,.081,p.z-Math.cos(h)*v.wheelbase/2+Math.sin(h)*side*v.halfWidth];w.skids.push({a:point(old,old.h),b:point(s.player,m.heading),at:time});}}
   w.skidLast={x:s.player.x,z:s.player.z,h:m.heading};
  }else if(!sliding)w.skidLast=null;
  w.skids=w.skids.filter(a=>time-a.at<40).slice(-64);
  if(time-(w.skidDrawAt||-100)>.14&&w.skids.length){const g=new MZ.Geometry();for(const mark of w.skids){const dx=mark.b[0]-mark.a[0],dz=mark.b[2]-mark.a[2],length=Math.hypot(dx,dz)||1,ox=dz/length*.075,oz=-dx/length*.075,f=(1-(time-mark.at)/40)*.7;g.quad([mark.a[0]-ox,.081,mark.a[2]-oz],[mark.a[0]+ox,.081,mark.a[2]+oz],[mark.b[0]+ox,.081,mark.b[2]+oz],[mark.b[0]-ox,.081,mark.b[2]-oz],[f,f,f],[0,1,0]);}g.finish=-1;if(w.skidMesh)r.gl.deleteBuffer(w.skidMesh.buffer);w.skidMesh=r.mesh(g);w.skidDrawAt=time;}
  if(w.skids.length&&w.skidMesh)r.draw(w.skidMesh);
 }
 function install(r,w){const g=new MZ.Geometry();g.box(-57,.25,40,9,.18,19,0x536866);for(const z of [34.5,44]){g.box(-57,.35,z,7.5,.025,.07,0xeac783);g.box(-53.25,.35,z+3,.07,.025,5.5,0xeac783);}
  g.box(-58,2.0,49,.15,4,.15,0x4b665e);w.signs.push({x:-58,y:3.45,z:48.8,ry:Math.PI,lit:true,quad:r.makeSign('UBUNTU MOTORS','10 ORIGINAL CARS / SALES & SERVICE',8.9,1.15,'#214c51','#f8dba4')});
  w.points.push({id:'carShop',type:'carShop',name:'Ubuntu Motors / cars',kind:'10 ORIGINAL CARS / MOTOR DEALERSHIP',x:-58.5,z:30});
  for(const [z,id]of [[36,'hatchback'],[45,'bakkie']]){const v=MZMobility.RIDES[id];w.colliders.push({x1:-57-v.halfWidth,x2:-57+v.halfWidth,z1:z-v.halfLength,z2:z+v.halfLength,kind:'parked'});}for(const v of w.parkedTaxis||[]){w.colliders.push({x1:v.x-1.25,x2:v.x+1.25,z1:v.z-2.5,z2:v.z+2.5,kind:'parked'});}const ground=r.mesh(g);const old=w.render;
  w.render=(s,t)=>{r.draw(ground);if(w.rideMeshes?.hatchback){r.draw(w.rideMeshes.hatchback,MZ.M.model(-57,.36,36,0));r.draw(w.rideMeshes.bakkie,MZ.M.model(-57,.36,45,0));}old(s,t);};
  const names=['Ubuntu Avenue','Sundown Road','Market Street','Bayfront Road','Jacaranda Drive'];w.roads.forEach((a,i)=>a.name=names[i]||a.name||'Local Road');const get=w.getPoint;w.getPoint=id=>/^road[0-9]+$/.test(id)&&w.roads[Number(id.slice(4))]?{...w.roads[Number(id.slice(4))],id,type:'district'}:/^place[0-9]+$/.test(id)&&w.buildings[Number(id.slice(5))]?{...w.buildings[Number(id.slice(5))],id,type:'district'}:get(id);
  const signs=[[-63,7,'UBUNTU AVENUE'],[11,-52,'SUNDOWN ROAD'],[-82,38,'MARKET STREET'],[83,40,'BAYFRONT ROAD'],[-61,-71,'JACARANDA DRIVE']];
  const sg=new MZ.Geometry();for(const [x,z,text] of signs){sg.box(x,1.45,z,.09,2.9,.09,0x3b6054);w.signs.push({x,y:2.55,z,ry:0,lit:true,quad:r.makeSign(text,'SUNDOWN BAY',4.3,.62,'#296256','#f5e7c7')});}const mesh=r.mesh(sg),render=w.render;w.render=(s,t)=>{r.draw(mesh);render(s,t);};
 }
 root.MZCarWorld={model,install,drawVehicle,effects};
})(window);
