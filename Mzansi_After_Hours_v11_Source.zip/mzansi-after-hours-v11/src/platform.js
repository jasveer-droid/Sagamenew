'use strict';
/** Optional hosted offline cache. The standalone HTML never needs this. */
(function () {
    if (window.MZ_STANDALONE || !('serviceWorker' in navigator))
        return;
    const params = new URLSearchParams(location.search);
    if (params.has('debug'))
        return;
    const local = ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
    // Keep development edits fresh. On localhost, opt in with ?offline=1.
    if (local && params.get('offline') !== '1')
        return;
    if (location.protocol !== 'https:' && !local)
        return;
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').catch(() => {
            // Offline cache is optional; the actual game remains usable without it.
        });
    });
})();
