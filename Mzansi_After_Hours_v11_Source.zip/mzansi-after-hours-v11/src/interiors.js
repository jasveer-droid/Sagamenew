'use strict';
/** Open-door restaurant interior built from original local geometry. */
(function(root){
 function restaurant(world,renderer,g){
  const box=(...a)=>g.box(...a),col=(x,z,w,d)=>world.colliders.push({x1:x-w/2,x2:x+w/2,z1:z-d/2,z2:z+d/2,kind:'solid'});
  const sign=(text,sub,x,y,z,w,h,ry=0,bg='#203e39')=>world.signs.push({x,y,z,ry,lit:true,quad:renderer.makeSign(text,sub,w,h,bg,'#f1d5a0')});
  box(39,.10,-19,24,.20,16,0x958572);
  for(let x=28;x<51;x+=2)for(let z=-26;z<-11;z+=2)box(x,.22,z,1.98,.04,1.98,(Math.round((x-28+z+26)/2)%2)?0xb2a18a:0xc7bda3);
  for(const [x,z,w,d] of [[27,-19,.35,16],[51,-19,.35,16],[39,-27,24,.35],[31.7,-11,9.4,.35],[46.3,-11,9.4,.35]]){box(x,2.3,z,w,4.6,d,0xb67e62);col(x,z,w,d);}
  box(39,4.02,-11,5.3,1.3,.35,0x365d53);box(39,4.72,-19,24.5,.20,16.5,0x375d54);
  for(const x of [31.5,46.5]){box(x,2.1,-10.78,4.8,1.6,.10,0x416767);box(x,2.1,-10.70,.08,1.65,.08,0xddcba5);box(x,2.1,-10.7,4.85,.06,.08,0xddcba5);}
  box(39,.23,-11,5.1,.07,3,0x608d76);
  sign('BRAAI & CHILL','COME INSIDE / SIT / EAT / UNWIND',39,4.0,-10.75,10,1.05);
  sign('WELCOME, NEIGHBOUR','FIND A TABLE AND TAKE A SEAT',39,2.7,-26.77,7.6,1.1);
  // Back kitchen and service island.
  box(39,1.02,-24.2,7.2,1.6,1.5,0x557e6b);box(39,1.86,-24.2,7.5,.12,1.8,0xcdbd98);col(39,-24.2,7.2,1.5);
  for(const x of [36.8,38.8,40.8]){g.cylinder(x,1.99,-24.1,.34,.30,.15,0xbfd0b7,12);g.sphere(x,2.12,-24.1,.23,.12,.23,0xd38d54,5,8);}
  sign('THE HOUSE MENU','PAP 45 / BRAAI 85 / ROOIBOS 20',47,2.9,-26.73,4.8,1.5,0,'#344641');
  const seats=[];
  for(const [i,x,z] of [[1,31.5,-16.5],[2,46.5,-16.5],[3,31.5,-22],[4,46.5,-22]]){
   g.cylinder(x,1.02,z,1.23,1.23,.17,0x9d7050,12);g.cylinder(x,.59,z,.15,.27,.85,0x355b51,8);col(x,z,2.05,2.05);
   // Chair sits south of its table; its collision remains open so sitting is safe.
   for(const zz of [z+2,z-2]){box(x,.66,zz,.95,.16,.95,0x597b67);box(x,1.09,zz+(zz>z?.46:-.46),.94,.8,.12,0x597b67);for(const xx of [x-.34,x+.34])box(xx,.34,zz,.07,.65,.65,0x4b5b47);}
   const seat={id:'table'+i,type:'seat',name:'Table '+i+' / take a seat',kind:'BRAAI & CHILL',x,z:z+2,tableX:x,tableZ:z,yaw:0};seats.push(seat);world.points.push(seat);
   // Table number, bowl, napkin and a little plant.
   box(x-.43,1.14,z,.42,.03,.36,0xe9ddbd);g.cylinder(x+.45,1.23,z-.35,.13,.10,.35,0xbb8e62,7);g.sphere(x+.45,1.49,z-.35,.26,.30,.26,0x8dac76,5,7);
   box(x,3.7,z,.05,1.5,.05,0x3c4a40);g.cylinder(x,3.04,z,.2,.55,.40,0xddb370,12);
  }
  for(const x of [28.3,49.6]){g.cylinder(x,.52,-25.2,.53,.39,.8,0xa97357,8);g.sphere(x,1.48,-25.2,.8,1,.8,0x6b9472,5,8);}
  world.seats=seats;world.inRestaurant=(x,z)=>x>27.25&&x<50.75&&z>-26.7&&z<-10.7;
  world.points.push({id:'restaurant',type:'restaurant',name:'Braai & Chill / restaurant',kind:'WALK INSIDE THROUGH THE OPEN DOOR',x:39,z:-12.1});
  world.buildings.push({x:39,z:-19,w:24,d:16,color:0xb67e62,name:'BRAAI & CHILL'});
 }
 function install(renderer,world){
  const plates={},bites={},G=MZ.Geometry,M=MZ.M;
  for(const id of ['pap','braai','tea']){
   const plate=new G();
   if(id==='tea'){plate.cylinder(0,.14,0,.22,.16,.30,0xe1d4b2,16);plate.cylinder(0,.297,0,.193,.193,.009,0x7e4427,16);plate.ellipsoid(.25,.18,0,.11,.1,.065,0xe1d4b2,8,12);}
   else {plate.cylinder(0,0,0,.47,.44,.055,0xe8dac1,18);plate.cylinder(0,.03,0,.39,.42,.04,0xcbbd9e,16);}
   const food=new G();
   if(id!=='tea'){
    food.sphere(-.18,.14,.04,.23,.17,.22,0xe6d4a0,8,12);
    if(id==='braai'){food.ellipsoid(.15,.105,.08,.24,.08,.13,0x986042,8,12);food.ellipsoid(.13,.11,-.18,.19,.075,.115,0xa56943,8,12);for(let i=0;i<4;i++)food.box(.06+i*.058,.183,.07,.014,.005,.18,0x574736,.24);}
    else for(let i=0;i<14;i++){const x=.12+Math.sin(i*2.4)*.13,z=Math.cos(i*2.4)*.14;food.sphere(x,.10+(i%3)*.015,z,.057,.06,.06,[0xc66c3d,0xe29b46,0x8d974d][i%3],5,7);}
   }
   plates[id]=renderer.mesh(plate);bites[id]=renderer.mesh(food);
  }
  const hand=new G();hand.ellipsoid(0,0,0,.075,.055,.13,0xab7856,9,12);for(let i=0;i<4;i++)hand.beam([-.046+i*.029,0,-.07],[-.045+i*.029,-.008,-.20],.014,0xb58660,6);
  const arm=new G();arm.beam([0,0,0],[0,-.15,.32],.064,0x42756c,10);
  const spoon=new G();spoon.beam([0,0,.12],[0,0,-.20],.013,0xbac7bd,8);spoon.ellipsoid(0,0,-.24,.05,.009,.08,0xd8ded0,8,12);spoon.sphere(0,.026,-.24,.037,.025,.055,0xd7b47b,6,8);
  const handMesh=renderer.mesh(hand),armMesh=renderer.mesh(arm),spoonMesh=renderer.mesh(spoon),old=world.render;
  world.render=(s,t)=>{old(s,t);if(!s.life?.seat||!s.life.meal)return;const seat=world.seats.find(p=>p.id===s.life.seat),meal=MZLife.MEALS[s.life.meal.id];if(!seat||!meal)return;
   renderer.gl.useProgram(renderer.cp);
   const id=s.life.meal.id,elapsed=Math.max(0,meal.seconds-s.life.meal.remaining),progress=Math.min(1,elapsed/meal.seconds),phase=(elapsed%1.5)/1.5,lift=Math.pow(Math.sin(phase*Math.PI),2),remaining=Math.max(.08,1-progress);
   if(id!=='tea'||lift<.12){renderer.draw(plates[id],M.model(seat.tableX,1.14,seat.tableZ+.50));if(id!=='tea')renderer.draw(bites[id],M.model(seat.tableX,1.18,seat.tableZ+.50,0,.30+.70*remaining));}
   // First-person arms reach from the seated player to the plate, then lift a bite.
   const yaw=s.player.yaw,C=Math.cos(yaw),S=Math.sin(yaw),local=(x,y,z)=>[s.player.x+x*C-z*S,y,s.player.z+x*S+z*C];
   const h=local(.23, .81+lift*.38,-.92+lift*.62),model=M.model(...h,-yaw);
   renderer.draw(handMesh,model);renderer.draw(armMesh,model);
   if(id==='tea'){if(lift>=.12){const c=local(.17,.83+lift*.35,-.9+lift*.65);renderer.draw(plates.tea,M.model(...c,-yaw,.75));}}
   else renderer.draw(spoonMesh,model);
   const left=local(-.30,.78,-.65);renderer.draw(handMesh,M.model(...left,-yaw));renderer.draw(armMesh,M.model(...left,-yaw));
  };
 }
 root.MZInterior={restaurant,install};
})(window);
