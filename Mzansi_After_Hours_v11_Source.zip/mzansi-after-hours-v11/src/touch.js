'use strict';
/** Independent pointer IDs allow walking and looking at the same time.
 * Pointer cancellation, blur, menus and orientation changes all clear movement.
 */
(function (root) {
    root.createTouchControls = function (canvas, callbacks) {
        const stick = document.getElementById('joystick');
        const nub = document.getElementById('joystickNub');
        const controls = document.getElementById('touchControls');
        const sprint = document.getElementById('touchSprint');
        const input = { x: 0, y: 0, sprint: false };
        let moveId = null, lookId = null, origin = null, look = null, enabled = false;
        const clear = () => { input.x = input.y = 0; input.sprint = false; moveId = lookId = null; origin = look = null; nub.style.transform = 'translate(-50%, -50%)'; sprint.classList.remove('held'); };
        function update() {
            const mode = callbacks.settings().mobileControls;
            enabled = mode === 'on' || (mode !== 'off' && (MZGuide.detectInput() === 'touch'));
            document.body.classList.toggle('touch-mode', enabled);
            callbacks.onMode?.(enabled);
            if (!enabled) clear();
            controls.classList.toggle('hidden', !enabled || !callbacks.active());
            if (!callbacks.active())
                clear();
        }
        stick.addEventListener('pointerdown', e => {
            if (!enabled || !callbacks.active() || moveId !== null)
                return;
            e.preventDefault();
            moveId = e.pointerId;
            const r = stick.getBoundingClientRect();
            origin = { x: r.left + r.width / 2, y: r.top + r.height / 2, radius: r.width * .31 };
            stick.setPointerCapture(e.pointerId);
            move(e);
        });
        function move(e) {
            if (e.pointerId !== moveId || !origin)
                return;
            const dx = e.clientX - origin.x, dy = e.clientY - origin.y;
            const length = Math.hypot(dx, dy), scale = Math.min(1, origin.radius / (length || 1));
            input.x = dx * scale / origin.radius;
            input.y = -dy * scale / origin.radius;
            if (length < origin.radius * .08)
                input.x = input.y = 0;
            nub.style.transform = 'translate(calc(-50% + ' + dx * scale + 'px), calc(-50% + ' + dy * scale + 'px))';
        }
        stick.addEventListener('pointermove', move);
        function endMove(e) { if (e.pointerId === moveId) {
            moveId = null;
            origin = null;
            input.x = input.y = 0;
            nub.style.transform = 'translate(-50%, -50%)';
        } }
        for (const event of ['pointerup', 'pointercancel', 'lostpointercapture'])
            stick.addEventListener(event, endMove);
        canvas.addEventListener('pointerdown', e => {
            if (!enabled || !callbacks.active() || e.pointerType === 'mouse' || lookId !== null)
                return;
            e.preventDefault();
            lookId = e.pointerId;
            look = { x: e.clientX, y: e.clientY };
            canvas.setPointerCapture(e.pointerId);
        });
        canvas.addEventListener('pointermove', e => {
            if (e.pointerId !== lookId || !look || !callbacks.active())
                return;
            callbacks.look(e.clientX - look.x, e.clientY - look.y);
            look = { x: e.clientX, y: e.clientY };
        });
        function endLook(e) { if (e.pointerId === lookId) {
            lookId = null;
            look = null;
        } }
        for (const event of ['pointerup', 'pointercancel', 'lostpointercapture'])
            canvas.addEventListener(event, endLook);
        document.getElementById('touchUse').addEventListener('click', () => { if (callbacks.active())
            callbacks.interact(); });
        sprint.addEventListener('pointerdown', e => { e.preventDefault(); if (!callbacks.active())
            return; sprint.setPointerCapture(e.pointerId); input.sprint = true; sprint.classList.add('held'); });
        for (const event of ['pointerup', 'pointercancel', 'lostpointercapture'])
            sprint.addEventListener(event, () => { input.sprint = false; sprint.classList.remove('held'); });
        window.addEventListener('blur', clear);
        window.addEventListener('orientationchange', clear);
        window.addEventListener('mz:layoutchange', e => { if(e.detail.major) clear(); });
        window.addEventListener('resize', update);
        for(const q of ['(pointer:coarse)','(pointer:fine)','(hover:hover)']) window.matchMedia(q).addEventListener?.('change', update);
        return { input, clear, update, get enabled() { return enabled; } };
    };
})(window);
