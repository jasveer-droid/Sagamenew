'use strict';
/** Local crowd behaviour and articulated animation. Non-graphic, non-fatal hits.
 * Customers keep their anchors in co-op to match server trading positions.
 * Ambient behaviour and knockdown presentation are local, like police in v7. */
(function(root){
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),angle=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
 const hash=s=>{let n=0;for(const c of String(s))n=(n*31+c.charCodeAt(0))>>>0;return n;};
 function setup(p){if(p.crowd)return p.crowd;const seed=hash((p.id||p.name||'person')+p.x+','+p.z);return p.crowd={homeX:p.homeX??p.x,homeZ:p.homeZ??p.z,seed,health:100,mode:'idle',until:0,next:2+seed%8,cycle:0,goal:null,fallAt:0,fallYaw:0,vx:0,vz:0,immune:0,alert:0,look:0,speech:'',phase:seed%100};}
 function injured(p){return ['falling','down','rising'].includes(p.crowd?.mode);}
 function visibleLine(w,a,b,s){const steps=Math.ceil(Math.hypot(b.x-a.x,b.z-a.z)/.5);for(let i=1;i<steps;i++){if(!w.isFree(a.x+(b.x-a.x)*i/steps,a.z+(b.z-a.z)*i/steps,s,.05))return false;}return true;}
 function hit(p,car,s,w){const a=setup(p),speed=Math.hypot(car.vx||0,car.vz||0);if(speed<2.2||injured(p)||s.sim<a.immune)return null;
  const damage=clamp(Math.round(speed*3.4),8,65);a.health=Math.max(1,a.health-damage);a.mode='falling';a.helped=false;a.fallAt=s.sim;a.until=s.sim+4.5+damage*.045;a.immune=a.until+5;a.speech='Hurt / recovering';a.goal=null;p.walk=false;
  const n=Math.max(.1,speed);a.vx=car.vx/n*clamp(speed*.36,1,4);a.vz=car.vz/n*clamp(speed*.36,1,4);a.fallYaw=Math.atan2(a.vx,a.vz);p.ry=a.fallYaw;
  return {person:p,damage,source:car.source||'traffic'};
 }
 function sweep(p,car){
  const old=car.old||car,past=car.heading??0,dx=car.x-old.x,dz=car.z-old.z,steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.22)),C=Math.cos(past),S=Math.sin(past);
  for(let i=0;i<=steps;i++){const x=p.x-(old.x+dx*i/steps),z=p.z-(old.z+dz*i/steps);if(Math.abs(x*C+z*S)<(car.halfWidth||1.08)+.28&&Math.abs(x*S-z*C)<(car.halfLength||2.25)+.28)return true;}return false;
 }
 function collisions(w,s,cars){const events=[];for(const p of [...w.customers,...w.pedestrians,...w.police]){if(p.requires&&!s[p.requires])continue;for(const car of cars){if(Math.hypot(car.vx||0,car.vz||0)<2.2||Math.hypot(p.x-car.x,p.z-car.z)>10)continue;if(sweep(p,car)){const e=hit(p,car,s,w);if(e){events.push(e);break;}}}}return events;}
 function move(w,p,dx,dz,s){if(w.move)w.move(p,dx,dz,s,.29);else if(w.isFree(p.x+dx,p.z+dz,s,.29)){p.x+=dx;p.z+=dz;}}
 function onRoad(w,x,z){return w.roads.some(r=>Math.abs(x-r.x)<r.w/2+.4&&Math.abs(z-r.z)<r.d/2+.4);}
 function reset(w){for(const p of [...w.customers,...w.pedestrians,...w.police]){const a=p.crowd;const x=p.homeX??a?.homeX??p.x,z=p.homeZ??a?.homeZ??p.z;p.x=x;p.z=z;p.walk=false;delete p.crowd;setup(p);}}
 function tick(w,s,dt,{coop=false,locked=null,cars=[],horn=false}={}){
  if(w.crowdState&&(w.crowdState!==s||w.crowdCoop!==coop))reset(w);w.crowdState=s;w.crowdCoop=coop;

  for(const p of [...w.customers,...w.pedestrians,...w.police]){const a=setup(p);if(p.requires&&!s[p.requires])continue;const isOfficer=w.police.includes(p);p.walk=false;
   if(injured(p)){
    const elapsed=s.sim-a.fallAt;
    if(elapsed<.65){a.mode='falling';move(w,p,a.vx*dt,a.vz*dt,s);a.vx*=Math.exp(-dt*3);a.vz*=Math.exp(-dt*3);}
    else if(s.sim<a.until)a.mode='down';else if(s.sim<a.until+1.3)a.mode='rising';else {a.mode='shaken';a.until=s.sim+9;a.next=a.until;a.health=Math.max(40,a.health);a.speech='Taking a moment';a.goal=null;}
    continue;
   }
   if(a.mode==='shaken'&&s.sim<a.until){a.health=Math.min(100,a.health+dt*3);continue;}
   if(isOfficer){a.mode='idle';continue;}
   const distance=Math.hypot(p.x-s.player.x,p.z-s.player.z);
   if(locked===p.id){a.mode='talking';p.ry+=angle(p.ry,Math.atan2(s.player.x-p.x,s.player.z-p.z))*Math.min(1,dt*5);continue;}
   let danger=cars.find(c=>Math.hypot(c.vx||0,c.vz||0)>1.5&&Math.hypot(c.x-p.x,c.z-p.z)<8&&((p.x-c.x)*(c.vx||0)+(p.z-c.z)*(c.vz||0))>0&&visibleLine(w,p,c,s));
   if(danger||horn&&distance<14){a.mode='startled';a.alert=s.sim+1.2;a.speech='Watch the road!';if(danger&&!p.stationary){const vx=danger.vx,vz=danger.vz,len=Math.hypot(vx,vz)||1,side=((p.x-danger.x)*(-vz)+(p.z-danger.z)*vx)>=0?1:-1;move(w,p,-vz/len*side*dt*2.0,vx/len*side*dt*2.0,s);}continue;}
   if(a.alert>s.sim){a.mode='startled';continue;}
   if(distance<3.8&&!s.rides.riding&&visibleLine(w,p,s.player,s)){a.mode='greeting';a.speech='Hello, neighbour';p.ry+=angle(p.ry,Math.atan2(s.player.x-p.x,s.player.z-p.z))*Math.min(1,dt*5);continue;}
   if(p.stationary||coop&&p.type==='customer'){a.mode=(Math.floor((s.sim+a.seed%20)/7)%3===0?'phone':'idle');a.speech='';continue;}
   if(a.goal){const dx=a.goal[0]-p.x,dz=a.goal[1]-p.z,d=Math.hypot(dx,dz);if(d<.35){a.goal=null;a.next=s.sim+2+a.seed%6;a.mode='idle';if(p.path)p.index=(p.index+1)%p.path.length;}else{a.mode='walking';p.walk=true;p.ry+=angle(p.ry,Math.atan2(dx,dz))*Math.min(1,dt*6);const speed=p.speed||.82;const prev={x:p.x,z:p.z};move(w,p,dx/d*dt*speed,dz/d*dt*speed,s);if(Math.hypot(prev.x-p.x,prev.z-p.z)<dt*.08){a.goal=null;a.next=s.sim+1;if(p.path)p.index=(p.index+1)%p.path.length;}}}
   else if(s.sim>=a.next){a.cycle++;if(p.path){a.goal=p.path[p.index||0];}else {for(let i=0;i<6;i++){const t=(a.seed%36+i*6+a.cycle*8)*.1745,len=1.8+(a.cycle%3)*.8,x=a.homeX+Math.sin(t)*len,z=a.homeZ+Math.cos(t)*len;if(w.isFree(x,z,s,.4)&&!onRoad(w,x,z)&&visibleLine(w,p,{x,z},s)){a.goal=[x,z];break;}}}a.next=s.sim+5;}
   else{a.mode=['idle','phone','chat'][Math.floor((s.sim+a.seed%20)/6)%3];a.speech=a.mode==='chat'?'Enjoying the neighbourhood':'';}
   a.health=Math.min(100,a.health+dt*.8);
  }
 }
 function help(p,s,kit=false){const a=setup(p);if(!injured(p)||a.helped)return false;if(kit){if(s.medkits<1)return false;s.medkits--;a.health=Math.min(100,a.health+45);}a.helped=true;a.until=Math.min(a.until,s.sim+.3);a.fallAt=Math.min(a.fallAt,s.sim-.7);a.speech='Thank you for checking on me';return true;}
 // Matrix composition is local to articulation and supports old engine matrices.
 function multiply(a,b){const out=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let v=0;for(let k=0;k<4;k++)v+=a[k*4+r]*b[c*4+k];out[c*4+r]=v;}return out;}
 function matrix(x=0,y=0,z=0,yaw=0,rx=0,rz=0){const M=root.MZ.M,c=Math.cos(rx),s=Math.sin(rx),cz=Math.cos(rz),sz=Math.sin(rz),X=new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1]),Z=new Float32Array([cz,sz,0,0,-sz,cz,0,0,0,0,1,0,0,0,0,1]);return multiply(M.model(x,y,z,yaw),multiply(X,Z));}
 function draw(r,w,p,t){if(r.cameraPosition&&Math.hypot(p.x-r.cameraPosition.x,p.z-r.cameraPosition.z)>(r.visualQuality===0?77:140))return;const a=setup(p),m=p.model,M=root.MZ.M;let rx=0,base=.16+(p.height||0),ry=p.ry||0;
  if(injured(p)){const now=w.lifeSim??t,fall=clamp((now-a.fallAt)/.55,0,1),rise=clamp((now-a.until)/1.3,0,1);rx=fall*(1-rise)*1.53;ry=a.fallYaw;base=.18;}
  const walk=p.walk&&!injured(p),stride=Math.sin(t*7.2+(p.phase||0)),bob=walk?Math.abs(stride)*.025:Math.sin(t*1.4+a.phase)*.007;
  const rootM=matrix(p.x,base+bob,p.z,ry,rx),body=matrix(0,0,0,0,0,a.mode==='shaken'?.05:walk?stride*.012:0);r.draw(m.body,multiply(rootM,body));
  for(const side of [-1,1]){const swing=walk?stride*side*.47:0;const leg=matrix(side*.15,.76,0,0,swing);r.draw(m.leg,multiply(rootM,multiply(leg,M.model(0,-.76,0))));
   if(m.arms){let arm=walk?-swing*.72:.045;let roll=side*.025;if(a.mode==='phone'&&side===1){arm=-1.12;roll=-.18;}if(['greeting','talking','chat'].includes(a.mode)&&side===1){arm=-.75;roll=-.55+Math.sin(t*4)*.12;}if(a.mode==='startled'){arm=-1.7;roll=side*.3;}if(injured(p))arm=-.35;
    r.draw(m.arms[side===-1?0:1],multiply(rootM,matrix(side*.30,1.20,0,0,arm,roll)));
   }
  }
  if(m.phone&&a.mode==='phone')r.draw(m.phone,multiply(rootM,matrix(.33,1.11,.35,0,-.3)));
 }
 root.MZPeople={setup,reset,injured,hit,sweep,collisions,tick,help,multiply,matrix,draw,onRoad,visibleLine};
})(typeof window==='undefined'?globalThis:window);
