'use strict';
/** Divide the existing original car meshes into removable panels, preserving normals.
 * This is an authored modular presentation, NOT a deforming collision structure.
 */
(function(root){
 function partition(g,r){const G=MZ.Geometry,w=r.halfWidth,l=r.halfLength,long=['van','minibus'].includes(r.body),pickup=r.body==='pickup';const front=long?-l+.20:pickup?-1.46:['coupe','electric','classic'].includes(r.body)?-1.04:-1.20,rear=pickup?.5:long?l-.20:1.30;const parts=[];
  for(const p of g.parts){if(p.role==='wheel'){parts.push(p);continue;}const groups=new Map();for(let i=0;i<p.geo.v.length;i+=27){const v=p.geo.v,x=(v[i]+v[i+9]+v[i+18])/3,y=(v[i+1]+v[i+10]+v[i+19])/3,z=(v[i+2]+v[i+11]+v[i+20])/3,ny=(v[i+4]+v[i+13]+v[i+22])/3;let slot='';if(z<-l+.18&&y<.71)slot='frontBumper';else if(z>l-.18&&y<.71)slot='rearBumper';else if(y>.85&&ny>.3&&z<front+.05)slot='hood';else if((y>.85&&ny>.3&&z>rear+.08)||(pickup&&z>l-.10&&y>.9))slot='trunk';else if(Math.abs(x)>w*.68&&z>front+.05&&z<rear-.05&&y>.55)slot=x<0?'leftDoor':'rightDoor';if(!groups.has(slot))groups.set(slot,new G());groups.get(slot).v.push(...v.slice(i,i+27));}for(const [slot,geo]of groups)parts.push({...p,geo,slot});}
  const frame=new G();frame.box(0,.48,0,w*1.45,.12,l*1.72,0x26383d);for(const x of [-w*.45,w*.45]){frame.box(x,.83,.20,.48,.35,.65,0x35474a);frame.box(x,1.12,.48,.48,.60,.15,0x35474a);}frame.box(0,.93,front+.20,w*1.60,.18,.25,0x2b3e44);frame.beam([-w*.4,.65,-l+.3],[-w*.4,.65,l-.3],.06,0x54636b,6);frame.beam([w*.4,.65,-l+.3],[w*.4,.65,l-.3],.06,0x54636b,6);
  const block=new G(),zz=(-l+front)/2;block.box(0,.73,zz,w*.96,.31,.66,0x748489);block.box(0,.93,zz,w*.8,.1,.55,0xbc6c59);for(let i=0;i<4;i++){block.cylinder(-w*.32+i*w*.21,.98,zz,.045,.045,.08,0x9facaa,7);block.beam([-w*.4+i*w*.26,.75,zz+.25],[-w*.4+i*w*.26,.76,zz+.5],.027,0x606d71,7);}
  parts.push({geo:frame,role:'chassis',finish:0},{geo:block,role:'engine',slot:'engine',finish:1.2});g.parts=parts;return g;
 }
 root.MZNightGarage={partition};
})(window);
