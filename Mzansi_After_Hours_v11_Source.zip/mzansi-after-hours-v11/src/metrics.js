'use strict';
/** Local counters always stay in this browser. Hosted anonymous counts are opt-in.
 * No third-party analytics, IP history, fingerprinting or real names. */
(function(root){
 const KEY='mzansi_local_activity_v6';let local={sessions:0,playSeconds:0,lastStarted:0},store=null;
 try{store=localStorage;const x=JSON.parse(store.getItem(KEY)||'null');if(x&&Number.isFinite(x.sessions)&&Number.isFinite(x.playSeconds))local={sessions:Math.max(0,Math.floor(x.sessions)),playSeconds:Math.max(0,x.playSeconds),lastStarted:Number(x.lastStarted)||0};}catch(_){}
 let config={enabled:false},begun=false,sent=false,sessionId='',profileId='',device='desktop',getState=()=>null,pending=false,elapsed=0,activeTotal=0,reportedSeconds=0,lastPing=0,serverError='';
 const saveLocal=()=>{try{store?.setItem(KEY,JSON.stringify(local));}catch(_){}};
 async function discover(){if(!['http:','https:'].includes(location.protocol))return;try{const r=await fetch('api/info',{cache:'no-store',credentials:'same-origin'});if(r.ok)config=await r.json();}catch(_){}}
 async function event(type){const s=getState();if(!config.enabled||!s?.settings.analyticsConsent||s.dev?.unlimitedMoney||s.dev?.godMode||s.dev?.noPolice||pending)return;
  pending=true;try{const r=await fetch('api/event',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({type,sessionId,visitorId:profileId,device,mode:s.mode,seconds:Math.floor(reportedSeconds)}),keepalive:type==='end'});if(r.ok){sent=true;serverError='';}else serverError='Server rejected the anonymous activity update.';}catch(_){serverError='The shared statistics server is unreachable.';}finally{pending=false;}
 }
 function begin(s,profile,touch){getState=s;device=touch?'touch':'desktop';if(!begun){begun=true;local.sessions++;local.lastStarted=Date.now();sessionId=(root.crypto?.randomUUID?.()||('session_'+Date.now()+'_'+Math.random().toString(36).slice(2))).replace(/[^a-zA-Z0-9_-]/g,'');profileId=profile;saveLocal();}event(sent?'pulse':'start');}
 function tick(dt){if(!begun||!Number.isFinite(dt)||dt<=0)return;local.playSeconds+=dt;activeTotal+=dt;const s=getState();if(s?.settings.analyticsConsent&&!s.dev?.unlimitedMoney&&!s.dev?.godMode&&!s.dev?.noPolice)reportedSeconds+=dt;elapsed+=dt;if(elapsed>=15){elapsed=0;saveLocal();if(Date.now()-lastPing>10000){lastPing=Date.now();event(sent?'pulse':'start');}}}
 function consentChanged(){if(getState()?.settings.analyticsConsent)event(sent?'pulse':'start');}
 async function dashboard(token){if(!config.enabled)throw new Error('Shared statistics are not enabled on this server. Local activity is shown below.');const r=await fetch('api/admin/stats',{headers:{Authorization:'Bearer '+token},cache:'no-store'});if(!r.ok)throw new Error(r.status===401?'Incorrect server admin token. This is separate from the gameplay cheat code.':'Could not load server statistics.');return r.json();}
 root.addEventListener('pagehide',()=>{saveLocal();event('end');});root.addEventListener('visibilitychange',()=>{if(document.hidden)saveLocal();});
 root.MZMetrics={discover,begin,tick,consentChanged,dashboard,saveLocal,get local(){return {...local};},get enabled(){return config.enabled===true;},get error(){return serverError;}};
 discover();
})(window);
