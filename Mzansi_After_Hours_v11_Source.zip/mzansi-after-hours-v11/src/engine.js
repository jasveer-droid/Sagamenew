'use strict';
/* Original compact WebGL renderer. No third-party code or external assets. */
(() => {
    const rad = Math.PI / 180;
    const color = v => Array.isArray(v) ? v : [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
    const V = { sub: (a, b) => a.map((v, i) => v - b[i]), cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], norm: a => { let l = Math.hypot(...a) || 1; return a.map(v => v / l); }, dot: (a, b) => a.reduce((n, v, i) => n + v * b[i], 0) };
    const M = {
        perspective(fov, aspect, near, far) { let f = 1 / Math.tan(fov / 2), nf = 1 / (near - far); return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]); },
        lookAt(eye, at, up=[0,1,0]) { let z = V.norm(V.sub(eye, at)), x = V.norm(V.cross(up, z)), y = V.cross(z, x); return new Float32Array([x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -V.dot(x, eye), -V.dot(y, eye), -V.dot(z, eye), 1]); },
        model(x = 0, y = 0, z = 0, r = 0, s = 1) { let c = Math.cos(r) * s, n = Math.sin(r) * s; return new Float32Array([c, 0, -n, 0, 0, s, 0, 0, n, 0, c, 0, x, y, z, 1]); },
        point(m, p) { let [x, y, z] = p; return [m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14], m[3] * x + m[7] * y + m[11] * z + m[15]]; }
    };
    class Geometry {
        constructor() { this.v = []; }
        triangle(a, b, c, col, n) { let rgb = color(col); n = n || V.norm(V.cross(V.sub(b, a), V.sub(c, a))); for (let p of [a, b, c])
            this.v.push(...p, ...n, ...rgb); return this; }
        quad(a, b, c, d, col, n) { this.triangle(a, b, c, col, n); this.triangle(a, c, d, col, n); return this; }
        box(x, y, z, w, h, d, col, r = 0) { let C = Math.cos(r), S = Math.sin(r); const p = (a, b, c) => [x + a * C + c * S, y + b, z - a * S + c * C]; w /= 2; h /= 2; d /= 2; let f = [[[-w, -h, d], [w, -h, d], [w, h, d], [-w, h, d]], [[w, -h, -d], [-w, -h, -d], [-w, h, -d], [w, h, -d]], [[-w, -h, -d], [-w, -h, d], [-w, h, d], [-w, h, -d]], [[w, -h, d], [w, -h, -d], [w, h, -d], [w, h, d]], [[-w, h, d], [w, h, d], [w, h, -d], [-w, h, -d]], [[-w, -h, -d], [w, -h, -d], [w, -h, d], [-w, -h, d]]]; for (let a of f)
            this.quad(...a.map(q => p(...q)), col); return this; }
        cylinder(x, y, z, rt, rb, h, col, n = 9) { let a0 = y - h / 2, a1 = y + h / 2; for (let i = 0; i < n; i++) {
            let a = i * 2 * Math.PI / n, b = (i + 1) * 2 * Math.PI / n;
            let p = [x + Math.cos(a) * rb, a0, z + Math.sin(a) * rb], q = [x + Math.cos(b) * rb, a0, z + Math.sin(b) * rb], u = [x + Math.cos(b) * rt, a1, z + Math.sin(b) * rt], v = [x + Math.cos(a) * rt, a1, z + Math.sin(a) * rt];
            this.quad(q, p, v, u, col);
            if (rt)
                this.triangle([x, a1, z], v, u, col, [0, 1, 0]);
            if (rb)
                this.triangle([x, a0, z], q, p, col, [0, -1, 0]);
        } return this; }
        sphere(x, y, z, rx, ry, rz, col, lat = 5, lon = 8) { let p = (a, b) => [x + rx * Math.sin(a) * Math.cos(b), y + ry * Math.cos(a), z + rz * Math.sin(a) * Math.sin(b)]; for (let i = 0; i < lat; i++)
            for (let j = 0; j < lon; j++)
                this.quad(p(i * Math.PI / lat, j * 2 * Math.PI / lon), p(i * Math.PI / lat, (j + 1) * 2 * Math.PI / lon), p((i + 1) * Math.PI / lat, (j + 1) * 2 * Math.PI / lon), p((i + 1) * Math.PI / lat, j * 2 * Math.PI / lon), col); return this; }
        roof(x, y, z, w, d, h, col) { let a = [x - w / 2, y, z - d / 2], b = [x + w / 2, y, z - d / 2], c = [x + w / 2, y, z + d / 2], e = [x - w / 2, y, z + d / 2], m = [x, y + h, z - d / 2], n = [x, y + h, z + d / 2]; this.quad(a, m, n, e, col); this.quad(m, b, c, n, col); this.triangle(a, b, m, col); this.triangle(e, n, c, col); return this; }
    }
    function compile(gl, vs, fs) { const sh = (type, s) => { let a = gl.createShader(type); gl.shaderSource(a, s); gl.compileShader(a); if (!gl.getShaderParameter(a, gl.COMPILE_STATUS))
        throw new Error(gl.getShaderInfoLog(a)); return a; }; let p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS))
        throw new Error(gl.getProgramInfoLog(p)); return p; }
    class Renderer {
        constructor(canvas) {
            this.canvas = canvas;
            let gl = this.gl = canvas.getContext('webgl', { alpha: true, antialias: true, powerPreference: 'high-performance' }) || canvas.getContext('experimental-webgl');
            if (!gl)
                throw new Error('WebGL is not available. Enable graphics acceleration in your browser and reopen this file.');
            this.cp = compile(gl, `attribute vec3 aPos;attribute vec3 aNorm;attribute vec3 aCol;uniform mat4 uP,uV,uM;uniform vec3 uSun;uniform float uAmbient,uBright;varying vec3 vCol;varying float vDist;void main(){vec4 pos=uM*vec4(aPos,1.);vec4 view=uV*pos;gl_Position=uP*view;vec3 n=normalize(mat3(uM)*aNorm);float light=uAmbient+(1.-uAmbient)*max(dot(n,uSun),0.);vCol=aCol*light*uBright;vDist=length(view.xyz);}`, `precision mediump float;varying vec3 vCol;varying float vDist;uniform vec3 uFog;void main(){float fog=smoothstep(48.,175.,vDist);gl_FragColor=vec4(mix(vCol,uFog,fog*.95),1.);}`);
            this.tp = compile(gl, `attribute vec3 aPos;attribute vec2 aUV;uniform mat4 uP,uV,uM;varying vec2 vUV;varying float vDist;void main(){vec4 v=uV*uM*vec4(aPos,1.);gl_Position=uP*v;vDist=length(v.xyz);vUV=aUV;}`, `precision mediump float;varying vec2 vUV;varying float vDist;uniform sampler2D uTex;uniform vec3 uFog;uniform float uBright;void main(){vec4 c=texture2D(uTex,vUV);if(c.a<.02)discard;gl_FragColor=vec4(mix(c.rgb*uBright,uFog,smoothstep(48.,175.,vDist)*.9),c.a);}`);
            this.c = this.locations(this.cp, ['aPos', 'aNorm', 'aCol'], ['uP', 'uV', 'uM', 'uSun', 'uAmbient', 'uFog', 'uBright']);
            this.t = this.locations(this.tp, ['aPos', 'aUV'], ['uP', 'uV', 'uM', 'uFog', 'uTex', 'uBright']);
            this.fog = [.72, .63, .58];
            this.sun = V.norm([-.6, .9, .4]);
            this.ambient = .63;
            this.daylight = 1;
            this.brightness = 1;
            this.pixel = 1.5;
            this.signs = [];
            gl.enable(gl.DEPTH_TEST);
            gl.depthFunc(gl.LEQUAL);
            gl.enable(gl.BLEND);
            gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
            gl.clearColor(0, 0, 0, 0);
            this.resize();
        }
        locations(program, attrs, uniforms) { let g = this.gl, o = {}; for (let a of attrs)
            o[a] = g.getAttribLocation(program, a); for (let a of uniforms)
            o[a] = g.getUniformLocation(program, a); return o; }
        resize() { let ratio = Math.min(window.devicePixelRatio || 1, this.pixel); const view = window.MZLayout?.viewport || {width: innerWidth, height: innerHeight}; this.screenWidth = view.width; this.screenHeight = view.height; let w = Math.max(1, Math.round(view.width * ratio)), h = Math.max(1, Math.round(view.height * ratio)); if (this.canvas.width !== w || this.canvas.height !== h) {
            this.canvas.width = w;
            this.canvas.height = h;
        } this.gl.viewport(0, 0, w, h); this.projection = M.perspective(70 * rad, w / h, .06, 260); }
        mesh(geo) {
            const g=this.gl,buffer=g.createBuffer(),source=new Float32Array(geo.v||[]);g.bindBuffer(g.ARRAY_BUFFER,buffer);g.bufferData(g.ARRAY_BUFFER,source,g.STATIC_DRAW);
            const out={buffer,count:source.length/9,finish:geo.finish||0};
            if(geo.parts){out.carId=geo.carId;out.parts=geo.parts.map(p=>{const mesh=this.mesh(p.geo);mesh.finish=p.finish||0;if(p.deform)mesh.source=new Float32Array(p.geo.v);return {...p,geo:undefined,mesh,local:M.model(p.x||0,p.y||0,p.z||0)};});}
            return out;
        }
        begin(cam) {this.cameraPosition=cam; this.resize(); let f = [Math.sin(cam.yaw) * Math.cos(cam.pitch), Math.sin(cam.pitch), -Math.cos(cam.yaw) * Math.cos(cam.pitch)]; this.view = M.lookAt([cam.x, cam.y, cam.z], [cam.x + f[0], cam.y + f[1], cam.z + f[2]], [Math.cos(cam.yaw)*Math.sin(cam.roll||0),Math.cos(cam.roll||0),Math.sin(cam.yaw)*Math.sin(cam.roll||0)]); this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT); this.drawSky?.(cam); let g = this.gl, c = this.c; g.useProgram(this.cp); g.uniformMatrix4fv(c.uP, false, this.projection); g.uniformMatrix4fv(c.uV, false, this.view); g.uniform3fv(c.uSun, this.sun); g.uniform1f(c.uAmbient, this.ambient); g.uniform1f(c.uBright, this.brightness); g.uniform3fv(c.uFog, this.fog); this.bindVisuals?.(); }
        draw(mesh, model) {
            if(!mesh)return;
            if(mesh.parts){for(const p of mesh.parts)this.draw(p.mesh,M.multiply(model||M.model(),p.local));return;}
            const g=this.gl,c=this.c;g.bindBuffer(g.ARRAY_BUFFER,mesh.buffer);
            for(const [a,n,offset]of [[c.aPos,3,0],[c.aNorm,3,12],[c.aCol,3,24]]){g.enableVertexAttribArray(a);g.vertexAttribPointer(a,n,g.FLOAT,false,36,offset);}
            g.uniformMatrix4fv(c.uM,false,model||M.model());if(c.uFinish)g.uniform1f(c.uFinish,mesh.finish||0);
            if(mesh.finish<0)g.depthMask(false);g.drawArrays(g.TRIANGLES,0,mesh.count);if(mesh.finish<0)g.depthMask(true);
        }
        makeSign(text, sub, w = 6, h = 1.4, bg = '#193c40', fg = '#f5e8c7', extra = {}) { let c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, Math.round(1024 * h / w)); let H = c.height, x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, 1024, H); x.strokeStyle = fg + '55'; x.lineWidth = 3; x.strokeRect(10, 6, 1004, H - 12); x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = fg; let size = Math.round(H * (sub ? .46 : .6)); x.font = '900 ' + size + 'px Arial'; while (x.measureText(text).width > 940) {
            size -= 2;
            x.font = '900 ' + size + 'px Arial';
        } x.fillText(text, 512, sub ? H * .38 : H * .52); if (sub) {
            x.fillStyle = extra.subcolor || fg;
            x.globalAlpha = .85;
            x.font = '600 ' + Math.round(H * .155) + 'px Arial';
            x.fillText(sub, 512, H * .79);
            x.globalAlpha = 1;
        } return this.textureQuad(c, w, h); }
        textureQuad(canvas, w, h) { let g = this.gl, tex = g.createTexture(); g.bindTexture(g.TEXTURE_2D, tex); g.pixelStorei(g.UNPACK_FLIP_Y_WEBGL, true); g.texImage2D(g.TEXTURE_2D, 0, g.RGBA, g.RGBA, g.UNSIGNED_BYTE, canvas); g.texParameteri(g.TEXTURE_2D, g.TEXTURE_MIN_FILTER, g.LINEAR); g.texParameteri(g.TEXTURE_2D, g.TEXTURE_MAG_FILTER, g.LINEAR); g.texParameteri(g.TEXTURE_2D, g.TEXTURE_WRAP_S, g.CLAMP_TO_EDGE); g.texParameteri(g.TEXTURE_2D, g.TEXTURE_WRAP_T, g.CLAMP_TO_EDGE); let v = [-w / 2, -h / 2, 0, 0, 0, w / 2, -h / 2, 0, 1, 0, w / 2, h / 2, 0, 1, 1, -w / 2, -h / 2, 0, 0, 0, w / 2, h / 2, 0, 1, 1, -w / 2, h / 2, 0, 0, 1], b = g.createBuffer(); g.bindBuffer(g.ARRAY_BUFFER, b); g.bufferData(g.ARRAY_BUFFER, new Float32Array(v), g.STATIC_DRAW); return { texture: tex, buffer: b }; }
        drawSigns(signs) { let g = this.gl, t = this.t; g.disableVertexAttribArray(this.c.aCol); g.useProgram(this.tp); g.uniformMatrix4fv(t.uP, false, this.projection); g.uniformMatrix4fv(t.uV, false, this.view); g.uniform3fv(t.uFog, this.fog); g.uniform1i(t.uTex, 0); g.activeTexture(g.TEXTURE0); for (let s of signs) {
            g.bindBuffer(g.ARRAY_BUFFER, s.quad.buffer);
            g.enableVertexAttribArray(t.aPos);
            g.vertexAttribPointer(t.aPos, 3, g.FLOAT, false, 20, 0);
            g.enableVertexAttribArray(t.aUV);
            g.vertexAttribPointer(t.aUV, 2, g.FLOAT, false, 20, 12);
            g.bindTexture(g.TEXTURE_2D, s.quad.texture);
            g.uniformMatrix4fv(t.uM, false, M.model(s.x, s.y, s.z, s.ry || 0));
            g.uniform1f(t.uBright, s.lit ? 1 : Math.max(.64, this.daylight));
            g.drawArrays(g.TRIANGLES, 0, 6);
        } }
        project(x, y, z) { let v = M.point(this.view, [x, y, z]), p = M.point(this.projection, v); if (p[3] <= 0)
            return null; return { x: (p[0] / p[3] * .5 + .5) * this.screenWidth, y: (1 - (p[1] / p[3] * .5 + .5)) * this.screenHeight, z: p[2] / p[3] }; }
    }
    window.MZ = { Geometry, Renderer, M, V, color, compile };
})();
