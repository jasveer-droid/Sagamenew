'use strict';
/** Arcade patrol AI: sight/witness -> warning -> pursuit -> last-seen search.
 * Small bounded A* routes use the same collision geometry as the player.
 */
(function(root){
 function setup(p){if(!p.ai)p.ai={mode:'patrol',until:0,lastSeen:-1e6,last:{x:p.x,z:p.z},route:[],routeAt:0,still:0};return p.ai;}
 function reset(world){for(const p of world.police){if(root.MZPeople?.injured(p))continue;delete p.ai;p.chase=false;p.walk=false;}}
 function active(s){return !s.dev?.noPolice && (s.mode==='free'||s.story.chapter>10) && s.sim>=s.caughtUntil;}
 function witness(world,s){if(!active(s))return 0;let count=0;for(const p of world.police){if(root.MZPeople?.injured(p))continue;if(MZLife.canSee(world,p,s.player,s,20,true)){const a=setup(p);a.last={x:s.player.x,z:s.player.z};a.lastSeen=s.sim;a.mode=s.heat>=70?'chase':'warning';a.until=s.sim+7;a.still=0;a.routeAt=0;count++;}}return count;}
 function clearPath(world,s,a,b){const n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.z-a.z)/.45));for(let i=1;i<=n;i++)if(!world.isFree(a.x+(b.x-a.x)*i/n,a.z+(b.z-a.z)*i/n,s,.27))return false;return true;}
 function route(world,s,start,goal){
  if(clearPath(world,s,start,goal))return [{x:goal.x,z:goal.z}];
  const unit=1.4,sx=Math.round(start.x/unit),sz=Math.round(start.z/unit),gx=Math.round(goal.x/unit),gz=Math.round(goal.z/unit),key=(x,z)=>x+','+z;
  const first={x:sx,z:sz,g:0,f:Math.hypot(gx-sx,gz-sz),parent:null};let open=[first],best=new Map([[key(sx,sz),0]]),last=first;
  for(let count=0;open.length&&count<950;count++){
   let idx=0;for(let i=1;i<open.length;i++)if(open[i].f<open[idx].f)idx=i;
   const node=open.splice(idx,1)[0];if(Math.hypot(node.x-gx,node.z-gz)<Math.hypot(last.x-gx,last.z-gz))last=node;
   if(Math.hypot(node.x-gx,node.z-gz)<1.6&&clearPath(world,s,{x:node.x*unit,z:node.z*unit},goal)){last=node;break;}
   for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]]){
    const x=node.x+dx,z=node.z+dz,k=key(x,z),g=node.g+Math.hypot(dx,dz);if(g>64||(best.has(k)&&best.get(k)<=g))continue;
    if(!clearPath(world,s,{x:node.x*unit,z:node.z*unit},{x:x*unit,z:z*unit}))continue;
    best.set(k,g);open.push({x,z,g,f:g+Math.hypot(gx-x,gz-z),parent:node});
   }
  }
  const path=[];for(let n=last;n&&n.parent;n=n.parent)path.push({x:n.x*unit,z:n.z*unit});path.reverse();
  if(path.length&&clearPath(world,s,path[path.length-1],goal))path.push({x:goal.x,z:goal.z});return path;
 }
 function move(world,s,p,goal,speed,dt){const a=setup(p);if(s.sim>=a.routeAt||!a.route.length){a.route=route(world,s,p,goal);a.routeAt=s.sim+1.15;}
  while(a.route.length&&Math.hypot(a.route[0].x-p.x,a.route[0].z-p.z)<.4)a.route.shift();
  const target=a.route[0];p.walk=false;if(!target)return;const dx=target.x-p.x,dz=target.z-p.z,d=Math.hypot(dx,dz);if(d<.01)return;
  p.walk=true;p.ry=Math.atan2(dx,dz);world.move(p,dx/d*Math.min(d,speed*dt),dz/d*Math.min(d,speed*dt),s,.26);
 }
 function tick(world,s,dt,options={}){
  let event=null;for(const p of world.police){if(root.MZPeople?.injured(p))continue;const a=setup(p);p.chase=false;
   if(!active(s)){a.mode='patrol';a.still=0;}
   const dist=Math.hypot(p.x-s.player.x,p.z-s.player.z),seen=!options.blocked&&MZLife.canSee(world,p,s.player,s,32,a.mode==='patrol');
   if(active(s)&&a.mode==='patrol'&&s.heat>=60&&seen){a.mode='warning';a.until=s.sim+6;a.still=0;a.last={x:s.player.x,z:s.player.z};a.lastSeen=s.sim;event={type:'warning',officer:p};}
   if(a.mode==='warning'){
    if(seen){a.last={x:s.player.x,z:s.player.z};a.lastSeen=s.sim;}
    if(dist>3.1)move(world,s,p,a.last,3.3,dt);else p.walk=false;
    if(dist<6&&seen&&(options.speed||0)<.65){a.still+=dt;if(a.still>=1.6){a.mode='stop';event={type:'stop',officer:p,arrest:false};}}
    else a.still=0;
    if(a.mode==='warning'&&(s.sim>a.until||Math.hypot(s.player.x-a.last.x,s.player.z-a.last.z)>9||((options.speed||0)>5.5&&dist>7))){a.mode='chase';a.lastSeen=s.sim;a.routeAt=0;s.heat=Math.max(65,s.heat);event={type:'chase',officer:p};}
   }
   if(a.mode==='chase'){
    p.chase=true;if(seen){a.last={x:s.player.x,z:s.player.z};a.lastSeen=s.sim;}
    move(world,s,p,a.last,6.1,dt);
    if(seen&&dist<1.45&&!options.blocked){a.mode='stop';event={type:'stop',officer:p,arrest:true};}
    else if(s.sim-a.lastSeen>2.8){a.mode='search';a.until=s.sim+16;a.routeAt=0;event={type:'search',officer:p};}
   }
   if(a.mode==='search'){
    p.chase=false;if(seen&&s.heat>=25){a.mode='chase';a.lastSeen=s.sim;a.routeAt=0;event={type:'chase',officer:p};}
    else if(s.sim>a.until){a.mode='patrol';a.routeAt=0;s.heat=Math.max(0,s.heat-18);event={type:'clear',officer:p};}
    else {move(world,s,p,a.last,3.5,dt);if(Math.hypot(p.x-a.last.x,p.z-a.last.z)<1){p.walk=false;p.ry+=dt*.9;}}
   }
   if(a.mode==='patrol'){
    const goal=p.path[p.index];if(goal){if(Math.hypot(p.x-goal[0],p.z-goal[1])<.6){p.index=(p.index+1)%p.path.length;a.routeAt=0;}move(world,s,p,{x:goal[0],z:goal[1]},p.speed||1.7,dt);}
   }
   if(a.mode==='stop')p.walk=false;
  }return event;
 }
 function status(world){const modes=world.police.filter(p=>!root.MZPeople?.injured(p)).map(p=>setup(p).mode);return ['stop','chase','warning','search'].find(m=>modes.includes(m))||'patrol';}
 root.MZPolice={setup,reset,active,witness,route,clearPath,tick,status};
})(typeof window==='undefined'?globalThis:window);
