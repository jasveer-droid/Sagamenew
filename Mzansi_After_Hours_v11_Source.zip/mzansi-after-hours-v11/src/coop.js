'use strict';
/** Small, dependency-free co-op client. Shared economy is authoritative on the
 * local/hosted server; isolated single-player saves are never overwritten. */
(function(root){
 const KEY='mzansi_coop_session_v7';
 root.MZCoop={create(callbacks){
  let connecting=false;let queue=[];let session=null,data=null,inflight=false,failures=0,lastError='',stopped=false;const clone=o=>JSON.parse(JSON.stringify(o));
  function stored(){try{return JSON.parse(localStorage.getItem(KEY)||'null');}catch(_){return null;}}
  function remember(){if(!session)return;try{localStorage.setItem(KEY,JSON.stringify({...session,personal:callbacks.personal()}));}catch(_){lastError='Browser storage is unavailable. Keep this session open; co-op rejoin cannot be remembered.';}}
  async function request(endpoint,payload){const c=new AbortController(),timer=setTimeout(()=>c.abort(),7000);try{const response=await fetch('/api/coop/'+endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:c.signal,cache:'no-store'});const result=await response.json();if(!response.ok||result.error)throw new Error(result.error||'The room server did not accept the request.');return result;}catch(e){throw new Error(e.name==='AbortError'?'Connection timed out. The pending action will be retried safely.':e.message);}finally{clearTimeout(timer);}}
  function apply(result){data=result;failures=0;lastError='';callbacks.snapshot(result);}
  async function attach(result,credentials){session={code:result.code,token:credentials.token||result.token,seq:credentials.seq??result.seq,pending:credentials.pending||null};data=result;stopped=false;callbacks.enter(result,credentials.personal||null);apply(result);remember();return result;}
  async function connect(type,form){
   if(connecting)throw new Error('A connection is already in progress.');
   if(session)throw new Error('Leave the current room before joining another.');
   connecting=true;try{if(type==='resume'){const s=stored();if(!s)throw new Error('No remembered co-op session on this browser.');const r=await request('pulse',{code:s.code,token:s.token});await attach(r,s);if(r.unfinishedMeal&&!s.pending)queue.push({type:'refundMeal'});return r;}
   const r=await request(type,form);return await attach(r,{token:r.token});}finally{connecting=false;}
  }
  async function pump(){if(!session||inflight||stopped)return;if(!session.pending&&queue.length){session.pending={seq:session.seq+1,action:queue.shift(),pose:callbacks.pose()};remember();}inflight=true;try{
   const pending=session.pending,body={code:session.code,token:session.token,pose:pending?.pose||callbacks.pose()};
   const result=await request(pending?'action':'pulse',pending?{...body,seq:pending.seq,action:pending.action}:body);
   apply(result);
   if(pending){const receipt=result.receipt;if(!receipt||receipt.seq!==pending.seq)throw new Error('The transaction receipt did not match.');session.seq=receipt.seq;session.pending=null;callbacks.receipt(receipt,pending.action);remember();}
   else {session.seq=result.seq;remember();}
  }catch(e){failures++;lastError=e.message;callbacks.connection(lastError,failures);}finally{inflight=false;}}
  function send(action){if(!session)return false;if(session.pending){callbacks.connection('Waiting for the previous action to be confirmed.',failures);return false;}if(failures>=3){callbacks.connection('Reconnecting. Wait before making another purchase or sale.',failures);return false;}
   session.pending={seq:session.seq+1,action:clone(action),pose:callbacks.pose()};remember();pump();return true;
  }
  async function leave(){if(!session)return;if(session.pending)throw new Error('Wait for the pending transaction before leaving. Reconnect if the server is offline.');stopped=true;while(inflight)await new Promise(r=>setTimeout(r,30));try{await request('leave',{code:session.code,token:session.token});}catch(e){stopped=false;throw e;}
   session=null;data=null;queue=[];try{localStorage.removeItem(KEY);}catch(_){}callbacks.leave();}
  const timer=setInterval(pump,200);
  root.addEventListener('pagehide',remember);
  return {connect,send,enqueue:a=>queue.push(clone(a)),leave,remember,pump,get active(){return !!session;},get data(){return data;},get pending(){return !!session?.pending;},get error(){return lastError;},get stalled(){return failures>=3;},get saved(){return stored();},get session(){return session;},dispose(){clearInterval(timer);}};
 }};
})(window);
