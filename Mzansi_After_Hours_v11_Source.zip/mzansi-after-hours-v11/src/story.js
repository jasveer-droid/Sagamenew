'use strict';
/** Story state is independent of rendering. Objectives can be completed out of order.
 * Advancing a chapter is the ONLY place that grants a chapter reward.
 * All products and rules are fictional. There are no real production recipes.
 */
(function (root) {
    const FLAGS = ['intro', 'metMentor', 'inventory', 'phone', 'trackedSipho',
        'glowMade', 'siphoDelivered', 'seedBought', 'pouchBought', 'mistMade',
        'mistSold', 'heatLesson'];
    const chapters = [
        { title: 'The key to number fourteen', speaker: 'Auntie Zanele', role: 'YOUR NEIGHBOUR & GUIDE', target: 'mentor',
            line: 'Your uncle left you the keys to The Yard. Not a fortune. Just a room, a bench, and a chance to start again. Sundown Bay is small, but there is room here for a story of your own.',
            lesson: 'I will show you around, one job at a time. Your first supplies are already paid for. Everything we grow and mix here is imaginary.',
            task: 'Read Zanele\'s welcome and begin your story.', done: s => s.story.flags.intro },
        { title: 'Find your feet', speaker: 'Auntie Zanele', role: 'LESSON / WALK & LOOK', target: 'mentor',
            line: 'Before we talk business, get comfortable. I am just inside the yard. There is no rush.',
            lesson: 'Walk a few steps and look around. Desktop: W A S D to move; mouse or drag to look. Mobile: left stick to walk; swipe the right side to look. The gold compass points toward your objective.',
            task: 'Walk 3 metres and turn your view. Follow the gold compass into The Yard.', done: s => s.story.walked >= 3 && s.story.looked >= .22 },
        { title: 'A familiar face', speaker: 'Auntie Zanele', role: 'LESSON / INTERACT', target: 'mentor',
            line: 'There you are! Come closer. The little prompt tells you when something can be used or someone can be spoken to.',
            lesson: 'Walk up to Zanele inside The Yard. Press E or tap USE. You interact in the same way with shops, customers and equipment.',
            task: 'Speak to Zanele inside The Yard.', done: s => s.story.flags.metMentor },
        { title: 'What you already have', speaker: 'Auntie Zanele', role: 'LESSON / YOUR BACKPACK', target: 'locker',
            line: 'Before you spend a rand, know what is in your bag. Supplies on one shelf, finished stock on the other. Do not mix them up.',
            lesson: 'Open Backpack with I or the bag button. Leaves and empty pouches are inputs. Finished packs are what customers buy. A normal batch makes three packs.',
            task: 'Open your backpack and check your free starter supplies.', done: s => s.story.flags.inventory },
        { title: 'Something from nothing', speaker: 'Auntie Zanele', role: 'LESSON / YOUR FIRST BATCH', target: 'bench',
            line: 'Your uncle always said: start simple, then get fancy. Original Glow is the place to begin.',
            lesson: 'At the mixing bench, choose Original Glow. Two fictional leaves and three pouches become three packs after 10 seconds. The timing game is optional: two hits in the mint zone add one bonus pack. A miss never ruins your batch.',
            task: 'Use the mixing bench and finish one Original Glow batch.', done: s => s.story.flags.glowMade },
        { title: 'A message from Sipho', speaker: 'Sipho', role: 'LESSON / PHONE & ORDERS', target: 'sipho',
            line: 'Zanele gave me your number. Two Original Glow packs, please. I am by the pavement near Sunset Square.',
            lesson: 'Open Phone, find Sipho\'s order and choose Track customer. Orders do not expire. Bring exactly the product and quantity listed. The gold compass and map show where to go.',
            task: 'Open Phone and track Sipho\'s order.', done: s => (s.story.flags.phone && s.story.flags.trackedSipho) || s.story.flags.siphoDelivered },
        { title: 'Your first promise', speaker: 'Sipho', role: 'LESSON / DELIVER & GET PAID', target: 'sipho', reward: 80,
            line: 'You showed up. That matters. Keep your promises around here, and people remember you.',
            lesson: 'Walk to Sipho, interact, and choose Deliver order. Two packs leave your bag, R170 enters your wallet, and reputation increases. Normal street offers are separate and may be declined; an agreed order has a fixed payment.',
            task: 'Bring 2 Original Glow packs to Sipho and deliver his order.', done: s => s.story.flags.siphoDelivered },
        { title: 'Keep tomorrow in mind', speaker: 'Nandi', role: 'LESSON / RESTOCK', target: 'supplier', reward: 30,
            line: 'You cannot sell an empty shelf, neighbour. Put a little of today\'s money into tomorrow\'s supplies.',
            lesson: 'At Sunset Spaza, buy one seed and a bundle of six pouches. A seed costs R25; the pouch bundle costs R15. Raw ingredients do not take up your finished-stock capacity.',
            task: 'Buy a Glowleaf seed and a pouch bundle from Nandi.', done: s => s.story.flags.seedBought && s.story.flags.pouchBought },
        { title: 'A little patience', speaker: 'Auntie Zanele', role: 'LESSON / GROW & HARVEST', target: 'grow', reward: 60,
            line: 'There is a rhythm to this place. Plant, make a round of deliveries, come home. Let the little things grow.',
            lesson: 'Use a planter: one imaginary seed grows six leaves in 35 seconds. Harvest when ready. Growth runs during street play and production screens, not while the game is paused. You can also sleep at your bed to finish plants and batches.',
            task: 'Plant a seed in your yard, then harvest the mature plant.', done: s => s.stats.harvested > 0 },
        { title: 'Your own signature', speaker: 'Lerato', role: 'LESSON / NEW BLENDS', target: 'bench', reward: 100,
            line: 'Original is good. But I like something a little different. Can you make Moon Mist?',
            lesson: 'Mix Moon Mist using the invented Moon dew ingredient. Deliver Lerato\'s order or sell Moon Mist to a customer. Reputation unlocks Sunburst at 6 and Night Prism at 16. Missing something? Nandi stocks it.',
            task: 'Make Moon Mist, then sell or deliver at least one pack.', done: s => s.story.flags.mistMade && s.story.flags.mistSold },
        { title: 'Know when to take a break', speaker: 'Auntie Zanele', role: 'LESSON / ATTENTION & REST', target: 'mentor',
            line: 'A busy night can get away from you. Look after yourself, and do not let the little meter surprise you.',
            lesson: 'In this fictional game, trading raises attention. A witnessed deal can trigger a warning; high attention can also draw a nearby officer. Stop to cooperate, or a pursuit may follow. Officers search your last-seen position when sight is lost. Getting caught costs up to R180 and a quarter of your finished stock. Rest at your bed to clear attention. Reading menus is safe; the world pauses. Open Help to revisit any rule.',
            task: 'Return to Zanele and ask about attention and taking breaks.', done: s => s.story.flags.heatLesson },
        { title: 'Two hands, two stations', speaker: 'Aadil', role: 'LESSON / EQUIPMENT', target: 'hardware',
            line: 'Busy bench? I can set up a second station. Buy once, use it every day.',
            lesson: 'Buy the second mixing station at Bay Hardware for R450. It lets two batches run together. Grow lights shorten growing time, solar equipment shortens mixing time, and a larger bag holds more finished packs.',
            task: 'Earn R450 and buy the second mixing station.', done: s => s.upgrades.mixer },
        { title: 'The next address', speaker: 'Auntie Zanele', role: 'LESSON / EXPAND', target: 'workshop',
            line: 'Look at you. The Yard used to feel enormous. Now there is a bigger door waiting across the avenue.',
            lesson: 'Buy Workshop 02 for R1600. The shutter opens, another mixing slot unlocks, and two extra planters become available back at home. Walk inside to find the dispatch desk.',
            task: 'Save R1600 and purchase Workshop 02.', done: s => s.workshop },
        { title: 'You cannot do it all alone', speaker: 'Kabelo', role: 'LESSON / YOUR FIRST TEAMMATE', target: 'runner',
            line: 'You make it, I deliver it. Keep some spare packs on the shelf and we will make a good team.',
            lesson: 'Hire Kabelo for R650. He sells up to two spare packs every 25 seconds, keeping 15% commission. Order reservation is ON by default: stock promised in phone orders is protected. Pause him or change reservations at the dispatch desk.',
            task: 'Hire your delivery runner at the workshop dispatch desk.', done: s => s.runner },
        { title: 'A name worth keeping', speaker: 'Auntie Zanele', role: 'FINAL CHAPTER / PUT IT ALL TOGETHER', target: 'bench',
            line: 'No one starts out knowing everything. You learned, kept going, and made this place your own. Now let us see that name above the door.',
            lesson: 'Reach R5000 in lifetime sales. This counts sales revenue, not your current cash or story rewards. Mix, grow, fill orders, sell directly, and keep spare stock for Kabelo. Your phone keeps the score.',
            task: 'Reach R5000 in lifetime sales with your workshop and runner.', done: s => s.totalRevenue >= 5000 }
    ];
    function initial() { return { chapter: 0, seen: -1, walked: 0, looked: 0, flags: Object.fromEntries(FLAGS.map(k => [k, false])), rewards: 0 }; }
    function validate(raw) {
        const s = initial();
        if (!raw || typeof raw !== 'object')
            return s;
        const n = (v, a, b) => Number.isFinite(v) ? Math.max(a, Math.min(b, v)) : a;
        s.chapter = Math.floor(n(raw.chapter, 0, chapters.length));
        s.seen = Math.floor(n(raw.seen, -1, chapters.length));
        s.walked = n(raw.walked, 0, 10);
        s.looked = n(raw.looked, 0, 10);
        s.rewards = Math.floor(n(raw.rewards, 0, 270));
        for (const k of FLAGS)
            s.flags[k] = raw.flags?.[k] === true;
        return s;
    }
    function advance(s) {
        const completed = [];
        if (s.mode === 'free') return completed;
        while (s.story.chapter < chapters.length && chapters[s.story.chapter].done(s)) {
            const c = chapters[s.story.chapter++];
            const reward = c.reward || 0;
            s.cash += reward;
            s.story.rewards += reward;
            completed.push({ title: c.title, reward });
        }
        return completed;
    }
    function current(s) {
        if(s.mode === 'free') return {n:-1,title:'Your city. Your choice.',text:'Explore, make stock and trade with any customer. There are no compulsory missions.',target:s.track,progress:'FREE ROAM / 40 CUSTOMERS / 7 DISTRICTS'};
        const i = s.story.chapter;
        if (i >= chapters.length)
            return { n: i + 1, title: 'Your own place in Sundown Bay', text: 'Story complete. The neighbourhood stays open. Keep building, try every blend, and set your own pace.', target: 'bench', progress: 'FREE PLAY / YOUR STORY CONTINUES' };
        const c = chapters[i];
        let target = c.target, progress = '';
        if (i === 1)
            progress = Math.min(3, s.story.walked).toFixed(1) + ' / 3m walked' + (s.story.looked >= .22 ? ' / Look: done' : ' / Turn your view');
        if (i === 7)
            progress = (s.story.flags.seedBought ? 'Seed: done' : 'Buy a seed') + ' / ' + (s.story.flags.pouchBought ? 'Pouches: done' : 'Buy pouches');
        if (i === 9 && s.story.flags.mistMade)
            target = 'lerato';
        const costs = { 11: 450, 12: 1600, 13: 650 };
        if (costs[i])
            progress = 'R' + Math.min(costs[i], Math.round(s.cash)) + ' / R' + costs[i];
        if (i === 14)
            progress = 'R' + Math.min(5000, Math.round(s.totalRevenue)) + ' / R5000 lifetime sales';
        return { n: i + 1, title: c.title, text: c.task, target, progress };
    }
    function event(s, name, data = {}) {
        if(s.mode === 'free') return;
        const f = s.story.flags;
        if (name === 'move')
            s.story.walked = Math.min(10, s.story.walked + Math.max(0, data.distance || 0));
        if (name === 'look')
            s.story.looked = Math.min(10, s.story.looked + Math.abs(data.amount || 0));
        if (name === 'intro')
            f.intro = true;
        if (name === 'mentor')
            f.metMentor = true;
        if (name === 'inventory')
            f.inventory = true;
        if (name === 'phone')
            f.phone = true;
        if (name === 'track' && data.id === 'sipho')
            f.trackedSipho = true;
        if (name === 'crafted' && data.recipe === 'glow')
            f.glowMade = true;
        if (name === 'crafted' && data.recipe === 'mist')
            f.mistMade = true;
        if (name === 'sale' && data.recipe === 'mist')
            f.mistSold = true;
        if (name === 'delivery' && data.npc === 'sipho')
            f.siphoDelivered = true;
        if (name === 'buy' && data.id === 'seed')
            f.seedBought = true;
        if (name === 'buy' && data.id === 'pouch')
            f.pouchBought = true;
        if (name === 'heatLesson')
            f.heatLesson = true;
    }
    root.MZStory = { chapters, initial, validate, advance, current, event, complete: s => s.story.chapter >= chapters.length };
})(typeof window === 'undefined' ? globalThis : window);
