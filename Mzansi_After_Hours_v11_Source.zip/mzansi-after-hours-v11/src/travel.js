'use strict';
/** Deterministic motion: metres, seconds and radians. A rigid bicycle-model chassis,
 * with acceleration, tyre grip, reverse, drag, braking and swept solid collisions.
 * This is not a full soft-body crash or stunt simulator. No dependencies. */
(function(root){
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 function jumpState(){return {height:0,velocity:0,grounded:true,landed:false};}
 function jump(j,ride=null){if(!j.grounded||ride?.car)return false;j.velocity=ride?4.1:5.0;j.grounded=false;j.landed=false;return true;}
 function stepJump(j,dt){if(!Number.isFinite(dt)||dt<=0)return;j.landed=false;let left=Math.min(dt,.2);while(left>0){const h=Math.min(left,1/120);left-=h;if(!j.grounded){j.velocity-=12*h;j.height+=j.velocity*h;if(j.height<=0){j.height=0;j.velocity=0;j.grounded=true;j.landed=true;}}}}
 function carMotion(yaw=0){return {speed:0,heading:yaw,distance:0,vx:0,vz:0,steer:0,roll:0,pitch:0,impact:0,gear:'N'};}
 function footprint(x,z,yaw,ride,world,state){
  const a=ride.halfWidth||.82,b=ride.halfLength||1.8,C=Math.cos(yaw),S=Math.sin(yaw),ex=Math.abs(C)*a+Math.abs(S)*b,ez=Math.abs(S)*a+Math.abs(C)*b,B=world.bounds;
  if(x-ex<B.minX||x+ex>B.maxX||z-ez<B.minZ||z+ez>B.maxZ)return false;
  for(const c of world.colliders){if(c.kind==='gate'&&state.workshop)continue;const hx=(c.x2-c.x1)/2,hz=(c.z2-c.z1)/2,dx=(c.x1+c.x2)/2-x,dz=(c.z1+c.z2)/2-z;
   if(Math.abs(dx)>=ex+hx||Math.abs(dz)>=ez+hz)continue;
   // Separating-axis test: car right/forward axes and the two wall axes.
   if(Math.abs(dx*C+dz*S)>=a+hx*Math.abs(C)+hz*Math.abs(S))continue;
   if(Math.abs(dx*S-dz*C)>=b+hx*Math.abs(S)+hz*Math.abs(C))continue;
   return false;
  }return true;
 }
 function carStep(m,r,input,dt,player,world,state){
  if(!r?.car||!Number.isFinite(dt)||dt<=0)return {distance:0,impact:0};
  if(root.MZNightlife&&state.rides?.equipped){if(MZNightlife.missing(state,state.rides.equipped).length){m.speed=m.vx=m.vz=0;return {distance:0,impact:0};}r=MZNightlife.tuned(state,state.rides.equipped)||r;}
  let remain=Math.min(dt,.12),distance=0,impact=0; m.contact=null;
  while(remain>1e-7){const h=Math.min(remain,1/120);remain-=h;
   const throttle=clamp(Number(input.forward)||0,-1,1),turn=clamp(Number(input.side)||0,-1,1),hand=!!input.brake;
   const road=root.MZVehicle?.surface(world,player.x,player.z,state.settings?.roadWet)||{mu:1.06,drag:.18,name:'Asphalt',rough:0};
   const d=state.rides?.damage?.[state.rides.equipped],health=root.MZVehicle?MZVehicle.condition(d)/100:1;
   let mu=road.mu*(r.grip||1);if(r.drive==='AWD'&&road.name==='Loose ground')mu*=1.15;
   const speed=m.vx*Math.sin(m.heading)-m.vz*Math.cos(m.heading),assist=state.settings?.stabilityAssist!==false;
   let force=0;
   if(throttle>.05)force=speed<-.3?r.braking:r.acceleration*throttle*(.62+.38*health);
   if(throttle<-.05)force=speed>.35?-r.braking:-(r.acceleration*.62)*Math.abs(throttle);
   const limit=mu*9.81;force=clamp(force,-limit*(assist?1:.88),limit*(r.drive==='AWD'?1:.92));
   if(hand)force=-Math.sign(speed)*Math.min(Math.abs(speed)/h,r.braking*1.22);
   const resistance=(road.drag+.0038*speed*speed+(!throttle&&r.body==='electric'?.8:0))*Math.sign(speed);
   let next=speed+(force-resistance)*h;if(!throttle&&!hand&&speed*next<0)next=0;
   next=clamp(next,-r.reverseSpeed,r.maxSpeed*(.68+.32*health));if(hand&&Math.abs(next)<.2)next=0;
   const bias=d?((d.right||0)-(d.left||0))*.026*Math.min(1,Math.abs(next)/5):0;
   const target=turn*.56/(1+Math.abs(next)*.046)+bias;m.steer+=(target-m.steer)*Math.min(1,h*8.5);
   const requested=next/r.wheelbase*Math.tan(m.steer),maxYaw=limit/Math.max(2,Math.abs(next));
   const desired=clamp(requested,-maxYaw,maxYaw);m.yawRate=(m.yawRate||0)+(desired-(m.yawRate||0))*Math.min(1,h*(assist?9:5.5));
   if(Math.abs(next)<.04)m.yawRate=0;
   const yaw=m.heading+m.yawRate*h;
   if(footprint(player.x,player.z,yaw,r,world,state))m.heading=yaw;else{m.steer=0;m.yawRate*=.5;next*=.9;}
   const lateral=m.vx*Math.cos(m.heading)+m.vz*Math.sin(m.heading);
   const grip=(hand?1.35:assist?11:6.3)*mu;let slip=lateral*Math.exp(-grip*h);
   if(hand&&Math.abs(next)>2)slip+=turn*Math.abs(next)*h*.22;
   m.vx=Math.sin(m.heading)*next+Math.cos(m.heading)*slip;m.vz=-Math.cos(m.heading)*next+Math.sin(m.heading)*slip;
   const ox=player.x,oz=player.z,dx=m.vx*h,dz=m.vz*h;
   if(footprint(ox+dx,oz+dz,m.heading,r,world,state)){player.x+=dx;player.z+=dz;}
   else{
    const hit=Math.hypot(m.vx,m.vz);impact=Math.max(impact,hit);
    let nx=0,nz=0;
    if(footprint(ox+dx,oz,m.heading,r,world,state)){player.x+=dx;nz=Math.sign(dz);m.vz*=-.17;m.vx*=.70;}
    else if(footprint(ox,oz+dz,m.heading,r,world,state)){player.z+=dz;nx=Math.sign(dx);m.vx*=-.17;m.vz*=.70;}
    else{nx=Math.sign(dx);nz=Math.sign(dz);m.vx*=-.12;m.vz*=-.12;}
    if(!m.contact||hit>m.contact.speed)m.contact={speed:hit,x:nx*Math.cos(m.heading)+nz*Math.sin(m.heading),z:-nx*Math.sin(m.heading)+nz*Math.cos(m.heading)};
    m.yawRate*=.55;m.pitchV=(m.pitchV||0)+Math.min(.8,hit*.025);m.impact=.65;
   }
   const travelled=Math.hypot(player.x-ox,player.z-oz);distance+=travelled;m.distance+=travelled;
   m.speed=m.vx*Math.sin(m.heading)-m.vz*Math.cos(m.heading);m.wheelSpin=(m.wheelSpin||0)+m.speed*h/(r.body==='suv'?.42:.35);
   root.MZVehicle?.updateSuspension(m,r,force,m.yawRate*next,road,h);
   m.handBrake=hand;m.surface=road.name;m.traction=clamp(Math.abs(lateral)/Math.max(2,Math.abs(next)),0,1);m.braking=hand||(throttle<0&&speed>0)||(throttle>0&&speed<0);
   m.driveGear=Math.min(6,Math.max(1,Math.ceil(Math.abs(m.speed)/(r.maxSpeed/5.5))));
   m.rpm=r.body==='electric'?Math.round(900+Math.abs(m.speed)*240):Math.round(850+clamp(Math.abs(m.speed)/(r.maxSpeed/5.5)-m.driveGear+1,.12,1)*4900);
  }
  m.gear=m.speed<-.3?'R':Math.abs(m.speed)<.3?'N':'D';m.impact=Math.max(0,(m.impact||0)-dt);return {distance,impact,contact:m.contact};
 }
 function chase(player,m,world,state){
  const target={x:player.x,z:player.z},back=6.8;let d=back;
  for(let i=.4;i<=back;i+=.2){if(!world.isFree(target.x-Math.sin(m.heading)*i,target.z+Math.cos(m.heading)*i,state,.2)){d=Math.max(.25,i-.3);break;}}
  return {x:target.x-Math.sin(m.heading)*d,z:target.z+Math.cos(m.heading)*d,y:Math.min(3.3,1.5+d*.27),yaw:m.heading,pitch:-.22,roll:0};
 }
 root.MZTravel={jumpState,jump,stepJump,carMotion,carStep,footprint,chase};
})(typeof window==='undefined'?globalThis:window);
