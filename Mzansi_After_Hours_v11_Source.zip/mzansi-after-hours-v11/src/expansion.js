'use strict';
/** Open Neighbourhood: connected roads, original modular buildings and new contacts. */
(function(root){
 root.MZExpansion={build(a){
  const {world:w,box,col,sign,point,tree,bench,crate,building,person,rnd}=a;
  const b=MZNeighbourhood.bounds;w.bounds=b;
  w.roads=[{x:0,z:0,w:248,d:12},{x:18,z:-25,w:12,d:158},{x:-76,z:0,w:10,d:106},{x:76,z:0,w:10,d:106},{x:0,z:-64,w:248,d:10}];
  // Land and roads meet the original paving at its existing elevations.
  box(-92.5,-.015,-25,65,.12,158,0xa5aa90);box(92.5,-.015,-25,65,.12,158,0xa9b098);
  box(0,-.015,-79,124,.12,50,0xa3ad93);
  function road(x,z,width,depth,horizontal){
   box(x,.008,z,width,.11,depth,0x566368);
   const len=horizontal?width:depth;
   for(const side of [-1,1]){
    if(horizontal){box(x,.095,z+side*(depth/2+1.9),width,.24,3.7,0xbfc0a9);box(x,.17,z+side*(depth/2+.07),width,.18,.14,0xd1c8b1);}
    else{box(x+side*(width/2+1.9),.095,z,3.7,.24,depth,0xbfc0a9);box(x+side*(width/2+.07),.17,z,.14,.18,depth,0xd1c8b1);}
   }
   for(let i=-len/2+2;i<len/2;i+=6){let xx=horizontal?x+i:x,zz=horizontal?z:z+i;if(horizontal&&[18,-76,76].some(t=>Math.abs(t-xx)<7))continue;if(!horizontal&&[0,-64].some(t=>Math.abs(t-zz)<7))continue;box(xx,.078,zz,horizontal?2.7:.12,.02,horizontal?.12:2.7,0xe0d8b9);}
  }
  road(-92,0,64,12,true);road(92,0,64,12,true);road(18,-79,12,50,false);
  road(-76,0,10,106,false);road(76,0,10,106,false);road(0,-64,248,10,true);
  // Perimeter is outside old boundaries, with clear passages between districts.
  box(0,.68,b.minZ-1,250,1.3,.45,0x88938a);/* South now opens into the park and harbour. */
  box(b.minX-1,.68,-25,.45,1.3,160,0x88938a);box(b.maxX+1,.68,-25,.45,1.3,160,0x88938a);
  function poleSign(text,sub,x,z,ry=0){box(x,1.8,z,.13,3.6,.13,0x48645d);sign(text,sub,x,3.15,z,8,1.1,'#345c55','#f5dfb7',ry,true);}
  function light(x,z){box(x,2.4,z,.11,4.8,.11,0x41605a);box(x,4.84,z,.8,.18,.8,0xf6d5a1);}
  function stall(x,z,name,tint){
   for(let dx of [-2.7,2.7])for(let dz of [-1.8,1.8])box(x+dx,1.6,z+dz,.10,3.2,.1,0x546e61);
   for(let i=0;i<8;i++)box(x-2.8+i*.8,3.28,z,.8,.18,4.6,i%2?tint:0xeedabc);
   box(x,1.0,z+1.6,5.6,.35,1.1,0x9e7854);col(x,z+1.6,5.6,1.1);
   for(let k=0;k<6;k++)box(x-2+k*.8,1.36,z+1.6,.5,.35,.5,[0xd9b45d,0x81a46c,0xc68664][k%3]);
   sign(name,'LOCAL MAKERS / OPEN LATE',x,2.6,z+2.32,5.5,.64,'#365d55','#f4ddad',0,true);
  }
  // WEST: pedestrian market lanes and a working satellite supply kiosk.
  box(-103,.10,15,33,.20,68,0xbca587);
  building(-104,-46,28,14,5.5,0xb89376,'MASAKHANE HALL','MARKET / COMMUNITY / MAKERS');
  stall(-114,-22,'MARKET SUPPLIES',0x788ea7);stall(-101,-22,'FRESH & LOCAL',0xbf8065);stall(-89,-22,'MADE IN THE BAY',0x72a28b);
  stall(-114,28,'SUNDOWN THREADS',0xaa80a5);stall(-102,41,'PAPER & PRINT',0xbb954e);
  building(-111,12,12,10,4.2,0xc89576,'THE CORNER STUDIO','DESIGN / REPAIR / CREATE');
  for(let x of [-119,-87])for(let z of [-39,20,45]){tree(x,z,.68,(z===20));light(x+2,z+3);}
  crate(-98,0,-40);crate(-96.8,0,-40);bench(-90,20);bench(-101,-11);
  poleSign('MASAKHANE MARKET','EXPLORE / TRADE / MAKE CONNECTIONS',-88,7);
  point('marketSquare','district','Masakhane Market',-88,10,'NEW DISTRICT',{district:'market'});
  point('marketSupply','shop','Market supply kiosk',-114,-17.8,'MASAKHANE MARKET',{vendor:'Market supply kiosk'});
  point('marketTaxi','taxi','Market taxi stop',-83,4,'LOCAL TAXIS / R20');
  // EAST: boardwalk, water beyond the rail, cafe tables and open walking lanes.
  box(111,.1,0,26,.2,104,0xcbb693);for(let z=-50;z<53;z+=1.3)box(112,.209,z,24,.012,.035,0xae997d);
  box(158,.05,-20,65,.10,190,0x5a9394);for(let z=-100;z<66;z+=6)box(150,.111,z,43,.012,.07,0x99c2b0);
  for(let z=-51;z<54;z+=3){box(123,1.1,z,.12,2,.12,0xc5c7b0);box(123,1.62,z+1.5,.1,.1,3.1,0x5c7c70);box(123,.76,z+1.5,.1,.09,3.1,0x5c7c70);}
  building(102,-44,30,13,5.5,0xd2ac88,'BAYFRONT CAFE','SEA AIR / GOOD FOOD / GOOD COMPANY');
  for(let x of [98,105,112]){box(x,.92,-32,2,.12,1.5,0x9e8159);box(x,.45,-32,.14,.9,.14,0x4e665c);col(x,-32,2,1.5);box(x,3.0,-32,3.7,.12,3.2,0xe4c88c);box(x,1.8,-32,.08,2.4,.08,0x466858);}
  for(let z of [-20,3,26,47]){bench(119,z);light(121,z+3);tree(88,z,.65,false);}
  poleSign('BAYFRONT WALK','A LITTLE MORE ROOM TO ROAM',100,7);
  point('bayfront','district','Bayfront Walk',106,12,'NEW DISTRICT',{district:'bayfront'});
  point('bayFood','food','Bayfront cafe counter',105,-35,'BAYFRONT WALK');
  point('bayTaxi','taxi','Bayfront taxi stop',83,4,'LOCAL TAXIS / R20');
  // NORTH: a residential loop and community green, joined by the new avenue.
  const homes=[[-106,0xbda487],[-82,0x88a297],[-47,0xc7aa90],[-24,0x9aac9b],[-3,0xb99d98],[42,0xa3b2a9],[79,0xc4ab81],[105,0x889f9a]];
  for(let [x,tint] of homes){building(x,-93,16,15,4.6,tint,'','');box(x,5.0,-93,17,.22,16,0x677f75);for(let j=0;j<3;j++)box(x-5+j*4,1,-84.7,2.8,.18,.18,0xbdc5b2);}
  box(-30,.08,-75,53,.16,15,0x93a87f);box(-30,.175,-74,53,.03,2.5,0xc6b396);
  for(let x of [-57,-38,-18,2,31,55,87,-91]){tree(x,-83,.72,true);light(x+2,-82);}
  for(let x of [-43,-23,-3,38])bench(x,-72);
  poleSign('JACARANDA HEIGHTS','COMMUNITY GREEN / NORTHERN AVENUE',-8,-70,Math.PI);
  point('heights','district','Jacaranda Heights',4,-74,'NEW DISTRICT',{district:'heights'});
  point('heightsTaxi','taxi','Heights taxi stop',10,-68,'LOCAL TAXIS / R20');
  // Distinct, reusable model palette. Distance culling limits phone draw calls.
  const models=[];const skins=[0x855c41,0xc4936b,0xe1b99a,0x694e3c,0xa7714e,0xba8d65];
  const shirts=[0xc48e67,0x759b9f,0x9985ae,0xaaa16d,0xd2b485,0x749b83];
  for(let i=0;i<6;i++)models.push(person(skins[i],shirts[i],0x435758,i%3===1,i%2===0?'lerato':'newcomer'));
  for(let i=0;i<MZNeighbourhood.customers.length;i++){
   const n=MZNeighbourhood.customers[i];if(['commons','harbour'].includes(n.district))continue;w.customers.push({...n,homeX:n.x,homeZ:n.z,ry:Math.PI*.25,kind:'CUSTOMER',type:'customer',model:models[i%6],phase:rnd()*6,walk:false,cooldown:0});
  }
  for(const n of w.customers)if(!n.district)n.district='centre';
  w.cars.push({x:-100,z:-61,ry:Math.PI/2,speed:4.2},{x:100,z:-67,ry:-Math.PI/2,speed:-4.8});
  // New patrols follow the unobstructed district avenues.
  for(const [i,path] of [[[ -76,-48],[-76,47],[-76,3],[-115,3],[-115,-3],[-76,-3]],[[76,-48],[76,47],[76,3],[117,3],[117,-3],[76,-3]]].entries()){
   w.police.push({id:'outerPatrol'+i,x:path[0][0],z:path[0][1],ry:0,phase:i,model:w.police[i].model,path,index:1,speed:1.4,chase:false});
  }
 }};
})(window);
