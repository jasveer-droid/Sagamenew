'use strict';
/** Mobile Fit: visible-viewport layout, not device-name guesses or CSS scaling.
 * Reuse real status nodes so money/health cannot become stale in a second HUD.
 * Original insertion points are restored on desktop. No save data is changed.
 */
(function (root) {
    const doc = document, html = doc.documentElement, body = doc.body;
    const compactHud = doc.getElementById('compactHud');
    const targets = ['.wallet-block', '.vitals', '#compass'].map(selector => {
        const node = doc.querySelector(selector), anchor = doc.createComment('desktop ' + selector);
        node.before(anchor);
        return {node, anchor};
    });
    let touch = false, compact = false, pending = 0;
    let viewport = {width: root.innerWidth, height: root.innerHeight, left: 0, top: 0};
    const px = n => Math.round(n * 100) / 100 + 'px';
    function measure() {
        const v = root.visualViewport;
        // Preserve normal browser zoom. At normal scale, browser chrome and the
        // on-screen keyboard can shrink the visible area without a window resize.
        const visual = v && Math.abs(v.scale - 1) < .05;
        return {
            width: Math.max(1, visual ? v.width : root.innerWidth),
            height: Math.max(1, visual ? v.height : root.innerHeight),
            left: visual ? Math.max(0, v.offsetLeft) : 0,
            top: visual ? Math.max(0, v.offsetTop) : 0
        };
    }
    function apply() {
        pending = 0;
        const before = viewport;
        viewport = measure();
        const major = Math.abs(before.width - viewport.width) > 2;
        for (const [key, value] of Object.entries(viewport)) html.style.setProperty('--view-' + key, px(value));
        const nextCompact = touch || viewport.width < 1100 || viewport.height < 620;
        if (nextCompact !== compact) {
            compact = nextCompact;
            targets.forEach(({node, anchor}) => compact ? compactHud.append(node) : anchor.after(node));
        }
        body.classList.add('fit-ui');
        body.classList.toggle('compact-ui', compact);
        body.classList.toggle('fit-landscape', viewport.width >= 540 && viewport.width > viewport.height);
        body.classList.toggle('fit-short', viewport.height < 440);
        body.classList.toggle('fit-tiny', viewport.height < 300);
        body.classList.toggle('fit-narrow', viewport.width < 370);
        body.classList.toggle('fit-single', viewport.width < 620);
        body.classList.toggle('fit-medium', viewport.width < 820);
        root.dispatchEvent(new CustomEvent('mz:layoutchange', {detail: {major, compact, ...viewport}}));
    }
    function schedule() { if (!pending) pending = root.requestAnimationFrame(apply); }
    root.addEventListener('resize', schedule, {passive: true});
    root.addEventListener('orientationchange', () => {schedule(); root.setTimeout(schedule, 180);}, {passive: true});
    root.addEventListener('pageshow', schedule, {passive: true});
    doc.addEventListener('fullscreenchange', schedule);
    root.visualViewport?.addEventListener('resize', schedule, {passive: true});
    root.visualViewport?.addEventListener('scroll', schedule, {passive: true});
    root.MZLayout = {
        get viewport() {return viewport;}, get compact() {return compact;},
        setTouch(value) {if (touch !== !!value) {touch = !!value; schedule();}},
        refresh: schedule
    };
    apply();
})(window);
