'use strict';
/** A random local browser profile, not a hardware fingerprint or a cloud account. */
(function(root){
    const KEY='mzansi_after_hours_device';
    function randomId(){
        try{return root.crypto.randomUUID().replace(/-/g,'').slice(0,20);}
        catch(_){return Date.now().toString(36)+Math.random().toString(36).slice(2,10);}
    }
    function create(storage){
        let profile=null,available=false,persisted=false;
        try{const raw=JSON.parse(storage.getItem(KEY)||'null');if(raw&&/^[A-Z0-9-]{5,24}$/.test(raw.id))profile=raw;}catch(_){}
        profile=profile||{id:'BAY-'+randomId().slice(0,8).toUpperCase(),mode:'auto'};
        if(!['auto','on','off'].includes(profile.mode))profile.mode='auto';
        function remember(mode){if(['auto','on','off'].includes(mode))profile.mode=mode;
            try{storage.setItem(KEY,JSON.stringify(profile));available=true;return true;}catch(_){available=false;return false;}}
        remember(profile.mode);
        function newer(state){
            try{const saved=JSON.parse(storage.getItem(root.MZSave.KEY)||'null');
                return saved?.game==='mzansi-after-hours'&&[4,5,6,7,8,9,10,11].includes(saved.version)&&(saved.meta?.revision||0)>(state.meta?.revision||0)&&saved.meta?.writer!==session;
            }catch(_){return false;}
        }
        const session=randomId();
        async function retention(){try{persisted=await root.navigator.storage.persisted();}catch(_){}return persisted;}
        async function protect(){try{persisted=await root.navigator.storage.persist();return persisted;}catch(_){return false;}}
        return {profile,session,remember,newer,retention,protect,get available(){return available;},get persisted(){return persisted;}};
    }
    root.MZDevice={KEY,create};
})(typeof window==='undefined'?globalThis:window);
