'use strict';
/** Enterprise Quarter: twenty walk-in workspaces and a fictional bank. */
(function(root){
 root.MZCommerceWorld={build(a){
 const {world:w,renderer:r,box,col,sign,point,tree,bench,person}=a,D=MZCommerceData,G=MZ.Geometry;
 box(-197,-.13,-14,148,.27,232,0x9ca590);
 const roads=[{x:-129,z:-15,w:10,d:224,name:'Enterprise Drive'},...[-232,-198,-164].map((x,i)=>({x,z:9,w:8,d:190,name:['Founders Lane','Opportunity Lane','Workshop Lane'][i]})),...[-87,-46,-10,26,62,98].map((z,i)=>({x:-198,z,w:142,d:8,name:['Bank Street','Service Street','Market Link','Craft Street','Trade Street','Commerce Crescent'][i]}))];
 for(const v of roads){w.roads.push(v);box(v.x,.007,v.z,v.w,.12,v.d,0x54636a);const horizontal=v.w>v.d;for(const side of [-1,1])box(v.x+(horizontal?0:side*5.2),.09,v.z+(horizontal?side*5.2:0),horizontal?v.w:2.1,.19,horizontal?2.1:v.d,0xc5c4b0);const len=horizontal?v.w:v.d;for(let q=-len/2+3;q<len/2;q+=7)box(v.x+(horizontal?q:0),.077,v.z+(horizontal?0:q),horizontal?2.5:.10,.013,horizontal?.10:2.5,0xe1dac2);}
 // An unobstructed link joins the old market road to the new grid.
 box(-126,.012,0,13,.12,12,0x54636a);box(-129,.014,-5,10,.12,14,0x54636a);
 const skins=[0x916044,0xc39970,0x6d4c39,0xae7957],workers=skins.map((c,i)=>person(c,[0x7ca295,0xceb37e,0x8ca4ba,0xaf8c99][i],0x344e53,i===1));
 function shell(x,z,width,depth,colour,name,sub){
  box(x,.04,z,width,.12,depth,0xb8a588);box(x,.14,z,width-.5,.12,depth-.5,0xcbbba1);
  for(const side of [-1,1]){box(x+side*width/2,2.25,z,.25,4.5,depth,colour);col(x+side*width/2,z,.25,depth);}
  box(x,2.25,z-depth/2,width,4.5,.25,colour);col(x,z-depth/2,width,.25);
  // Four-metre entrance remains truly open; decorative windows are on the wings.
  const wing=(width-4.5)/2;for(const side of [-1,1]){const xx=x+side*(2.25+wing/2);box(xx,1.5,z+depth/2,wing,3,.25,colour);col(xx,z+depth/2,wing,.25);box(xx,1.9,z+depth/2+.14,wing-1,1.7,.06,0x577d82);for(const v of [-1,1])box(xx+v*(wing-1)/2,1.9,z+depth/2+.19,.07,1.8,.05,0xe0d6b9);}
  box(x,3.7,z+depth/2,width,1.55,.25,colour);box(x,4.6,z,width+.5,.2,depth+.5,0x4c6a69);
  box(x,3.05,z+depth/2+.8,width+.9,.13,2.1,0xc4a76e);
  sign(name.toUpperCase(),sub,x,3.76,z+depth/2+.2,width-1,1.23,'#224849','#f4dfb4',0,true);
  for(let i=0;i<4;i++){box(x-8+i*5,.216,z-depth/2+2,2.2,.03,1.5,0xb0a087);}
  w.buildings.push({x,z,w:width,d:depth,color:colour,name});
 }
 function counter(x,z,width=6){box(x,1.06,z,width,1.9,1.1,0x8c7257);box(x,2.06,z,width+.2,.15,1.25,0xd7c2a0);col(x,z,width,1.2);box(x+1.8,2.25,z,.64,.37,.48,0x3d5558);box(x+1.8,2.48,z,.6,.08,.4,0xbcdaca);}
 function shelves(x,z,colr=0x86a396){for(let y=.55;y<2.5;y+=.8){box(x,y,z,5,.12,.9,0x896c50);for(let j=0;j<5;j++)box(x-1.8+j*.86,y+.3,z,.55,.50,.50,j%2?colr:0xddc496);}col(x,z,5,1);}
 for(const [i,d]of D.businesses.entries()){
  const {x,z}=d;shell(x,z,24,22,d.colour,d.name,d.type.toUpperCase()+' / WORK / OWN / GROW');counter(x,z+3);
  shelves(x-8,z-6,d.colour);shelves(x+8,z-6,d.colour);
  const geom=new G();
  if(['food','produce','retail'].includes(d.style)){
   box(x-7,1,z+4,4,1.8,3,0x73918a);col(x-7,z+4,4,3);for(let k=0;k<9;k++)geom.sphere(x-8+(k%3),2.04,z+3+Math.floor(k/3),.32,.25,.32,[0xce9563,0xc8b472,0x8eaa6c][k%3],5,8);
   if(d.id==='coffee'){box(x+7,1.5,z+3,3,2.7,2,0x536f73);box(x+7,2.9,z+3,2.8,.15,2.1,0xbdc2a8);col(x+7,z+3,3,2);}
  }else if(d.style==='laundry'){for(let j=0;j<3;j++){box(x-8+j*3,1.5,z-3,2.5,2.7,1.8,0xadc0b6);geom.sphere(x-8+j*3,1.5,z-2.04,.77,.77,.08,0x486b79,8,12);col(x-8+j*3,z-3,2.5,1.8);}}
  else if(d.style==='garage'||d.style==='bikes'){
   box(x-7,.75,z-2,3.2,1,6.4,0x667f77);col(x-7,z-2,3.2,6.4);box(x-7,1.52,z-2,2.7,.5,4,0xbc9471);
   for(const dx of [-1.5,1.5])for(const dz of [-1.8,1.8])geom.sphere(x-7+dx,.83,z-2+dz,.30,.55,.55,0x344849,7,10);
   for(let j=0;j<5;j++)box(x+7,1.1+j*.4,z-3,3,.12,.8,0xacbbaa);
  }else if(d.style==='salon'){for(const dx of [-7,7]){box(x+dx,.65,z,2,.8,2,0x647482);box(x+dx,1.5,z-1,2,1.5,.25,0x647482);box(x+dx,2.1,z-3,2.8,2.8,.13,0xa2c5c5);col(x+dx,z,2,2);}}
  else if(d.style==='flowers'){for(let k=0;k<8;k++){const xx=x-8+(k%4)*1.3,zz=z-1+Math.floor(k/4)*1.7;geom.cylinder(xx,.6,zz,.38,.3,1,0xbb9b72,7);geom.sphere(xx,1.5,zz,.65,.55,.65,[0xb38eac,0xd7ba6b,0x9bb586][k%3],5,8);}col(x-6,z,6,4);}
  else if(d.style==='hotel'){for(const dx of [-7,7]){box(x+dx,.65,z-2,3,.8,6,0x839f9b);box(x+dx,1.1,z-4,2.8,.3,1.4,0xe1d8c1);col(x+dx,z-2,3,6);}}
  else if(d.style==='fitness'){for(const dx of [-7,7]){box(x+dx,.35,z-2,2.7,.35,5.3,0x51686b);geom.beam([x+dx-1.1,.4,z-4],[x+dx-1.1,2,z-4],.12,0xa2b3a4);geom.beam([x+dx+1.1,.4,z-4],[x+dx+1.1,2,z-4],.12,0xa2b3a4);box(x+dx,2,z-4,2.5,.2,1,0x364b52);col(x+dx,z-2,3,5);}}
  else{for(const dx of [-7,7]){box(x+dx,1,z-1,3.2,.16,2.3,0xb49a77);col(x+dx,z-1,3.2,2.3);box(x+dx,1.6,z-1,2,.9,.7,d.style==='books'?0xccb288:0x688489);box(x+dx,1.65,z-.62,1.7,.6,.06,0x9bc3be);}}
  if(geom.v.length){w.commerceProps??=[];w.commerceProps.push(r.mesh(geom));}
  point(d.point.id,'business',d.name,x,z+6,'WORK / BUSINESS',{businessId:d.id});
  w.pedestrians.push({name:d.owner,x:x-1.5,z:z+1.3,ry:0,model:workers[i%4],phase:i,stationary:true});
  // Readable counter-level invitation, unlike a decorative building label.
  sign('WORK HERE / OPEN YOUR OWN','THREE TASKS / WAGES PAID TO YOUR GAME BANK',x,2.8,z-6.7,10,1.1,'#335956','#f0d8ae',0,true);
  if(i%4===0)tree(x-15,z+15,.65,true);
 }
 // A larger, accessible banking hall with desks, ATM and a visible vault door.
 shell(-215,-110,31,24,0x9cad9f,'Ubuntu Community Bank','GAME MONEY ONLY / CURRENT / SAVINGS');counter(-215,-105,10);
 box(-224,2,-120,4,3.8,.4,0x5a7677);col(-224,-120,4,.5);sign('VAULT','STAFF ONLY',-224,2,-119.72,3,1.0,'#314f53','#e9d7ad',0,true);
 for(const xx of [-225,-204]){box(xx,.6,-109,3,.4,1.5,0x4b7371);box(xx,1.2,-109.6,3,1.1,.18,0x4b7371);col(xx,-109,3,1.5);}
 box(-200,1.4,-96.6,1.8,2.7,1.2,0x37575d);box(-200,1.9,-95.96,1.3,.8,.08,0x8abdb5);col(-200,-96.6,1.8,1.2);sign('ATM','GAME CASH',-200,3,-95.95,2.6,.7,'#294e51','#f1d6a0',0,true);
 for(const p of [D.bank,D.atm])point(p.id,'bank',p.name,p.x,p.z,'GAME BANK / NO REAL MONEY');
 w.pedestrians.push({name:'Lebo / bank host',x:-216.8,z:-106.7,ry:0,model:workers[2],phase:0,stationary:true});
 shell(-169,-110,25,24,0xb2a28b,'Enterprise Careers','TWENTY EMPLOYERS / START A PAID SHIFT');counter(-169,-105,7);
 point(D.jobs.id,'careers',D.jobs.name,D.jobs.x,D.jobs.z,'CAREERS / DAILY JOBS');point(D.centre.id,'businesses',D.centre.name,D.centre.x,D.centre.z,'ENTERPRISE QUARTER');
 w.pedestrians.push({name:'Sam / careers host',x:-170,z:-106.7,ry:0,model:workers[1],phase:1,stationary:true});
 point('enterpriseTaxi','taxi','Enterprise taxi stop',-130,-84,'TAXI RANK');sign('ENTERPRISE QUARTER','BANK / TWENTY WORKING BUSINESSES',-128,3.4,-6,8,1.3,'#2c5655','#f2d2a0',Math.PI/2,true);
 },install(r,w){
  const G=MZ.Geometry,M=MZ.M,green=new G(),amber=new G(),parcel=new G();green.sphere(0,0,0,.12,.12,.12,0x8edea8,5,8);amber.sphere(0,0,0,.12,.12,.12,0xe7b46d,5,8);parcel.box(0,.24,0,.55,.45,.5,0xd6b078);parcel.box(0,.48,0,.12,.04,.51,0xf3dfb7);const gm=r.mesh(green),am=r.mesh(amber),pm=r.mesh(parcel);const old=w.render;
  w.render=(s,t)=>{old(s,t);r.gl.useProgram(r.cp);for(const mesh of w.commerceProps||[])r.draw(mesh);for(const d of MZCommerceData.businesses){if(Math.hypot(d.x-s.player.x,d.z-s.player.z)>90)continue;const f=s.enterprise?.firms[d.id];r.draw(f?.open?gm:am,M.model(d.x-2.7,2.35,d.z+3.1));if(f)for(let j=0;j<Math.min(6,Math.ceil(f.stock/5));j++)r.draw(pm,M.model(d.x+6+(j%3)*.65,.25+Math.floor(j/3)*.5,d.z+4));if(s.enterprise?.task&&s.enterprise?.work?.biz===d.id)r.draw(pm,M.model(d.x,2.31,d.z+3,t*.7));}}
 }};
})(window);
