'use strict';
/** Pure gameplay rules for health and personal rides. No DOM, dependencies or timers. */
(function (root) {
    const RIDES = Object.freeze({
        skateboard: { name: 'Ubuntu Cruiser', kind: 'Skateboard', price: 250, maxSpeed: 9, acceleration: 4.2, drag: 1.25, height: .20, radius: .36, colour: 0xe2ac63,
            description: 'Your first set of wheels. Compact, light and quicker than walking.' },
        bicycle: { name: 'Bay Commuter', kind: 'Bicycle', price: 700, maxSpeed: 12, acceleration: 3.6, drag: .85, height: .10, radius: .40, colour: 0x78c5ae,
            description: 'An everyday bicycle with a delivery basket and an easy cruising pace.' },
        scooter: { name: 'Sundown Electric', kind: 'Electric scooter', price: 1500, maxSpeed: 15, acceleration: 5.4, drag: 1.0, height: .08, radius: .43, colour: 0xdb8466,
            description: 'A compact electric ride. Smooth acceleration; leave room to brake and hop.' },
        hatchback: {name:'Sundown City',kind:'Hatchback',price:4500,maxSpeed:18,reverseSpeed:5,acceleration:4.2,braking:10,wheelbase:2.3,car:true,halfWidth:.83,halfLength:1.82,height:0,radius:.9,colour:0x69a9b5,body:'hatch',mass:1080,drive:'FWD',grip:1.03,spring:38,damping:9,description:'A nimble city car with reverse, tyre grip and a proper turning circle. Up to 65 km/h.'},
        bakkie: {name:'Ubuntu Hauler',kind:'Bakkie',price:8000,maxSpeed:21,reverseSpeed:4.5,acceleration:3.2,braking:8.5,wheelbase:2.7,car:true,halfWidth:.94,halfLength:2.25,height:0,radius:1,colour:0xe8b665,body:'pickup',mass:1840,drive:'RWD',grip:.86,spring:28,damping:7,description:'A heavier pickup with slower braking, rear load bed and a wider turning circle. Up to 76 km/h.'}
,
        sedan: {name:'Karoo Executive',kind:'Saloon',body:'sedan',price:6500,maxSpeed:25,reverseSpeed:5,acceleration:4.4,braking:10.3,wheelbase:2.66,car:true,halfWidth:.88,halfLength:2.18,height:0,radius:.95,colour:0x456b8d,mass:1420,drive:'RWD',grip:1.05,spring:34,damping:9,description:'A balanced rear-drive saloon. A long wheelbase makes sweeping corners calmer.'},
        coupe: {name:'Cape Veloce',kind:'Sports coupe',body:'coupe',price:14500,maxSpeed:34,reverseSpeed:6,acceleration:6.7,braking:13,wheelbase:2.52,car:true,halfWidth:.91,halfLength:2.08,height:0,radius:.98,colour:0xc75042,mass:1260,drive:'RWD',grip:1.18,spring:50,damping:11,description:'Low, light and quick. Strong brakes, firmer suspension and lively rear-wheel drive.'},
        suv: {name:'Drakensberg Trail',kind:'Family SUV',body:'suv',price:12000,maxSpeed:24,reverseSpeed:5,acceleration:4.0,braking:10,wheelbase:2.78,car:true,halfWidth:.99,halfLength:2.3,height:0,radius:1.06,colour:0x667b63,mass:2020,drive:'AWD',grip:1.0,spring:29,damping:8,description:'All-wheel drive, a tall cabin and more body movement. Stable on loose surfaces.'},
        van: {name:'Ubuntu Cargo',kind:'Delivery van',body:'van',price:10500,maxSpeed:21,reverseSpeed:4,acceleration:2.9,braking:8.5,wheelbase:2.93,car:true,halfWidth:.99,halfLength:2.5,height:0,radius:1.06,colour:0xd4d2c5,mass:2300,drive:'FWD',grip:.91,spring:27,damping:8,description:'A long-wheelbase working van. Heavy, steady and slower to stop; plan your turns.'},
        minibus: {name:'Sundown Shuttle',kind:'Minibus',body:'minibus',price:16000,maxSpeed:23,reverseSpeed:4,acceleration:3.0,braking:8.6,wheelbase:3.05,car:true,halfWidth:1.02,halfLength:2.65,height:0,radius:1.09,colour:0xe3e5da,mass:2550,drive:'RWD',grip:.88,spring:25,damping:8,description:'A spacious local shuttle with individual side windows. Leave extra braking distance.'},
        rally: {name:'Sundown Rally',kind:'Rally hatch',body:'rally',price:18500,maxSpeed:29,reverseSpeed:5.5,acceleration:6.1,braking:12,wheelbase:2.38,car:true,halfWidth:.88,halfLength:1.93,height:0,radius:.94,colour:0xd1a543,mass:1180,drive:'AWD',grip:1.16,spring:33,damping:8,description:'A raised AWD hatch with a spoiler, auxiliary lamps and tyres suited to gravel.'},
        classic: {name:'Protea Classic',kind:'Classic coupe',body:'classic',price:9500,maxSpeed:26,reverseSpeed:4.5,acceleration:4.8,braking:8.6,wheelbase:2.62,car:true,halfWidth:.91,halfLength:2.26,height:0,radius:.98,colour:0x6b9c96,mass:1540,drive:'RWD',grip:.83,spring:24,damping:6.5,description:'Chrome bumpers, round lamps and softer suspension. Easy to slide; brake early.'},
        electric: {name:'Jozi Current',kind:'Electric GT',body:'electric',price:22500,maxSpeed:32,reverseSpeed:5,acceleration:7.2,braking:12.3,wheelbase:2.8,car:true,halfWidth:.94,halfLength:2.27,height:0,radius:1.01,colour:0x8b86ad,mass:1930,drive:'AWD',grip:1.14,spring:43,damping:10,description:'Immediate electric response, a panoramic roof and extra coasting deceleration.'}
    });
    const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
    const angle = n => Math.atan2(Math.sin(n),Math.cos(n));
    function motion(yaw=0) { return { speed:0, heading:yaw, distance:0 }; }
    function step(m, ride, input, dt) {
        if (!ride || !Number.isFinite(dt) || dt <= 0) return { dx:0,dz:0 };
        dt = Math.min(dt,.1);
        const throttle = clamp(Number(input.forward)||0,-1,1);
        if (input.brake || throttle < -.1) m.speed = Math.max(0,m.speed - 17*dt*Math.max(.4,Math.abs(throttle)));
        else if (throttle > .05) m.speed = Math.min(ride.maxSpeed*(input.boost?1:.85),m.speed + ride.acceleration*throttle*dt);
        else m.speed = Math.max(0,m.speed - ride.drag*dt);
        const target = Number.isFinite(input.yaw)?input.yaw:m.heading;
        m.heading += angle(target - m.heading)*Math.min(1,dt*(m.speed>1?3.2:6));
        return { dx:Math.sin(m.heading)*m.speed*dt,dz:-Math.cos(m.heading)*m.speed*dt };
    }
    function buyRide(s,id) {
        const r=Object.hasOwn(RIDES,id)?RIDES[id]:null;
        if (!r || s.rides.owned[id] || !MZLife.canPay(s,r.price)) return false;
        MZLife.pay(s,r.price);s.rides.owned[id]=true;s.rides.equipped=id;s.rides.riding=false;return true;
    }
    function useMedkit(s) {
        if(s.health>=100 || s.medkits<1)return 0;
        const healed=Math.min(45,100-s.health);s.medkits--;s.health+=healed;return healed;
    }
    function damage(s,amount) {
        if(!Number.isFinite(amount)||amount<=0||s.sim<s.damageUntil||s.health<=0)return null;
        const protectedRide=s.rides.riding&&s.rides.helmet;
        const lost=Math.min(s.health,Math.max(1,Math.round(amount*(protectedRide?.65:1))));
        s.health-=lost;s.damageUntil=s.sim+2.25;s.stats.trafficHits++;
        s.rides.riding=false;
        return {lost,knockedOut:s.health===0,protectedRide};
    }
    function recover(s) {
        const fee=s.dev?.unlimitedMoney?0:Math.min(s.cash,60);MZLife.pay(s,fee);s.health=60;s.damageUntil=s.sim+6;
        s.rides.riding=false;s.stats.knockouts++;return fee;
    }
    /** Relative swept segment vs oriented taxi box. Detects high-speed crossings,
     * not just frame-end overlap. Call with old==new on a wrapped traffic spawn. */
    function trafficHit(p0,p1,c0,c1,radius=.32) {
        const rot=c1.ry||0,C=Math.cos(rot),S=Math.sin(rot);
        const local=p=>({x:p.x*C-p.z*S,z:p.x*S+p.z*C});
        const a=local({x:p0.x-c0.x,z:p0.z-c0.z});
        const b=local({x:p1.x-c1.x,z:p1.z-c1.z});
        let t0=0,t1=1;
        for(const [key,extent] of [['x',1.26+radius],['z',2.36+radius]]){
            const d=b[key]-a[key];
            if(Math.abs(d)<1e-8){if(Math.abs(a[key])>extent)return false;continue;}
            let lo=(-extent-a[key])/d,hi=(extent-a[key])/d;
            if(lo>hi)[lo,hi]=[hi,lo];t0=Math.max(t0,lo);t1=Math.min(t1,hi);
            if(t0>t1)return false;
        }
        return true;
    }
    root.MZMobility={RIDES,motion,step,buyRide,useMedkit,damage,recover,trafficHit};
})(typeof window==='undefined'?globalThis:window);
