'use strict';
/** Shared teaching content and capability-based input selection.
 * Touch availability alone must not turn a mouse-first laptop into phone mode.
 */
(function(root){
 function detectInput(env={}){
  const coarse=env.coarse ?? root.matchMedia?.('(pointer:coarse)').matches ?? false;
  const fine=env.fine ?? root.matchMedia?.('(pointer:fine)').matches ?? false;
  const hover=env.hover ?? root.matchMedia?.('(hover:hover)').matches ?? false;
  const touches=env.touches ?? root.navigator?.maxTouchPoints ?? 0;
  return coarse || (!fine && !hover && touches>0) ? 'touch' : 'desktop';
 }
 const lessons=[
  [['Your new home','The key opens Number Fourteen: your yard, your mixing bench and four planter spaces.','home'],['Meet the neighbourhood','Zanele teaches each system as you use it. Nothing in the story is timed.','person'],['Start small','Your R2500, supplies and first order are already waiting. Click below when you are ready.','wallet']],
  [['Move at your pace','{move} to walk a few steps. You do not need to sprint.','move'],['Look around','{look} Turn until you can see the inside of your yard.','look'],['Follow the gold marker','The gold compass points to your objective. The distance gets smaller as you approach.','map']],
  [['Find Zanele','She is inside your yard, near the front entrance. Follow her gold marker.','person'],['Stand nearby','Walk within a few steps and face her. An interaction prompt appears.','look'],['Say hello','{use} Then choose the conversation response. Menus pause the street.','use']],
  [['Open your backpack','{bag} This shows your cash, supplies and packed stock.','bag'],['Two kinds of items','Supplies go into a recipe. Finished packs are what you sell. They are separate.','leaf'],['Keep room for production','You begin with space for 40 packs. Each running batch reserves up to four spaces.','pack']],
  [['Find the mixing bench','Follow the gold marker inside your yard. {use} when the bench prompt appears.','mixer'],['Choose Original Glow','The green recipe uses 2 imaginary leaves and 3 empty pouches. Choose Prepare a batch, load the tokens, match the blend and seal.','glow'],['Let the batch finish','It takes 10 seconds. The moving-bar bonus is optional. Leaving the bench never cancels your batch.','clock']],
  [['Open Phone','{phone} Sipho has asked for 2 Original Glow packs.','phone'],['Read the order','Check the product name, quantity and payment. Orders do not expire.','pack'],['Track the customer','Press Track customer on Sipho\'s card. The gold compass leads to him.','map']],
  [['Bring two packs','Your first Original Glow batch makes at least three. Two are enough for this order.','glow'],['Meet Sipho','Follow the marker to the pavement near the square. {use}','person'],['Deliver, do not negotiate','Click Deliver order. Sipho pays the agreed R170 once and your reputation rises.','wallet']],
  [['Visit Sunset Spaza','Nandi sells everything you need. Follow the gold marker across the street.','home'],['Buy a seed','One Glowleaf seed costs R25. It grows six imaginary leaves.','seed'],['Buy the pouch bundle','Six pouches cost R15. Both purchases complete this lesson.','pouch']],
  [['Use the planters','Return to the yard. {use} at the Glowleaf planters.','leaf'],['Plant a seed','Choose a packet and plant it in an empty planter. Optional Mist and Sparkle tasks add leaves. It grows in 35 seconds of active play.','seed'],['Harvest when ready','Return and choose Harvest. Sleeping finishes plants too. Reading a lesson pauses time.','clock']],
  [['Try Moon Mist','At the bench, use imaginary leaves, pouches and Moon dew.','mist'],['Restock if needed','Missing ingredients are marked on the recipe. Nandi stocks the invented ingredients.','dew'],['Find a buyer','Deliver Lerato\'s Moon Mist order or sell a Moon Mist pack to another customer.','wallet']],
  [['Notice attention','The attention meter is a game rule. Trading increases it; time and rest reduce it.','look'],['Take breaks','The bed clears attention. Patrols need sight of you: warnings can become chases, then searches if sight is lost.','home'],['Ask Zanele','Return to her and choose Tell me about attention to complete the lesson.','person']],
  [['Build up R450','Make and sell more batches. The counter tracks your current cash, not lifetime sales.','wallet'],['Visit Bay Hardware','Find Aadil at the hardware shop beside Sunset Spaza.','home'],['Buy the second station','Two batches can run at once. The other upgrades are optional.','mixer']],
  [['Save R1600','Keep enough supplies for another batch. A free grocery job is available at the spaza when money is tight.','wallet'],['Visit Workshop 02','Follow the marker across the main avenue.','home'],['Buy the property','The shutter opens. You gain a mixing slot, dispatch desk and two more home planters.','use']],
  [['Walk inside the workshop','Find the dispatch desk inside, not the property sign outside.','home'],['Hire Kabelo for R650','Your runner sells spare packs every 25 seconds, keeping 15% commission.','person'],['Protect promised orders','Order protection starts ON. He only sells packs beyond the quantities promised in phone orders.','pack']],
  [['Build lifetime sales','Reach R5000 in sales revenue. This is not the money currently in your wallet.','wallet'],['Use the full business','Grow, mix, supply customers and keep extra stock for your runner.','mixer'],['Make it your own','The story has an ending, then free play. No time limit or forced reset.','home']]
 ];
 const hints=[
  'Read at your own pace. Choose Take the keys when ready.',
  '{move} to walk. {look}',
  'Face Zanele inside the yard. {use}',
  '{bag} to inspect your free supplies.',
  'Bench > Original Glow > Prepare > load, match and seal. Wait for your packs.',
  '{phone} > Sipho > Track customer.',
  'Face Sipho > Deliver order. Bring 2 Original Glow packs.',
  'Nandi > Buy 1 seed AND buy the 6-pouch bundle.',
  'Planter > Plant a seed > wait 35 seconds > Harvest.',
  'Mix Moon Mist, then deliver to Lerato or make a street sale.',
  'Talk to Zanele > Tell me about attention.',
  'Earn R450 > Bay Hardware > Second mixing station.',
  'Save R1600 > Workshop 02 > Buy property.',
  'Dispatch desk inside workshop > Hire runner for R650.',
  'Grow, mix and sell until lifetime revenue reaches R5000.'
 ];
 const symbols={home:'home',person:'person',wallet:'wallet',move:'move',look:'look',map:'map',use:'use',bag:'bag',phone:'phone',clock:'clock',pack:'glow'};
 const paths={home:'M4 11L16 2l12 9v18H4z M12 29V18h8v11',person:'M23 9a7 7 0 1 1-14 0 7 7 0 0 1 14 0 M4 30v-3c0-13 24-13 24 0v3',wallet:'M3 7h25v22H3z M3 7V4h21v3 M19 14h11v9H19z M23 18h2',move:'M16 2v28 M2 16h28 M11 7l5-5 5 5 M11 25l5 5 5-5 M7 11l-5 5 5 5 M25 11l5 5-5 5',look:'M2 16s5-9 14-9 14 9 14 9-5 9-14 9S2 16 2 16 M21 16a5 5 0 1 1-10 0 5 5 0 0 1 10 0',map:'M3 6l8-3 10 4 8-3v24l-8 3-10-4-8 3z M11 3v24 M21 7v24',use:'M10 29V12a3 3 0 0 1 6 0v8 M16 18l9 2v9 M10 23l-5-5',phone:'M8 2h16v28H8z M8 7h16 M14 26h4',clock:'M30 16a14 14 0 1 1-28 0 14 14 0 0 1 28 0 M16 6v10l7 4',bag:'M7 10h18v20H7z M12 10V4h8v6 M10 19h12v7H10z'};
 function text(s,touch){const m=touch?{move:'Drag the left joystick',look:'Swipe the right side to look.',use:'Tap USE.',bag:'Tap Backpack',phone:'Tap Phone'}:{move:'Use W A S D or arrow keys',look:'Move the mouse, or hold and drag the street to look.',use:'Press E.',bag:'Press I or click Backpack',phone:'Press P or click Phone'};return s.replace(/\{(\w+)\}/g,(_,k)=>m[k]||'');}
 function svg(id){let p=paths[id]||paths.use;return `<svg class="ui-icon" viewBox="0 0 32 32" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${p}"/></svg>`;}
 function lesson(i,touch){return (lessons[Math.min(i,14)]||lessons[0]).map(([title,body,icon])=>({title,body:text(body,touch),icon:symbols[icon]||icon}));}
 root.MZGuide={detectInput,lesson,svg,hint:(i,t)=>i>=15?'Story complete. Read any lesson again in Phone > Story.':text(hints[i]||hints[0],t)};
})(typeof window==='undefined'?globalThis:window);
