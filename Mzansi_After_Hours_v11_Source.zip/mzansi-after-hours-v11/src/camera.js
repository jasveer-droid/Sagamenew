'use strict';
/** Independent car orbit camera. Input never mutates the vehicle heading.
 * Conservative boom collision keeps the camera out of walls on small streets. */
(function(root){
 const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
 function create(distance=7){return {offset:0,pitch:-.25,distance:clamp(Number(distance)||7,3.5,11),boom:7};}
 function look(c,dx,dy){if(!Number.isFinite(dx)||!Number.isFinite(dy))return;c.offset=Math.atan2(Math.sin(c.offset+dx),Math.cos(c.offset+dx));c.pitch=clamp(c.pitch-dy,-1.03,-.045);}
 function reset(c){c.offset=0;c.pitch=-.25;}
 function zoom(c,n){if(Number.isFinite(n))c.distance=clamp(n,3.5,11);return c.distance;}
 function pose(c,player,motion,world,state,dt=.016){
  const yaw=motion.heading+c.offset,co=Math.cos(c.pitch),so=Math.sin(c.pitch),targetY=1.10;
  const ux=-Math.sin(yaw)*co,uz=Math.cos(yaw)*co,uy=-so;let distance=c.distance;
  for(let i=.3;i<=distance;i+=.14){if(!world.isFree(player.x+ux*i,player.z+uz*i,state,.22)){distance=Math.max(.25,i-.2);break;}}
  c.boom=distance<c.boom?distance:Math.min(distance,c.boom+Math.max(0,Math.min(dt,.1))*8);
  return {x:player.x+ux*c.boom,z:player.z+uz*c.boom,y:Math.max(1.12,targetY+uy*c.boom),yaw,pitch:c.pitch,roll:0};
 }
 root.MZCamera={create,look,reset,zoom,pose};
})(typeof window==='undefined'?globalThis:window);
