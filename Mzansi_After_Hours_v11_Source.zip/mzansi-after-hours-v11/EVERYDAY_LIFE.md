# v11 note: bank approval now precedes opening a business

The job/stock/staffing rules below remain, but the old direct purchase flow is
superseded by CITY_CHOICES.md: apply at the bank, receive approval and then sign
at the business. The loan is restricted to opening costs; contribution comes
from Current. Existing owned firms remain unchanged.

# Everyday Life - play guide

All amounts are fictional rands inside Mzansi After Hours. No external banking,
payment, identity checks or real rewards are involved. No real financial advice.

## Find a job

Open Phone > Jobs. Filter the list, find an employer, and track its counter.
Go inside and use the counter on foot. Press Start this paid shift. Each of the
three cards has a brief and three possible actions: match the correct action,
wait four active game seconds and sign off. Wrong choices cost nothing. Finishing
all three cards pays the displayed wage once, directly into Current; it opens your
empty game account automatically when necessary. Work does not require cash,
stock or business ownership. An owned business cannot also pay you employer wages.

A paid shift can be completed once per employer per game day. Different employers
are available on the same day. No whole day disappears when you accept a shift;
these are short job minigames. You can cancel with no wage, or close the panel and
return later. The work ticket and its timer are saved. You must be at the counter,
on foot, to begin/sign off a card. Timers pause in ordinary solo menus and when
the solo game is closed; they run in the workstation and while exploring.

## Twenty work and ownership opportunities

The opening price buys that fixed location, initially closed and empty. It does
not include stock, first-day operating cost, recruitment or upgrades.

| Workplace | Paid role | Opening | Shift wage | First-day premises cost | Stock unit | Standard sale |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Morning Grind | Coffee shop | R900 | R180 | R18 | R22 | R58 |
| Sunrise Bakery | Bakery | R1,100 | R200 | R20 | R28 | R72 |
| Corner Basket | Mini supermarket | R2,000 | R240 | R30 | R40 | R92 |
| Fresh Spin | Laundry | R1,400 | R220 | R22 | R18 | R76 |
| Ubuntu Auto Care | Vehicle workshop | R3,200 | R320 | R42 | R55 | R160 |
| Shine & Go | Car wash | R1,300 | R190 | R20 | R16 | R65 |
| Signal & Screen | Electronics repairs | R2,400 | R280 | R32 | R38 | R130 |
| Fresh Cut Studio | Barber & salon | R1,600 | R230 | R25 | R20 | R92 |
| Thread & Needle | Tailoring studio | R1,800 | R250 | R28 | R30 | R118 |
| Petal Street | Florist | R1,000 | R180 | R18 | R24 | R70 |
| Parcel Point | Courier counter | R2,200 | R270 | R30 | R26 | R108 |
| Phezulu Print | Print & copy shop | R1,900 | R230 | R26 | R25 | R96 |
| Pedal Works | Bicycle workshop | R2,000 | R250 | R28 | R32 | R110 |
| Clean Sweep | Cleaning service | R850 | R170 | R16 | R14 | R62 |
| Green Hands | Garden service | R1,200 | R210 | R20 | R18 | R78 |
| Lens & Light | Photo studio | R2,600 | R290 | R32 | R36 | R138 |
| Mzansi Fitness | Fitness studio | R3,000 | R280 | R38 | R30 | R136 |
| Open Book | Books & stationery | R1,500 | R220 | R22 | R24 | R82 |
| City Stay | Guesthouse | R4,500 | R340 | R55 | R60 | R195 |
| Fresh Market | Fruit & vegetable stall | R750 | R160 | R14 | R16 | R52 |

## A practical first business

A new solo game starts with R2,500 pocket cash. Open Banking and deposit R2,000,
leaving R500 in your pocket. At Morning Grind, sign the R900 opening agreement,
order 5 stock units for R110 and pay R18 to open. Current now contains R972.
Serve one customer through the three work cards: one unit is consumed and R58
appears in the till. Select Bank till to move it to Current, now R1,030. The
remaining stock is four units. There are no random wage failures or automatic
loans. These numbers use default pricing with developer cheats off.

A business is separate from your original Glowleaf inventory. Stock units represent
that business's supplies. Staff customers are abstract timed orders: there is not
a fully simulated physical queue or a full animation of every service.

## Operating your business

Stock is delivered immediately after payment from Current. Capacity is 40, 50 or
60 units at levels 1, 2 or 3. A manual order reserves one unit until it is served;
cancelling returns that unit once. Supplier orders account for that reserved unit.

Open each game day by paying the displayed premises cost and R45 per assistant.
Reopening on the same day does not charge the same cost twice. Adding a worker
or upgrading after paying can leave a small, explicitly displayed difference to
pay. A new day closes the shop: review costs and reopen. Closed shops charge
nothing. Running out of stock also closes a shop. Wages/costs are game rules,
not South African tax, labour or banking rules.

Recruitment costs R200 per assistant. Close the shop before recruiting, changing
prices or upgrading. Maximum assistants equals the premises level. Assistants
serve while the game runs, at one unit every approximately 55/38/85 active seconds
on Standard/Value/Premium, divided by the number of assistants. They cannot serve
without stock or paid daily costs. Manual service pauses automatic orders at that
particular counter so the same stock is not sold twice. In co-op the shared server
continues running while connected players have menus open; when no member is
active it does not grant offline income.

Value pricing pays 85% of base; Premium pays 120%. Levels 2 and 3 multiply base
sale value by 1.10 and 1.20, before the selected pricing factor is applied. Each
upgrade adds R5 to daily premises cost. Displayed
amounts are rounded whole rands. Upgrading costs 45% of initial opening price times
the current level, rounded. Level 3 is the maximum. Higher prices trade a longer
staff-sales interval for a higher return; the game does not model a live external
market or claim that premium is always the best business choice.

Use Phone > Businesses > My businesses to manage the portfolio remotely. Starting
physical work, signing an opening agreement, and serving require a counter visit.
Supplier orders, banking, hiring, prices, opening/closing and till collection work
remotely. The original map name stays unchanged when you rename a business.

The displayed cash result includes setup, suppliers, recruitment, operating costs
and upgrades. It is NOT an accounting statement of profit under real-world rules.

## Banking

Current pays enterprise expenses and receives wages and collected takings. Savings
is a separate, non-interest-bearing game balance with an optional goal. Pocket cash
pays the existing older shops, food and vehicles. Move money as needed using the
phone's Banking app, the branch or the ATM. For convenience, the game allows
virtual pocket-cash transfers from the app; no real physical deposit is simulated.
All transfers require sufficient source funds, whole positive rands, and remaining
space under a one-billion-rand game balance cap. Transfers cannot create money.

Statement lists the latest 250 bank/business events, their origin/destination and
resulting account balances. Export statement produces a JSON file. The History
app independently retains the latest 200 game events. Savings goals never earn
interest. No loans, P2P payments to other rooms, payment cards, passwords, real bank
logins or real financial integrations were added.

Developer Unlimited money can waive new business costs in solo mode, but it cannot
move cash that does not exist between accounts. Shared rooms disable that cheat.

## Working with a friend

Both players use the same co-op server and room. Current, Savings, till balances,
stock, businesses and job progress are shared. One work ticket exists for the team;
either member can complete its next card at the right workplace. The other player
can still manage another shop, trade, drive or explore. There are no separate
salaries/accounts per member or transfers between unrelated rooms. Leaving restores
the separate solo save. Keep private server storage backed up when updating.

## Saves and phone controls

Version 9 accepts v1-v8 saves without replacing their existing cash, rides, story
or outdoor progress. Their new enterprise section starts empty. Export before
updating. The same browser and server address use the same local save; a different
browser/address, private browsing or clearing site data can lose/separate saves.
Keep a JSON backup. This is not automatic cloud synchronisation.

The new panels use the existing mobile-fit shell: scrolling content, visible close
controls, and a fixed work sign-off button. No device-model selection is required.
Physical-phone certification and native storage durability are not claimed by the
included automated test suite.
