# Mzansi After Hours v11 - City Choices

Original single-player and two-player browser game set in a fictional South
African-inspired neighbourhood. Editable HTML/CSS/JavaScript, procedural WebGL
art and optional dependency-free Node servers. No commercial game assets,
external runtime downloads or real payments are included.

## Launch

With Node.js 18+ installed, open a terminal in this extracted folder:

```sh
npm start          # computer browser, address printed in terminal
npm run mobile     # phone access on the same trusted Wi-Fi
npm run play       # start server and request desktop browser opening
npm run coop       # phone access plus two-player room service
npm run analytics  # optional, opt-in player statistics service
```

No `npm install` is needed to play. Keep the computer/server running. Use the
printed Phone address on your phone, not localhost. Windows desktop shortcut:
`START_GAME_WINDOWS.bat`; co-op shortcut: `START_COOP_WINDOWS.bat`. The server must
be allowed on your trusted private network by your computer's firewall. Do not
expose an unprotected development server directly to the public Internet.

`Mzansi_After_Hours_v11.html` is the self-contained solo alternative. Directly
opening downloaded files and retaining storage is browser-dependent. A stable
server address is preferable for regular phone play. There is no deployed public
link, APK/IPA, account login or automatic device-to-device save synchronisation.

## What v11 adds

- Career greeting: work, apply for a business, continue, or guided story.
- In-person bank applications, timed yes/no decisions with explanations,
  restricted opening finance, and manual loan repayment from Current.
- Enterable Sundown Social Casino: European single-zero roulette, six-deck
  blackjack and a three-reel slot with a published 94% theoretical return.
- In-game bar drinks with first-person cup animation and saved casino history.
- Leaf Lounge: custom-quantity fictional joints, flower and packaged inventory.
- Ubuntu Custom Works: seven engine choices across ten cars, tuning components,
  removable body groups/four wheels, a parts locker and mechanical readiness checks.

**Read [CITY_CHOICES.md](CITY_CHOICES.md) for locations, exact rules, prices,
loan conditions, blackjack variants, slot paytable, limits and controls.**

All casino wagers, loans and shop purchases use fictional game money. There are
no real-money deposits, cash-outs, prizes, real-bank links or real product orders.
The garage is modular, not BeamNG full soft-body physics or photorealistic graphics.

## Existing game retained

The fifteen-chapter teaching story, Free Roam, seven districts, forty customers,
twenty workplaces/owned businesses, Current/Savings, growing fictional Glowleaf,
production, restaurant seating/eating, outdoor activities, first-person walking,
jumping, three light rides, ten cars, free-look driving, health/traffic incidents,
police encounters, named atlas, phone, local saving and trusted-friend co-op remain.

Desktop: WASD move/drive; mouse/drag look; Shift sprint; E interact; P phone;
I inventory; M map; G rides; V mount/off; Space jump or car handbrake; C reset car
camera; Esc menu. Touch: left joystick, swipe uncovered world to look, USE,
RUN, JUMP/BRAKE, RIDE/OFF, phone/menu buttons. Available actions depend on context.

## Updating and saves

Export the old solo JSON before updating; close old tabs and old server. v1-v10
save data migrate to schema 11. Existing money, businesses and cars are retained.
Return using the same browser/profile and address; clearing website data, private
mode and changing hosts can remove or separate local saves. Keep JSON backups.

Co-op has a separate shared business. Back up and retain the private server
room directory before switching project folders. See `COOP_HOSTING.md`. A solo
save export cannot substitute for server room storage. Room codes work only on
the same reachable server. No public hosting is included.

## Development

```sh
npm run build      # regenerate the self-contained HTML + BUILD_INFO.json
npm test           # current deterministic rules, actual HTTP and package tests
npm run test:v11   # v11 rules and actual room-server transactions only
```

All production modules are under `src/`. `index.html` loads them directly; the
build script inlines the same files into the standalone HTML. Do not hand-edit
only the generated HTML. Edit the sources and rebuild.

New modules: `nightlife.js` (shared pure rules), `nightlife-panels.js` (UI),
`nightlife-world.js` (walk-in locations/animation), `nightlife-garage.js` (mesh
partitioning). The original `commerce`, `storage`, `travel`, `car-world`, `game`
and co-op modules integrate those systems. `AGENTS.md` records invariants for
VS Code/Cursor/Claude or another coding assistant.

Optional browser checks need Python Playwright and Chromium with working WebGL.
On Linux with Xvfb:

```sh
xvfb-run -a python tests/v11_browser.py
xvfb-run -a python tests/v11_coop_browser.py
xvfb-run -a python tests/browser_smoke.py
xvfb-run -a python tests/safety_smoke.py
xvfb-run -a python tests/native_launch.py
```

Browser tests in this environment use `set_content`, an explicitly test-only
memory storage adapter and, for co-op, a test-only Fetch bridge to a real HTTP
service. They are not native hosted/phone certification. No adapter, enabled
GameDebug flag or bridge is shipped in normal gameplay. Current results and
limitations: `TEST_REPORT.md`. Only the supported browser entrypoints above are included in this delivery.
Older-numbered Node rule suites remain part of the current regression run.

## Scope and deployment

This is a playable browser prototype, not a bug-free certification, full driving
simulator, real financial/casino service or production multiplayer backend.
The file-backed server targets two trusted friends per room. Health/physics and
crowd reactions are not fully server-authoritative. For public deployment,
review authentication, backups, abuse/rate limits, TLS and privacy requirements.
See `COOP_HOSTING.md` before hosting. Optional player statistics stay off until
players opt in; the gameplay developer code is not the server admin token.

The user's target device is a Samsung S26. Physical-phone performance, native
browser restart persistence, browser-specific fullscreen and public-Internet
co-op still need real-device testing. A graphics setting is not an FPS guarantee.
