# Mzansi After Hours v11 - City Choices
## Executed checks and limitations

**23 October 2026.** This is a record of executed checks, not a guarantee of
no bugs, physical-phone certification, BeamNG equivalence, real casino/banking
certification or production public multiplayer security.

## Final results

| Suite | Passed | Failed | Evidence |
| --- | ---: | ---: | --- |
| Node rules, saves, actual static/co-op HTTP, optional analytics and packaging | 566 | 0 | `test-results/v11-all-node.txt` |
| New City Choices desktop/mobile integration | 116 | 0 | `test-results/v11-browser-results.json` |
| New two-browser shared bank/casino/parts integration | 21 | 0 | `test-results/v11-coop-browser-results.json` |
| Retained full teaching story and desktop/touch regression | 73 | 0 | `test-results/browser-results.json` |
| Storage denial, focus and WebGL recovery | 8 | 0 | `test-results/safety-results.json` |
| **Total counted checks** | **784** | **0** | |

The Node total includes nested tests and the optional analytics suite. Pure
casino/finance/parts tests, the actual v11 room API checks and archived earlier
feature rules are included in that number, not counted separately. Repeated
runs, probes, old v10 release results and blocked native URL attempts are NOT
added to the total. The slot enumeration checks all 8,000 outcomes inside one
test assertion; it is not advertised as 8,000 independent integration tests.

The final four-browser-suite loop loaded the same frozen standalone file. Its
start/end hash and exit status are in `test-results/v11-release/`. The completed
runs recorded no uncaught JavaScript exceptions and passing concluding WebGL
checks. The production JavaScript and Node tools passed syntax checking. Screenshots
were inspected for actual menu layout and car/casino rendering.

**Standalone:** `Mzansi_After_Hours_v11.html`  
**Bytes:** 679583  
**SHA-256:**

```text
9cffe6e69715da244ace86e2c9a6cfca4e4df60d73dcc19241865b9568cfb099
```

This is also the hash in BUILD_INFO.json. The generated standalone contains no
external runtime downloads, enabled test flag, memory-storage adapter or Fetch
bridge. Its editable `index.html` loads the same production modules. Optional
Node co-op/statistics servers are separate runtime services.

## Career greeting, applications and finance

The actual start button opens the Work/Business greeting without replacing
starter money. Tests choose Work, open the job directory and keep the balance;
choose Business and track the bank; and restore an existing solo save with the
Continue choice. Story mode can still be selected and the retained campaign
suite reaches its ending through real gameplay actions.

At the branch, UI tests open Current, submit an insufficient-contribution
application, observe the stated refusal, submit a corrected application and
observe approval. The production review timer is twelve seconds of active
simulation. The single-player harness advances simulation to inspect boundaries;
the two-browser server integration waits for the real timer. Pure tests verify
no premature approval, a 20% contribution requirement, available funds, existing
ownership, the rapid-plan work requirement, one outstanding loan and repeat-use
rejection. Every one of the twenty premises passes a self-funded approval/opening
cycle in the rule suite.

Signing at the actual business counter charges the contribution, creates a
restricted loan plus the one-time rounded-up 5% game fee, and opens the firm.
Loan money never appears as spendable cash or Current. Repayment debits Current
exactly. Refused applications do not charge. Existing owned shops are retained;
other existing business, bank, supply and daily-job tests remain in Node coverage.
The original debit/statement tests also cover developer waivers and no negative
balances. No real loan, real banking connection, compounding interest, credit
score, automatic default or offline debt penalty is implemented.

## Casino mechanics and persistence

Roulette tests inspect zero and all supported categories/picks, correct total
returns and rejection of invalid wagers without mutating the balance. Supported
variants are listed in CITY_CHOICES.md. The game uses single-zero European
roulette with standard straight/even-money/dozen/column returns, not every
possible inside bet.

The slots test exhaustively enumerates three independent 20-stop reels and
confirms the exact 94% theoretical return and the published non-overlapping
paytable. It does not guarantee a player's session return. Random integer draws
use rejection sampling over crypto.getRandomValues; the server's rule context
uses Node webcrypto. Test-only deterministic random providers exercise particular
outcomes without replacing production randomness.

Blackjack rules are tested for ace scoring, dealer soft-17 stand, natural 3:2,
initial blackjack settlement, win/loss/push, hit/stand/double, a single equal-rank
split, split aces, no resplit and saved paid stakes. Six shuffled copies of each
card are verified. Stakes and extra double/split stakes count toward the saved
game-day wager limit. Another table cannot bypass an unfinished hand. Actual UI
buttons deal and settle; a separate fresh application restores the same paid
hand and cards instead of refunding or rerolling. The latest 60 rounds persist.

All stakes use finite fictional pocket cash, even when the solo developer
purchase waiver is enabled. Test fixtures reject invalid/negative/fractional and
over-budget stakes. There is no autoplay, monetary deposit, cash-out, prize
exchange or connection to a real casino/payment service. Neither the editable
solo save nor this trusted-friend server is an audited real-money gaming system.

## In-game shop and drinks

Every shop item and drink is tested for exact debit/quantity, purchase limits,
storage bounds, wrong location, invalid fractions and saved inventory. UI tests
purchase three joints and 3.5 grams (seven fictional half-gram packs), then reject
0.1 grams without charging. An actual touch order also records exact quantities.
The new collectibles are separate from the original crafted sale products.
Consumption/resale of the new shop items is not implemented. No real suppliers,
real purchases, preparation instructions or real substance quantities are advised.

A bar order deducts once and starts the first-person cup/hand animation without
changing health. The renderer is checked for errors. These are cosmetic game
drinks: no intoxication, impairment, health benefit or driving advantage is
modelled. New non-casino purchases honour the solo developer cost waiver; bank
contributions/repayments and casino stakes do not. Loading a normal save does not
restore developer authorisation. Co-op disables client purchase cheats.

## Modular garage and retained driving

Each of the ten existing cars is checked with all seven listed engine choices.
Tests buy conversion kits once, remove/refit for free, preserve ownership on
restore, and reject invalid or unaffordable actions. The same road input produces
a higher simulated acceleration with the V8 than stock. Other components change
the actual tuned acceleration, braking or grip inputs.

All car meshes have six nonempty removable body groups and four distinct wheel
indices. Actual browser clicks remove a bonnet and change the rendered preview;
mobile taps remove a door group. World drawing uses the same visibility filters.
A missing engine, transmission, brakes, suspension, tyres or wheel prevents both
mounting and the driving solver from moving the car. Refitting restores driving,
which is exercised with real keyboard acceleration. Owned kits, installed parts
and removed panels restore in a separate application instance.

**This is not full BeamNG soft-body physics.** Cars still use the retained rigid
planar contact footprint with an anchored visual damage cage. Added parts are
modular render groups, not individual collision bodies or a complete node/beam
vehicle structure. There are no dynamically tearing joints, detached parts
following collision trajectories, full suspension contacts, rollover simulation,
actual engine mounting measurements or photorealistic material assets. Listed
engine conversions fit every game car as an intentional fictional simplification;
this is not a claim that any real engine physically fits any real car.

## World reachability and mobile layouts

Seven new interaction points (casino entrance, roulette, blackjack, slots, bar,
garage and shop) have collision-free approaches. A flood fill through the actual
world collider grid finds an approach from the original neighbourhood. This does
not prove every path is driveable at every speed. New buildings are enterable and
render original procedural tables, cabinets, shelves, workshop/car display and
interior lights. The named atlas and phone expose the new locations. A real taxi
button charges R20 and arrives safely at the After Hours stop; Riverside Commons
and Harbour Works are also listed in the taxi menu.

Eleven new panels are measured at 280x640, 320x480, 360x640, 390x844, 844x390,
568x240 and 768x1024 CSS pixels. Tests check actual bounds, horizontal overflow,
close-control visibility and whether the last action can scroll into view. Real
emulated touch events settle a roulette bet, buy shop quantities, remove a car
part and order a waived developer drink. Retained touch movement/looking and core
controls are checked. Screenshots are actual controlled test states, not concept
art or measurements from the user's Samsung S26.

## Two-player shared business

Actual Node HTTP tests exercise authenticated room commands, location checks,
review decisions, borrowing and repayments, shared shop/drink/configuration
changes, table outcomes, repeat-request receipts and server persistence. The
server redacts undealt blackjack cards and the dealer hole card. Only the acting
member may play the live hand. Explicitly leaving automatically stands that
member's unfinished hands and settles them, preventing a blocked shared table.

Two separate headed browser contexts (desktop and touch-emulated) then create
and join a password-protected room through the actual UI. They buy a car, open
Current, apply for finance, wait for review, sign at the business, play roulette
and slots, deal/stand blackjack and reject an action by the other member. They
share bonnet/engine removal and refitting and shop quantities. Only the drink
purchaser receives the cup animation. Leaving restores the original solo money,
while the partner keeps the shared financed business and modified car.

Because native browser navigation is blocked here, a **test-only Python Fetch
bridge** forwards unchanged client requests to the real local HTTP room server.
This is not a native same-origin/HTTPS/mobile Wi-Fi/public Internet deployment
check. Shared finance/casino/configuration rules are server-controlled, but crowd,
health and physical driving remain personal simulations. No public server or
production anti-cheat/abuse certification is provided.

## Environment and explicitly unverified behaviour

Node.js 22.16.0, Chromium 144.0.7559.96 on Linux, Python Playwright, headed Xvfb
and SwiftShader software WebGL. Browser suites load the generated standalone
using page.set_content on about:blank with an explicitly test-only memory
localStorage adapter. Save restoration is application-level serialisation into
another fresh page, not native persistence after a real browser or phone restart.

Actual navigation to the standalone file URL and the real local HTTP server was
attempted and returned **ERR_BLOCKED_BY_ADMINISTRATOR** for both. See
`test-results/native-launch-results.json`; these are limitations, not passes.
Actual server file/API responses were tested independently with Node HTTP.

Not verified: physical Samsung S26/Android/iPhone, Safari/Firefox/Edge-specific
behaviour, native installed web-app lifecycle, service-worker update/offline
cache durability, browser restarts, real keyboards/notches/toolbars/fullscreen,
public Internet latency/TLS/hosting, low-memory graphics hardware, battery/thermal
behaviour, sustained FPS, multi-hour soak play or all possible gameplay paths.
Test travel/funds/time and some randomness are controlled fixtures; the story
check is not a normal-duration unassisted human playthrough.

## Issues discovered and corrected

- The original new co-op menu wrapper called a nonexistent `coop.command` method.
  The two-browser test caught it; it now calls the existing ordered `coop.send`.
  The corrected two-client workflow was rerun successfully.
- A member leaving during blackjack could otherwise leave a blocked table.
  Explicit leave now stands and settles; the API test covers this and public
  shoe/hole-card redaction.
- The new-greeting Story choice needed to reset the chapter-seen flag before
  reopening a lesson. The retained full campaign now passes that flow.
- The existing taxi UI did not list its new stop (or two retained outdoor stops).
  All three are now listed and the actual After Hours ride is exercised.
- New purchases initially missed the solo developer cost waiver. Non-casino
  purchases now honour it, without waiving wagers or bank repayments.
- The first draft of a phone-shortcut assertion expected an older garage label;
  it was corrected to the actual new business name. The first co-op harness also
  assumed an unsaved solo state already existed; it now creates a real solo save.

Initial failed browser logs/results remain under `test-results/v11-initial/`;
they are not counted as passing checks. Old exploratory/rerun logs are not added
to the release total. None of the production changes creates a publicly hosted
service or validates BeamNG-level physics.

## Reproduce

```sh
npm run build
npm test
xvfb-run -a python tests/v11_browser.py
xvfb-run -a python tests/v11_coop_browser.py
xvfb-run -a python tests/browser_smoke.py
xvfb-run -a python tests/safety_smoke.py
xvfb-run -a python tests/native_launch.py
```

Browser dependencies are optional development tools, not required for playing.
On the actual target phone, verify a normal session, full close/reopen at the
same address, saved money/parts/hand, menu scrolling/rotation, car performance,
and both co-op clients before a public release. Keep a JSON and room-data backup.
