# Mzansi After Hours v10 - Roadcraft

## Start here

Export your v9 solo save before changing versions. Close the old game and server.
Extract the full source ZIP. With Node.js installed, run `npm run mobile` and open
the printed Phone address on the same trusted Wi-Fi. Keep the server running.
Use `npm run coop` instead for two-player rooms. `npm run play` opens the desktop
address. No npm packages are needed to play or run these servers.

The standalone `Mzansi_After_Hours_v10.html` is the solo/offline alternative.
Browser support for opening a downloaded file and keeping its local storage
varies; a stable server address is preferable for regular saved play. Keep a JSON
backup before moving to a different browser or address. No public server or
cloud save account has been deployed.

## The ten-car collection

Open **Map**, search **Ubuntu Motors**, and track the dealership. You can also
open **My rides -> Visit Ubuntu Motors**. The showroom has ten distinct original
models. Its cards show the actual in-game model, not an unrelated concept image.
The original skateboard, bicycle and electric scooter remain at Ubuntu Wheels.

| Vehicle | Style | Drive | Purchase price | Game speed cap |
| --- | --- | --- | ---: | ---: |
| Sundown City | City hatchback | FWD | R4,500 | 65 km/h |
| Ubuntu Hauler | Bakkie | RWD | R8,000 | 76 km/h |
| Karoo Executive | Saloon | RWD | R6,500 | 90 km/h |
| Cape Veloce | Sports coupe | RWD | R14,500 | 122 km/h |
| Drakensberg Trail | Family SUV | AWD | R12,000 | 86 km/h |
| Ubuntu Cargo | Delivery van | FWD | R10,500 | 76 km/h |
| Sundown Shuttle | Minibus | RWD | R16,000 | 83 km/h |
| Sundown Rally | Rally hatch | AWD | R18,500 | 104 km/h |
| Protea Classic | Classic coupe | RWD | R9,500 | 94 km/h |
| Jozi Current | Electric GT | AWD | R22,500 | 115 km/h |

All names, specifications, prices and caps are invented game values. These are
not licensed real-world cars. The minibus and van are drivable vehicle styles;
this update does not add passengers, an independent cargo inventory or taxi fares.
Money for cars and roadside repairs comes from **pocket cash**, not Current. Use
the bank to withdraw wages or business income before buying a car.

## Drive and look around

| Action | Desktop | Touch phone/tablet |
| --- | --- | --- |
| Accelerate | W | Joystick forward |
| Steer | A / D | Joystick left/right |
| Brake; reverse once stopped | S | Pull joystick backward |
| Handbrake | Hold Space | Hold BRAKE |
| Look independently | Mouse, or hold and drag world | Second finger swipes uncovered world |
| Reset camera behind car | C | Reset arrow beside speedometer |
| Change viewing distance | Mouse wheel / VIEW | VIEW |
| Get in / out | V | RIDE / OFF |
| Open owned rides | G | Rides menu |

The speedometer shows km/h, a forward gear indicator or reverse, and the selected
car's condition. The gear/RPM values are simplified game telemetry, not a
simulated clutch, gearbox or torque converter. Independent camera orbit is
preserved: looking around never steers the wheels.

Cars do not jump on demand. Space / the mobile action button still jumps when
on foot, skateboarding, cycling or riding the small scooter.

## Driving setup

Open **My rides -> Driving setup / surface & grip**, or use the same option in
**Settings**. The setup can be read before starting a game.

**Assisted** is the default. It settles lateral sliding more strongly. **Sport**
turns that assistance off so more sideways momentum remains. This is a simple
stability aid, not a full ESC/ABS system.

**Dry / Wet roads** changes asphalt grip and the wet visual sheen. Wet roads
need more braking room. This is a road-condition option, not rain or a full
weather simulation. Paving, forecourts and loose ground have separate grip,
rolling resistance and surface vibration. AWD vehicles get a modest loose-ground
advantage. The electric GT has extra deceleration when coasting.

Different cars have individually tuned acceleration, brakes, steering, wheelbase,
grip and spring response. The van/minibus turn and stop differently from the
sports coupe. Displayed mass is a design specification; the solver uses tuned
acceleration/braking rather than a complete mass distribution and drivetrain.

## Crashes and repairs

An impact above the low-speed threshold damages the front, rear, left or right
bodywork. The shell visibly folds inward and settles through its spring-linked
cage. The condition number falls, acceleration/top speed reduce and one-sided
damage can pull the steering slightly. Player health and existing pedestrian
injury/police rules still apply. A cooldown prevents a single contact from being
charged as a crash on every simulation substep.

Dents stay when you get out, change rides, save or reload. Select the damaged
owned car in My rides, **stop**, then open Driving setup and choose
**Roadside repair / R180**. This is a service action, not a simulated tow-truck
arrival. It restores bodywork and performance. An undamaged car cannot be charged
again; insufficient pocket cash cannot put the wallet below zero. Repairing does
not heal the driver. Use the existing health/restaurant/home options for that.

## What changed visually

The cars now have more shaped body panels, sloped cabins, window pillars, door
seams, handles, mirrors, model-specific lamps, grille details and licence plates.
Their four wheels spin, the front pair steer and the body/wheels respond to the
simplified sprung motion. Pickup bed, long van/minibus body, classic chrome,
rally spoiler/lights and electric panoramic roof distinguish the models.

Paint and glass use procedural highlights and a sky-colour approximation. There
is a soft under-car contact shadow, temporary skid marks, wet-ground sheen and
an approximate night headlight beam. No external texture/model download is
required. Existing Performance/Balanced/Sharp graphics choices remain. Only the
currently driven car keeps an active deformation skin, and its spring simulation
sleeps after settling; saved dents are retained when swapping vehicles.

## BeamNG comparison - important limits

This update is inspired by the *direction* of more responsive driving and visible
crash damage. It is **not BeamNG.drive**, and does not incorporate BeamNG code,
vehicle assets or physics.

The car's solid contact still uses a rigid oriented footprint on a largely flat
map. A 63-node, 338-link anchored visual cage deforms bodywork according to four
persistent crush zones. It is not an entire vehicle made of independently
simulated structural nodes. The spring response provides body lean and wheel
motion; it is not a wheel-contact suspension/uneven-terrain dynamics model.

There is no rollover, crumpling collision hull, detachable parts/wheels, shattered
glass, engine/tyre destruction, full powertrain, physical passenger, ray tracing,
photo-real material library or BeamNG-level soft-body fidelity. Highlights are
not captured environment reflections. Cars remain stylised procedural 3D. A
fuller simulation would require substantial further engine, asset and performance
work; this build makes the improvements listed above without promising parity.

BeamNG's official explanation of its own system (reference, not incorporated code):
https://www.beamng.com/game/about/physics/

## Saves and co-op

v1-v9 solo saves migrate to schema 10. Money, Current/Savings, inventory, shops,
story, owned rides and other progression are retained. New-car ownership, per-car
dents and driving preferences save too. Reloading starts safely on foot rather
than resuming a moving car. The same browser/profile and game origin are required
for automatic continuation; exporting/importing moves saves explicitly.

Co-op retains its separate shared business. Buying a new car unlocks it for the
team. Each driver's motion, damage, wet-road preference and stability setting
remain personal. Repairs cost the shared wallet and use ordered server receipts
so a retried request cannot charge twice. Damage is not a fully authoritative
network simulation: the server is designed for two trusted friends, not public
anti-cheat competition. The other player sees the selected vehicle and movement,
not an identical live deforming mesh/crowd physics state.

Back up and retain the private co-op room directory when updating the server;
read COOP_HOSTING.md. Merely copying a solo save does not copy a room. Enter a
room code only on the same reachable server; no public hosting was performed.

## Tests and reproducibility

Run `npm run build`, then `npm test` for deterministic rules, migrations,
transactions, real local HTTP server checks and co-op rules. Optional browser
tests additionally need Python Playwright, Chromium and an available display:
`xvfb-run -a python tests/v10_browser.py` on Linux.

See TEST_REPORT.md for exactly what was run on this build. Automated/browser
emulation checks do not certify physical phones, native browser persistence,
frame rate, public-Internet co-op or every possible gameplay sequence.
