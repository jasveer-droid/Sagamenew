'use strict';
const CACHE = 'mzansi-story-11.0.0';
const ROOT = new URL('./', self.location.href);
const FILES = ['src/nightlife.js','src/nightlife-panels.js','src/nightlife-world.js','src/nightlife-garage.js','src/commerce-data.js','src/commerce.js','src/commerce-world.js','src/commerce-panels.js','src/camera.js','src/people.js','src/activities.js','src/outdoor-world.js','src/outdoor-panels.js','index.html','src/style.css','src/data.js','src/neighbourhood.js','src/story.js','src/storage.js',
  'src/life.js','src/police.js','src/interiors.js','src/metrics.js','src/life-panels.js','src/device.js','src/mobility.js','src/ride-world.js','src/engine.js','src/visuals.js','src/guide.js','src/expansion.js','src/world.js','src/touch.js','src/layout.js','src/atlas.js','src/coop.js','src/travel-panels.js','src/vehicle-dynamics.js','src/travel.js','src/car-world.js','src/game.js','src/platform.js',
  'manifest.webmanifest','assets/icon.svg','assets/icon-192.png','assets/icon-512.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES.map(file => new URL(file, ROOT).href))));
  // Updates activate after existing game tabs close, not halfway through a save.
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('mzansi-story-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== ROOT.origin || !url.pathname.startsWith(ROOT.pathname)) return;
  if (url.searchParams.has('debug') || url.pathname.includes('/api/')) return;
  event.respondWith((async () => {
    if (event.request.mode === 'navigate') {
      try { return await fetch(event.request); }
      catch (_) { return (await caches.match(new URL('index.html', ROOT).href)) || Response.error(); }
    }
    return (await caches.match(event.request, {ignoreSearch: true})) || fetch(event.request);
  })());
});
