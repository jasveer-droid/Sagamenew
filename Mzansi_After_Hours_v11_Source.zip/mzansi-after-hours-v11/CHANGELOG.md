# 11.0.0 - City Choices / 23 October 2026

Career greeting; bank review/yes-no decisions and restricted business finance;
European roulette, six-deck blackjack and 94% three-reel slot; casino history
and cosmetic drinks; quantity-based fictional retail; modular garage/engine
conversions; visible removable body groups and wheels; save and co-op integration.

No BeamNG-equivalent structural physics or photorealistic renderer was added.
See CITY_CHOICES.md and current TEST_REPORT.md for exact scope and evidence.

# v10.0.0 - Roadcraft / 21 October 2026

- Added eight original cars: saloon, sports coupe, family SUV, delivery van,
  minibus, rally hatch, classic coupe and electric GT. Remodelled both old cars;
  retained three light rides, all old ownership and the in-game dealership.
- Tuned acceleration, braking, steering inertia, tyre slip and surface grip.
  Added selectable assistance and wet roads; saved preferences.
- Added a bounded spring-linked visual body cage, persistent four-zone dents,
  damage-dependent handling, condition display and R180 stationary repair.
  Chassis/collision remains rigid. Not BeamNG-equivalent full soft-body physics.
- Added shaped cabin/body details, material highlights, independent spinning and
  steered wheels, spring-response body motion, contact shadow, transient skid marks
  and approximate night headlights. Stylised artwork; no photorealism claim.
- Expanded the showroom and added readable driving/service instructions; kept
  responsive touch/desktop controls, free camera orbit and current-speed display.
- Save schema 10 migrates older saves; bank, jobs and businesses retained.
  Co-op shares new purchase unlocks and sequenced repairs, with personal dents.
- Tests include all new cars, deformation bounds, save migration, genuine local
  HTTP co-op transactions and responsive browser integration. See TEST_REPORT.md
  for completed results and explicit limitations, not historical totals.

---

# v9 - Everyday Life (20 October 2026)

- Enterprise Quarter: 20 open-door business interiors, branch/ATM/careers centre.
- Twenty paid daily workflows, three validated timed work cards each.
- Own, name, stock, open/close, serve, staff, price and upgrade every new business.
- Game banking: current/savings/pocket cash, savings goal, statements and export.
- Expanded bounds/streets/navigation/taxi; preserved forty original customers.
- Shared server-owned enterprise/accounts/work tickets, idempotent transactions.
- Schema 9 migration, pending-job save/reload, new business/bank/job history.
- Mobile scrolling forms and fixed job completion controls; menu world redraw cap.
- Portable source, deterministic/API/browser checks and explicit test limits.

# 8.0.0 - Living Streets

Independent car camera; mouse/wheel and two-pointer touch; reset/presets; articulated
crowds, local routines, non-graphic recoverable NPC impacts; Riverside Commons and
Harbour Works; 40 customers and 10 roads; basketball, recycling, parcels, postcards
and garden rest. Shared outdoor rules and reward receipts for co-op. Schema 8
migration preserves prior money, vehicles and story. Mobile landscape camera
actions sit above navigation. See TEST_REPORT.md for checks and remaining limits.

# v7.0.0 - Together & On the Move / 16 October 2026

Added on-foot/light-ride jumping and mobile jump input; car handbrake controls;
km/h and gear display; original hatchback and bakkie with arcade driving/collision;
Ubuntu Motors; named/filterable/searchable map with street signs; visible meal
portions and animated eating hands; private two-player co-op with separate shared
business, room code/password, partner avatars, server transactions and reconnect.

Retained schema migration from v1-v6. Solo storage remains separate from rooms.
No public hosting, full suspension/ragdoll simulation, passenger driving, native
mobile package or physical-phone certification is claimed.

---

# 6.0.0 - Street Life (16 October 2026)

New R2,500 starts; preserved old funds; eight handbook topics; three fictional crop packets and optional care; three-step production wizard; enterable restaurant with four seats and timed meals; handset phone with filtered/exportable 200-event business history; witnessed-warning/pursuit/search patrol AI; collision-safe first-person knockdowns; requested developer code with session-only unlimited-money/invincibility/police toggles; actual boot progress and Play/Settings/Fullscreen/Dev launcher; optional opt-in first-party player-profile counts with separate server-admin token.

Full details and limitations: README.md, TEST_REPORT.md. Old entries below describe earlier versions, not additional v6 test evidence.

# Version 5.0.0 - Open Neighbourhood (16 October 2026)

- Selectable Free Roam with no compulsory chapters; mode changes preserve one
  shared business save. Existing Story remains available.
- Masakhane Market, Bayfront Walk and Jacaranda Heights; 24 added customers
  for 32 total. Connected roads, scenery, services, taxi stops and patrols.
- Nearest-first customer directory, district filters, optional/declinable
  orders, favourite-blend price premium and correctly projected larger map.
- v1-v5 import/migration, remembered mode/outer-map position/customer cooldowns,
  updated tab-conflict guard for schema 5.
- Expanded bounds and distance-based character rendering; corrected two old
  customer positions that were embedded in existing building colliders.
- All v4.1 mobile-fit, story, health and ride systems retained.

## Previous release history

# Changelog

## 4.0.0 - Streets & Wheels - 15 October 2026

- Added a stable version-independent primary save key, local random profile,
  visible continue/save summary, timestamps, revision-aware stale-tab protection,
  input preference memory, save centre, title-screen imports and persistent
  blocked-storage warning. Autosave interval is now three simulation seconds.
- Preserved v1-v3 migrations, cash/story data and rotating backups. Imported
  health/ownership are validated. Resume starts safely on foot.
- Added health HUD, moving-traffic swept intersections, impact cooldown,
  dismount/knockback, first-hit tutorial and zero-health recovery without debt or
  loss of owned rides. First aid, meals and free sleep restore health.
- Added Ubuntu Wheels physical shop, Tumi, 3D displays/previews, skateboard,
  bicycle, electric scooter, helmet and first-aid purchases using game money.
- Added owned-ride garage, first-person models, acceleration/coasting/braking,
  per-ride movement, speed display, indoor dismounting and parked home models.
- Added G/V/B desktop shortcuts and touch RIDE/OFF, contextual boost and joystick
  braking. Added optional paused ride/traffic lessons with pinned Continue.
- Added optional browser-opening launchers and updated portable documentation.
- Retained the 15-chapter story, mixing/economy, old visual upgrades, runner,
  save exports, auto/desktop/touch modes and graphics recovery.

### QA corrections during v4 work

- Small 360-pixel phones initially allowed a few pixels of joystick/health-button
  overlap. Narrow-screen dimensions were corrected and the controls retested.
- Resetting a game now inherits the prior save revision before writing its new
  state, so revision-based stale-tab detection remains monotonic.
- A traffic integration test initially advanced the car just short of its actual
  collision extent. Its simulated crossing was extended into the collider;
  collision code was not weakened to force that test to pass.
- Adjusted pointer-look hint and touch hint placement to avoid covering new HUD
  elements; increased the skateboard's product-preview framing.

## Earlier releases

v3 introduced richer original procedural artwork, environment detail, character
portraits, player-paced illustrated lessons and device-selection overrides.
v2 introduced the guided 15-chapter story and desktop/touch foundations.
v1 introduced the original first-person neighbourhood and business loop.

## 4.1.0 - Mobile Fit (15 October 2026)
- Visible-viewport sizing for renderer and interface; safe area and resize handling.
- Compact phone/tablet HUD with tap-to-read objectives, no duplicate state labels.
- Scrollable title and menus; independent fixed-size dialog navigation.
- Shop cards and readable instructional text reflow in narrow and shallow windows.
- Rotation clears active input without resetting gameplay.
- Same save schema and game mechanics as 4.0.0. Updated optional offline cache.
- Added a viewport matrix and multi-touch layout regression suite.
