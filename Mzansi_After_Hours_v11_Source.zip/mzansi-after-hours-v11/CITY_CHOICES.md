# Mzansi After Hours v11 - City Choices

## Before updating

Export your v10 solo JSON save and close the older game. Import the backup into
v11 to keep money, Current/Savings, businesses, story, inventory and cars. The
stable browser save key is unchanged. Keep the same browser and game address.
Changing browsers/addresses or clearing website data can separate/delete local
saves. Export backups regularly. Co-op rooms use the server's private directory,
which must be backed up separately; a solo export is not a room backup.

## Play

Solo: open `Mzansi_After_Hours_v11.html` in a browser with WebGL. Downloaded-file
launch and local storage vary by browser, especially on phones. For regular phone
play, extract the full project on a computer with Node.js 18+ and run:

```sh
npm run mobile
```

Use the printed Phone address on the same trusted Wi-Fi. Keep the computer awake
and the server running. Use `npm run coop` instead for two-player rooms. This is
not a public hosted link or native APK. No runtime npm packages need installing.
VS Code, Cursor and other editors can edit this ordinary HTML/CSS/JavaScript folder.

## The greeting: Work, Business, or Continue

Starting a solo game now opens a career greeting. **Find work** opens the twenty
paid workplaces and tracks the careers centre. **Open a business** tracks Ubuntu
Community Bank and opens the application guide. **Explore first** is available to
a new player; returning players can **Continue current game** without changing
mode or progress. **Continue the guided story** opens the current story lesson.

Choosing work or business enters Free Roam. Neither choice locks out the other.
Existing businesses are not repossessed and savings are not reset. Reopen the
choice from Phone or Menu. New solo games still start with R2,500; existing money
is not replaced. The separate co-op business still starts with R5,000.

## Applying to open a business

1. Open a free game bank account through Banking. Deposit your contribution into
   **Current**; casino and retail purchases use **pocket cash**, not Current.
2. Track **Ubuntu Community Bank**. Visit the actual branch on foot, then open
   **Business applications**. Select one of the twenty unowned workplaces, your
   whole-rand contribution and a business plan.
3. Submit. The review takes **12 active game seconds** and continues while the
   application panel is open. There is no application fee and no charge yet.
4. Read **APPROVED** or **DECLINED**, with reasons. An approval must then be signed
   at the selected business's own counter. Stock and running costs are separate.

### Transparent game approval rules

- Contribution must be at least **20% of the opening price**, available in Current.
- The premises must not already be owned.
- Another loan cannot be borrowed while an existing business loan is unpaid.
  A fully self-funded application can still be approved.
- The **Steady start** plan requires no previous shifts. **Rapid growth** needs
  two completed paid shifts. A refusal costs nothing; correct the reason and reapply.

The restricted loan covers opening price minus contribution. There is a one-time
**5% game fee on the borrowed amount**, rounded up. Funds go directly toward the
opening agreement, never into spendable cash, so they cannot be withdrawn or
wagered. Your contribution is charged only on signing. Approved finance cannot
be used twice. If your contribution is no longer available, signing is rejected.

Example: Morning Grind costs R900. Deposit R180, apply with R180 and Steady start,
then sign after approval. Current falls by R180. R720 of restricted finance funds
the rest. The game loan balance is R756 (R720 + R36 fee). Stock is not included.

**Repay** through Bank applications using Current. No accumulating interest,
automatic deductions, offline penalties or default/credit-score simulation is
implemented. These are fictional game rules, not real lending terms or advice.

## Sundown Social Casino

Track **Sundown Social Casino** in the named map, or take the taxi to the
**After Hours** stop. It is in the southern part of Enterprise Quarter, beside
**Ubuntu Custom Works** and **Leaf Lounge**. Walk inside and approach the individual
table or bar. Phone shortcuts allow browsing from anywhere, but play/purchases
require visiting the matching interaction point on foot.

All wagers use fictional pocket cash. No real payments, deposits, cash-outs,
real-world prizes or payment accounts exist. It is not a licensed gambling product
or a system suitable for taking real money. Solo code/saves remain editable.

Stakes are **R10-R500 in R10 steps**. There is no autoplay. Total stakes per game
day have a player-set budget of R500, R1,000, R2,000 or R5,000 (default R2,000).
Double/split wagers count toward that budget. The limit resets on a new game day.
Developer unlimited-purchase mode does not waive casino stakes: the finite cash
balance shown in the casino is what counts. An unfinished blackjack hand must be
finished before playing another game.

### European single-zero roulette

37 equally likely outcomes, 0-36, using the displayed European wheel order.

| Supported bet | Profit odds | Total returned when it wins |
| --- | --- | --- |
| One number, including 0 | 35:1 | 36x stake |
| Red/black, odd/even, 1-18/19-36 | 1:1 | 2x stake |
| One dozen or column | 2:1 | 3x stake |

Zero loses every outside bet. No split/street/corner bets, la partage or en prison
are included. For each offered bet, theoretical return is 36/37 (about 97.30%).
This mathematical average is not a promised session result.

### Blackjack

Six decks, shuffled at the start of each round; dealer stands on every 17,
including soft 17, and checks initial blackjack before player decisions.

Hit, stand, double on the initial two cards, or split an equal-rank pair once.
Doubling after a split is allowed. No resplitting; split aces get one extra card
per hand. Natural blackjack pays **3:2 profit**, ordinary wins **1:1**, and pushes
return the stake. Split 21 is not a natural. No insurance or surrender.

Cards, shuffle position and paid stakes persist through solo save restoration.
Closing the panel does not refund or reroll a hand. In co-op only the player who
dealt may act. The server does not send its undealt shoe or hidden dealer card to
clients. Disconnecting permits rejoining the same hand; explicitly leaving a
room **automatically stands** that player's remaining hands and settles them.

### Sundown Reels

Three independently selected 20-stop reels. Each strip contains 6 cherries,
5 lemons, 4 bells, 3 crowns and 2 sevens. The table below is **total return**,
including any returned stake, not profit on top of the original wager.

| Winning result | Total return |
| --- | ---: |
| Three cherries | 4x |
| Three lemons | 8x |
| Three bells | 20x |
| Three crowns | 60x |
| Three sevens | 250x |
| Exactly two cherries, any positions | 0.5x |
| Everything else | 0x |

The highest matching rule is paid once. Exact theoretical return is **94%**,
verified by enumerating all 8,000 stop combinations. Outcomes use unbiased
cryptographic integer draws, not a scripted win cycle. The UI shows the settled
result; the small result reveal is presentational, not a physical wheel solver.

### History and bar

Casino History keeps the latest **60 settled rounds**, stakes, returns and net
results. General game history and saved business data remain separate.

The Social Bar sells water (R10), coffee (R20), fruit cooler (R25), fictional lager
(R35), cider (R35) and Bay Sunset cocktail (R55). Ordering plays a first-person
hand/cup animation. These are cosmetic game drinks: no healing, intoxication,
real purchases or driving bonus is simulated. Restaurant meals still work as before.

## Leaf Lounge

| Fictional game item | Price |
| --- | ---: |
| One Glowleaf joint | R25 |
| Glowleaf flower / 0.5 g pack | R18 |
| Five-joint pre-roll pack | R110 |
| Fictional edible box | R60 |
| Rolling-paper pack | R12 |

Type the quantity before buying. Flower is entered in grams, in 0.5 g steps:
3.5 g buys seven packs for R126. Joint quantity 3 costs R75. Each purchase is
limited to 999 units (flower: 499.5 g); item storage is capped at 9,999 units.
Affordability and quantity are checked before payment. View purchases through
**Retail inventory** in the phone. These new items are collectibles, not the
original crafted customer-sale packs. Consumption and resale of these retail
items are not implemented. No real sellers, orders or payment services are involved.

## Ubuntu Custom Works: modular garage

Buy a car at Ubuntu Motors first. Drive to Custom Works, park outside, get out,
and approach the workshop marker. Choose the owned car to modify. Its preview and
the car on the workshop lift reflect the saved body configuration.

Each kit can be installed in any of the ten original cars. This uses fictional
universal adapters/conversions, not actual mechanical compatibility engineering.
Kits are purchased once **per car**. Removing them keeps them in that car's locker;
refitting a previously purchased kit is free.

| Engine option | One-time kit price |
| --- | ---: |
| Original engine | Already owned |
| 1.6 inline-four | R900 |
| 2.0 turbo-four | R2,200 |
| 3.5 V6 | R3,200 |
| 5.0 V8 | R4,800 |
| 3.0 diesel | R2,600 |
| Electric conversion | R5,500 |

Running-gear upgrades: transmission R700; brakes R650; suspension R800; tyres
R500 (sport/off-road options). Stock parts stay in the locker. You can remove or
refit the engine, transmission, brakes, suspension and tyre set.

Visible removable parts: **bonnet, boot/tailgate, left doors, right doors, front
bumper, rear bumper and each of the four wheels**. Door groups are combined per
side, not separately hinged panels. All six body groups exist on all ten models.
Removing body panels changes the rendered car and its simplified mass. Engine and
running-gear choices change acceleration, speed cap, braking and grip.

A car missing an engine, transmission, brakes, suspension, tyres or any wheel
cannot be driven. Refit the required part at the garage. **Refit complete stock
configuration** is free and retains purchased kits in the locker. Previous
per-car crash damage and R180 roadside repairs remain separate.

### Important physics boundary

This is a modular arcade vehicle system over the existing rigid planar collision
and visual dent model. It is **not BeamNG.drive's full soft-body simulation**.
It adds no rollover, structurally deforming collision hull, crash-detached parts,
individual suspension contact solver, universal real-world engine models or
photorealistic renderer. Removal happens through the workshop, not crash breakage.

## Co-op scope

The running Node room server owns the shared wallet, bank review, restricted loan,
casino outcomes, retail inventory and car configurations. Both players see these
updates. Repeated network commands reuse ordered receipts instead of rerolling
or charging twice. The buyer alone receives a drink animation. Both players may
manage a shared car's parts; park before modifying.

Personal movement, health, police and live crash deformation remain local, as in
v10. A trusted friend can still tamper with local code/movement; this is not a
public anti-cheat service or production gambling backend. Public Internet play
requires hosting the same server with HTTPS and persistent private storage.
No public server, native application or cloud account has been deployed.

## Verification

See `TEST_REPORT.md` for the checks actually executed on this build. The target
is phone-friendly browser play, but no physical Samsung S26 was available here.
Native browser file/HTTP navigation was blocked in the test environment, so
native restart persistence and public Internet hosting remain unverified.

## Developer purchase waiver

The existing solo developer code remains unchanged. Unlimited purchase mode also
waives garage kits, Leaf Lounge items and bar orders. Casino stakes and bank
contributions/repayments always require actual finite balances; use the existing
Add R5,000 developer action for testing those. Developer cheats remain disabled
in co-op and are not restored as authorised by a normal save load.
