/** Private two-player rooms; server-authoritative shared economy with ordered,
 * idempotent commands. Poses remain client-authoritative (trusted-friend play).
 * No third-party services. Put HTTPS in front before using over the Internet. */
import {randomBytes,scrypt as scryptCallback,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import path from 'node:path';
import {initialTeam,cleanTeam,publicTeam,tick,command,leaveCityTable} from './coop-rules.mjs';
const scrypt=promisify(scryptCallback),token=()=>randomBytes(24).toString('hex');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
const equal=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y);};
export async function createCoop({enabled=false,directory,now=()=>Date.now()}={}){
 const rooms=new Map(),limits=new Map();let dirty=false,writing=false,lastFlush=0;const file=path.join(directory||'.private','coop-rooms.json');
 if(enabled){try{const data=JSON.parse(await readFile(file,'utf8'));for(const r of data.rooms||[]){if(!/^[A-Z2-9]{6}$/.test(r.code)||now()-r.updated>30*864e5)continue;r.team=cleanTeam(r.team);r.last=now();for(const m of r.members){m.seen=0;m.pose={x:-32,z:10,yaw:Math.PI,height:0,ride:null,seat:null};}rooms.set(r.code,r);}}catch(e){if(e.code!=='ENOENT')console.warn('Co-op room storage could not be loaded:',e.message);}}
 async function flush(){if(!enabled||writing||!dirty)return;writing=true;dirty=false;try{await mkdir(path.dirname(file),{recursive:true});const temp=file+'.tmp';await writeFile(temp,JSON.stringify({version:1,rooms:[...rooms.values()]}),{mode:0o600});await rename(temp,file);lastFlush=now();}catch(e){dirty=true;console.error('Co-op save error:',e.message);}finally{writing=false;}}
 function advance(r){const time=now(),dt=Math.min(1,Math.max(0,(time-r.last)/1000));r.last=time;if(r.members.some(m=>time-m.seen<12000&&!m.departed)){const before=[r.team.cash,r.team.jobs.length,r.team.orders.length,r.team.life.historySeq].join('|');tick(r.team,dt);if(before!==[r.team.cash,r.team.jobs.length,r.team.orders.length,r.team.life.historySeq].join('|'))r.revision++;dirty=true;}return time;}
 const timer=enabled?setInterval(()=>{for(const r of rooms.values())advance(r);if(now()-lastFlush>5000)flush();},100):null;timer?.unref();
 const snapshot=(r,m)=>({ok:true,code:r.code,you:m.id,host:r.host,name:m.name,seq:m.seq,revision:r.revision,unfinishedMeal:!!m.meal,team:publicTeam(r.team),members:r.members.filter(n=>!n.departed).map(n=>({id:n.id,name:n.name,online:now()-n.seen<12000,pose:n.pose})),updated:r.updated});
 function rate(req,kind,max){const key=(req.socket.remoteAddress||'local')+kind,t=now(),o=limits.get(key)||{start:t,n:0};if(t-o.start>60000){o.start=t;o.n=0;}o.n++;limits.set(key,o);if(limits.size>1000)for(const [k,v]of limits)if(t-v.start>60000)limits.delete(k);return o.n<=max;}
 async function body(req){let bytes=0,chunks=[];for await(const ch of req){bytes+=ch.length;if(bytes>16384)throw new Error('Request too large.');chunks.push(ch);}const d=JSON.parse(Buffer.concat(chunks).toString()||'{}');if(!d||typeof d!=='object'||Array.isArray(d))throw new Error('Invalid request.');return d;}
 function pose(m,p){if(!p||typeof p!=='object')return;const r=['skateboard','bicycle','scooter','hatchback','bakkie','sedan','coupe','suv','van','minibus','rally','classic','electric'].includes(p.ride)?p.ride:null;m.pose={x:clamp(p.x,-270,124),z:clamp(p.z,-130,190),yaw:clamp(p.yaw,-1e6,1e6),height:clamp(p.height,0,2),ride:r,speed:clamp(p.speed,-6,36),seat:/^table[1-4]$/.test(p.seat)?p.seat:null,eating:!!p.eating,walk:!!p.walk,health:clamp(p.health,0,100)};}
 const send=(res,status,d)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(d));};
 async function handle(req,res){const pathname=new URL(req.url,'http://localhost').pathname;if(!pathname.startsWith('/api/coop/'))return false;
  if(pathname==='/api/coop/status'&&req.method==='GET'){send(res,200,{enabled,maxPlayers:2});return true;}
  if(!enabled){send(res,503,{error:'Co-op is disabled. Start this project with npm run coop.'});return true;}
  if(req.method!=='POST'){send(res,405,{error:'Use POST.'});return true;}
  try{
   if(req.headers.origin){const o=new URL(req.headers.origin);if(o.host!==req.headers.host)throw new Error('Cross-origin room requests are not allowed.');}
   if(!String(req.headers['content-type']).startsWith('application/json'))throw new Error('Send JSON.');
   const endpoint=pathname.split('/').at(-1);if(!rate(req,endpoint==='create'||endpoint==='join'?'auth':'play',endpoint==='create'||endpoint==='join'?15:1500)){send(res,429,{error:'Too many requests. Try again shortly.'});return true;}
   const d=await body(req);
   if(endpoint==='create'){
    if(rooms.size>=50)throw new Error('This small server has reached its room limit.');
    const name=String(d.name||'Neighbour').trim().slice(0,24),password=String(d.password||'');if(password.length>64||password.length>0&&password.length<4)throw new Error('Use a room password of 4 to 64 characters, or leave it empty.');
    let code;const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';do{code=[...randomBytes(6)].map(n=>alphabet[n%alphabet.length]).join('');}while(rooms.has(code));
    const salt=token(),hash=password?(await scrypt(password,salt,32)).toString('hex'):'',m={id:token().slice(0,12),name:name||'Neighbour',token:token(),seen:now(),seq:0,receipt:null,departed:false,pose:{x:-32,z:10,yaw:Math.PI,height:0}};
    const r={code,salt,hash,host:m.id,members:[m],team:initialTeam(),revision:0,created:now(),updated:now(),last:now()};rooms.set(code,r);dirty=true;await flush();send(res,200,{...snapshot(r,m),token:m.token});return true;
   }
   const r=rooms.get(String(d.code||'').toUpperCase());if(!r)throw new Error('Room not found. Check the code and server address.');advance(r);
   if(endpoint==='join'){
    const password=String(d.password||'');if(password.length>64)throw new Error('Invalid password.');if(r.hash&&!equal((await scrypt(password,r.salt,32)).toString('hex'),r.hash))throw new Error('The room password does not match.');
    // Recheck capacity after the asynchronous password check.
    if(r.members.filter(m=>!m.departed).length>=2)throw new Error('This room already has two members. A member must leave before someone else joins.');
    const m={id:token().slice(0,12),name:String(d.name||'Neighbour').trim().slice(0,24)||'Neighbour',token:token(),seen:now(),seq:0,receipt:null,departed:false,pose:{x:-29,z:10,yaw:Math.PI,height:0}};r.members.push(m);r.members=r.members.filter(n=>!n.departed);r.updated=now();dirty=true;await flush();send(res,200,{...snapshot(r,m),token:m.token});return true;
   }
   const m=r.members.find(m=>!m.departed&&equal(m.token,d.token||''));if(!m){send(res,401,{error:'This room session is no longer authorised. Join again.'});return true;}
   m.seen=now();pose(m,d.pose);r.updated=now();dirty=true;
   if(endpoint==='pulse'){send(res,200,snapshot(r,m));return true;}
   if(endpoint==='leave'){if(leaveCityTable(r.team,m.id))r.revision++;if(m.meal){r.team.cash+=m.meal.paid;m.meal=null;r.revision++;}m.departed=true;if(r.host===m.id){r.host=r.members.find(n=>!n.departed)?.id||'';}dirty=true;await flush();send(res,200,{ok:true});return true;}
   if(endpoint==='action'){
    const seq=d.seq;if(!Number.isSafeInteger(seq)||seq<1)throw new Error('Invalid transaction sequence.');
    if(seq===m.seq){send(res,200,{...snapshot(r,m),receipt:m.receipt});return true;}
    if(seq!==m.seq+1){send(res,409,{...snapshot(r,m),error:'Transaction order changed. Reconnect before retrying.'});return true;}
    const before=JSON.parse(JSON.stringify(r.team)),mealBefore=m.meal?{...m.meal}:null;let receipt;
    try{if(!d.action||typeof d.action.type!=='string')throw new Error('Invalid action.');receipt={seq,ok:true,...command(r.team,m,d.action)};r.revision++;}
    catch(e){r.team=before;m.meal=mealBefore;receipt={seq,ok:false,text:e.message,personal:{}};}
    m.seq=seq;m.receipt=receipt;dirty=true;await flush();send(res,200,{...snapshot(r,m),receipt});return true;
   }
   throw new Error('Unknown room action.');
  }catch(e){send(res,400,{error:e.message||'The room request could not be completed.'});return true;}
 }
 return {enabled,handle,rooms,flush,async close(){if(timer)clearInterval(timer);dirty=true;await flush();}};
}
