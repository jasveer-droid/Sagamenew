"""Run the current browser regression suites. Requires Python Playwright/Xvfb.
Native launch restrictions are written to their own report, not counted as passes.
"""
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parents[1]
output=root/'test-results';output.mkdir(exist_ok=True)
failed=[]
for name in ['v11_browser','v11_coop_browser','browser_smoke','safety_smoke','native_launch']:
    with (output/(name+'-qa.log')).open('w') as log:
        try:
            result=subprocess.run(['xvfb-run','-a',sys.executable,str(root/'tests'/(name+'.py'))],cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
        except subprocess.TimeoutExpired:
            log.write('\nINCOMPLETE: test exceeded 600 seconds.\n');result=124
    (output/(name+'-qa-exit.txt')).write_text(str(result))
    print(name+': '+str(result),flush=True)
    if result:failed.append(name)
raise SystemExit(1 if failed else 0)
