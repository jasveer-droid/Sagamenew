/** Make a completely offline single HTML file. Node.js only; no packages. */
import {readFile, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let html = await readFile(path.join(root, 'index.html'), 'utf8');
html = html.replace(/<link[^>]+(?:rel="icon"|rel="manifest"|rel="apple-touch-icon")[^>]*>\s*/g, '');
const css = await readFile(path.join(root, 'src/style.css'), 'utf8');
html = html.replace('<link rel="stylesheet" href="src/style.css">', () => '<style>\n' + css + '\n</style>');
html = html.replace('<body>', '<body>\n<script>window.MZ_STANDALONE=true;</script>');
for (const name of ["data", "neighbourhood", "story", "life", "police", "activities", "commerce-data", "commerce", "nightlife", "storage", "device", "mobility", "vehicle-dynamics", "travel", "camera", "people", "engine", "visuals", "car-world", "nightlife-garage", "ride-world", "expansion", "interiors", "outdoor-world", "commerce-world", "nightlife-world", "world", "guide", "touch", "layout", "metrics", "life-panels", "atlas", "coop", "travel-panels", "outdoor-panels", "commerce-panels", "nightlife-panels", "game", "platform"]) {
  const code = await readFile(path.join(root, `src/${name}.js`), 'utf8');
  html = html.replace(`<script src="src/${name}.js"></script>`, () => '<script>\n' + code.replace(/<\/script/gi, '<\\/script') + '\n</script>');
}
const output = path.join(root, 'Mzansi_After_Hours_v11.html');
await writeFile(output, html);
const pkg=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));
await writeFile(path.join(root,'BUILD_INFO.json'),JSON.stringify({game:'Mzansi After Hours',version:pkg.version,edition:'City Choices',standalone_file:path.basename(output),bytes:Buffer.byteLength(html),sha256:createHash('sha256').update(html).digest('hex'),test_report:'TEST_REPORT.md',test_status:'Run the documented tests for this build; this metadata alone is not certification.'},null,2)+'\n');
console.log('Built '+output+' ('+Buffer.byteLength(html)+' bytes)');
