/** The shared business runs on the server, not on the faster player's phone. */
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {readFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({console,Date,Math,crypto:webcrypto});
for(const f of ['data','neighbourhood','story','life','activities','commerce-data','commerce','nightlife','storage','mobility'])vm.runInContext(readFileSync(path.join(root,'src',f+'.js'),'utf8'),ctx);
const {MZSave:Save,MZLife:Life,MZMobility:Mob,MZData:D,MZNeighbourhood:N}=ctx;
export const TEAM_KEYS=['cash','rep','sim','clock','day','inv','products','plants','jobs','jobSeq','upgrades','workshop','runner','runnerActive','reserveOrders','runnerTick','orders','orderSeq','nextOrder','totalRevenue','stats','cooldowns','outdoors','enterprise','cityLife'];
export function initialTeam(){const s=Save.initial();s.mode='free';s.cash=5000;s.inv.seed=6;s.inv.leaf=16;s.inv.pouch=24;s.freeGuideSeen=true;s.orders=[];s.nextOrder=30;return s;}
export function cleanTeam(s){return Save.validate({...s,version:11,game:'mzansi-after-hours',mode:'free'});}
export function publicTeam(s){const o={};for(const k of TEAM_KEYS)o[k]=s[k];o.owned=s.rides.owned;o.helmet=s.rides.helmet;o.history=s.life.history;const out=JSON.parse(JSON.stringify(o));const h=out.cityLife?.casino?.blackjack;if(h){delete h.deck;delete h.cursor;if(h.status==='playing')h.dealer=h.dealer.map((v,i)=>i===0?v:null);}return out;}
export function tick(s,dt){s.sim+=dt;ctx.MZActivities.tick(s);s.clock+=dt*1.6;while(s.clock>=1440){s.clock-=1440;s.day++;}
 ctx.MZCommerce.tick(s);ctx.MZNightlife.tick(s);
 s.jobs=s.jobs.filter(j=>{if(s.sim-j.start<j.duration)return true;const count=j.hits>=2?4:3;s.products[j.recipe]+=count;s.stats.crafted++;Life.log(s,'production',D.RECIPES[j.recipe].name+' batch completed / '+count+' shared packs');return false;});
 for(const p of s.plants){if(p&&!p.notified&&s.sim-p.start>=p.duration){p.notified=true;Life.log(s,'growing','A shared planter is ready to harvest.');}}
 if(s.runner&&s.runnerActive&&s.sim-s.runnerTick>=25){s.runnerTick=s.sim;const k=Object.keys(D.RECIPES).reverse().find(k=>spare(s,k)>0);if(k){const qty=Math.min(2,spare(s,k));sale(s,k,qty,Math.round(qty*D.RECIPES[k].value*.85));s.stats.runnerSales++;}}
 if(s.sim>=s.nextOrder){s.nextOrder=s.sim+50;const free=N.ids.filter(id=>!s.orders.some(o=>o.npc===id));if(free.length&&s.orders.length<8){const npc=free[Math.floor(Math.random()*free.length)],recipe=Object.keys(D.RECIPES)[Math.floor(Math.random()*4)],qty=2+Math.floor(Math.random()*3);s.orders.push({id:++s.orderSeq,npc,recipe,qty,pay:Math.round(qty*D.RECIPES[recipe].value*1.12)});}}
}
function spare(s,k){return Math.max(0,s.products[k]-(s.reserveOrders?s.orders.filter(o=>o.recipe===k).reduce((n,o)=>n+o.qty,0):0));}
function sale(s,k,qty,pay){s.products[k]-=qty;s.cash+=pay;s.totalRevenue+=pay;s.rep+=qty;s.stats.sales++;}
const places={supplier:[-30,-6.8],marketSupply:[-114,-17.8],bench:[-38.5,20.8],workBench:[46,26.5],grow:[-27.4,25.15],hardware:[-5,-7.9],rideShop:[-46.25,-6.65],carShop:[-58.5,30],workshop:[26.5,24.5],runner:[34,32],restaurant:[39,-19],bed:[-32,26.8],braai:[48,-6.9],bayFood:[105,-35]};
const original=[['sipho',-13.5,8],['aisha',.3,-7.5],['lerato',7,21],['pieter',26.25,-23],['ravi',49,9],['zoe',-10,32],['musa',-47,8],['thandi',26,38.4]];
export const people=new Map([...original.map(([id,x,z])=>[id,{id,x,z}]),...N.customers.map(n=>[n.id,n])]);
// A small approach tolerance accepts phone interactions from all sides of a counter.
function near(m,ids,max=7){return ids.some(id=>{const p=places[id]||people.get(id);return p&&Math.hypot(m.pose.x-(p.x??p[0]),m.pose.z-(p.z??p[1]))<=max;});}
function requireIt(ok,message){if(!ok)throw new Error(message);}
export function command(s,m,a){const id=String(a.id||''),type=a.type;let text='',personal={};
 const pay=n=>requireIt(Life.pay(s,n),'The shared wallet does not have enough cash.');
 if(type==='commerce'){const result=ctx.MZCommerce.perform(s,m.pose,a);requireIt(result.ok,result.text);return {text:result.text,personal:{},commerce:result};}
 else if(type==='city'){const result=ctx.MZNightlife.perform(s,m.pose,{...a,actor:m.id});requireIt(result.ok,result.text);return {text:result.text,personal:result.personal||{},city:result};}
 else if(type==='outdoor'){const result=ctx.MZActivities.perform(s,m.pose,a.kind,id);requireIt(result.ok,result.text);text=result.text;if(result.heal)personal.heal=result.heal;}
 else if(type==='basketScore'){requireIt(ctx.MZActivities.near(m.pose,'court'),'Visit the court first.');requireIt(s.sim-(m.lastShot??-100)>=1.7,'Wait for your last ball to land.');m.lastShot=s.sim;s.outdoors.shots++;if(a.hit===true)s.outdoors.hoops++;text='Court score updated.';}
 else if(type==='buy'){const d=D.SUPPLIES[id];requireIt(d&&near(m,['supplier','marketSupply']),'Visit a supply counter first.');pay(d.price);s.inv[id]+=d.qty;s.stats.bought++;text='Bought '+d.name;}
 else if(type==='craft'){const r=D.RECIPES[id];requireIt(r&&near(m,['bench','workBench']),'Visit a mixing bench first.');requireIt(s.jobs.length<(1+Number(s.workshop)+Number(s.upgrades.mixer)),'All shared mixing stations are busy.');requireIt(Object.values(s.products).reduce((a,b)=>a+b,0)+(s.jobs.length+1)*4<=(s.upgrades.bag?80:40),'The shared stock bag is full.');requireIt(Object.entries(r.needs).every(([k,v])=>s.inv[k]>=v),'Not enough shared ingredients.');for(const [k,v]of Object.entries(r.needs))s.inv[k]-=v;s.jobs.push({id:++s.jobSeq,recipe:id,start:s.sim,duration:s.upgrades.solar?6:10,hits:0,taps:0,lastTap:-10});text='Shared batch started: '+r.name;}
 else if(type==='steady'){const j=s.jobs.find(j=>String(j.id)===id);requireIt(j&&near(m,['bench','workBench'])&&j.taps<3&&s.sim-j.lastTap>=.48,'That timing attempt is not available.');j.taps++;j.lastTap=s.sim;const p=(Math.sin((s.sim-j.start)*3.1)+1)/2;if(p>=.35&&p<=.65)j.hits++;text='Timing attempt recorded.';}
 else if(type==='plant'){requireIt(near(m,['grow']),'Return to the shared planters first.');const i=Number(id);requireIt(Number.isInteger(i)&&i>=0&&i<(s.workshop?4:2),'Invalid planter.');if(s.plants[i]){const n=Life.harvest(s,i);requireIt(n>0,'This crop is still growing.');text='Harvested '+n+' leaves into shared supplies.';}else{requireIt(Life.beginPlant(s,i,a.variety||'classic'),'A seed and an empty planter are required.');text='Shared crop planted.';}}
 else if(type==='carePlant'){requireIt(near(m,['grow'])&&Life.carePlant(s,Number(id),a.kind),'That care task is not available.');text='Shared crop tended.';}
 else if(type==='upgrade'){const u=D.UPGRADES[id];requireIt(u&&near(m,['hardware'])&&!s.upgrades[id],'Visit Bay Hardware for an unowned upgrade.');pay(u.price);s.upgrades[id]=true;text=u.name+' installed for both players.';}
 else if(type==='property'){requireIt(!s.workshop&&near(m,['workshop']),'Visit the workshop entrance.');pay(1600);s.workshop=true;text='The shared workshop is open.';}
 else if(type==='runner'){requireIt(s.workshop&&!s.runner&&near(m,['runner']),'Visit the dispatch desk.');pay(650);s.runner=true;s.runnerTick=s.sim;text='Shared runner hired.';}
 else if(type==='toggleRunner'||type==='toggleReserve'){requireIt(near(m,['runner']),'Visit the dispatch desk.');const k=type==='toggleRunner'?'runnerActive':'reserveOrders';s[k]=!s[k];text='Dispatch setting updated.';}
 else if(type==='buyRide'){const r=Mob.RIDES[id];requireIt(r&&!s.rides.owned[id]&&near(m,[r.car?'carShop':'rideShop']),'Visit the correct vehicle shop; you may already own this ride.');pay(r.price);s.rides.owned[id]=true;text=r.name+' unlocked for both players.';personal.equipped=id;}
 else if(type==='repairCar'){requireIt(Object.hasOwn(Mob.RIDES,id)&&Mob.RIDES[id].car&&s.rides.owned[id]&&Math.abs(m.pose.speed||0)<=.3,'Stop your owned car before requesting service.');pay(180);personal.repaired=id;text='Bodywork repaired for R180.';}
 else if(type==='buyHelmet'){requireIt(!s.rides.helmet&&near(m,['rideShop']),'Visit Ubuntu Wheels.');pay(120);s.rides.helmet=true;text='Both riders now have helmets.';}
 else if(type==='buyMedkit'){requireIt(near(m,['rideShop','supplier','marketSupply']),'Visit a supply or ride shop.');pay(45);personal.medkit=1;text='First-aid kit purchased.';}
 else if(type==='sell'||type==='deliver'){
  let npc=people.get(a.npc);requireIt(npc&&near(m,[a.npc],7),'Approach the customer first.');requireIt(!(s.cooldowns[a.npc]>s.sim),'Your partner just traded here. Give the customer a moment.');
  let recipe=a.recipe,qty=Number(a.qty),mult=Number(a.mult),p;
  if(type==='deliver'){const o=s.orders.find(o=>String(o.id)===id&&o.npc===a.npc);requireIt(o,'This order was already completed.');recipe=o.recipe;qty=o.qty;p=o.pay;requireIt(s.products[recipe]>=qty,'Not enough shared stock.');s.orders=s.orders.filter(n=>n!==o);s.stats.delivered++;}
  else {requireIt(D.RECIPES[recipe]&&Number.isInteger(qty)&&qty>0&&qty<=5&&mult>=.85&&mult<=1.3&&s.products[recipe]>=qty,'Check product, quantity and price.');s.cooldowns[a.npc]=s.sim+8;if(Math.random()>Math.max(.22,1-(mult-1)*2.9)){text='The customer declined. Try a lower price later.';return {text,personal};}p=Math.round(D.RECIPES[recipe].value*(npc.favourite===recipe?1.1:1)*qty*mult);}
  sale(s,recipe,qty,p);s.cooldowns[a.npc]=s.sim+12;personal.deal=true;text=m.name+' sold '+qty+' packs / +R'+p+' to the shared wallet.';
 }
 else if(type==='declineOrder'){s.orders=s.orders.filter(o=>String(o.id)!==id);text='Optional order declined.';}
 else if(type==='food'){requireIt(near(m,['braai','bayFood']),'Visit the food counter.');pay(25);personal.heal=25;text='Meal purchased.';}
 else if(type==='orderMeal'){const meal=Life.MEALS[id];requireIt(meal&&m.pose.seat&&!m.meal&&m.pose.x>27&&m.pose.x<51&&m.pose.z>-27&&m.pose.z<-11,'Sit at a restaurant table first.');pay(meal.price);m.meal={id,paid:meal.price,started:s.sim};personal.meal=id;text='Your meal is on its way.';}
 else if(type==='refundMeal'){if(m.meal){s.cash+=m.meal.paid;m.meal=null;}text='Unfinished meal refunded.';}
 else if(type==='finishMeal'){requireIt(m.meal&&s.sim-m.meal.started>=Life.MEALS[m.meal.id].seconds-.2,'The meal is not finished yet.');m.meal=null;text='Meal finished.';}
 else if(type==='ride'){requireIt(N.taxiStops[id],'Choose a taxi destination.');pay(20);personal.taxi=N.taxiStops[id];text='Taxi fare paid.';}
 else if(type==='sleep'){requireIt(near(m,['bed']),'Go to your bed to rest.');personal.heal=100;text='Rested. Shared world time continues normally.';}
 else if(type==='penalty'){const cost=a.arrest?180:75,fee=Math.min(s.cash,cost);pay(fee);if(a.arrest)for(const k in s.products)s.products[k]-=Math.ceil(s.products[k]*.25);s.stats.fines++;text='Patrol penalty paid from the shared wallet.';}
 else if(type==='recovery'){const fee=Math.min(s.cash,60);pay(fee);text='Recovery transport paid.';}
 else throw new Error('This action is not available in the shared business.');
 if(type!=='outdoor')Life.log(s,['sell','deliver'].includes(type)?'trade':'system',text);return {text,personal};
}

export function leaveCityTable(s,actor){return ctx.MZNightlife.abandonBlackjack(s,actor);}
