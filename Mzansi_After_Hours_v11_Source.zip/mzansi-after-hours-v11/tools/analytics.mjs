/** Optional first-party analytics. Explicit opt-in clients only; no IP records. */
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
export async function createAnalytics({enabled=false,directory,adminToken}){
 let db={version:1,visitors:{},sessions:{}};let saveQueue=Promise.resolve();
 const filename=path.join(directory,'analytics.json');
 if(enabled){await mkdir(directory,{recursive:true});try{const x=JSON.parse(await readFile(filename,'utf8'));if(x?.version===1&&x.visitors&&x.sessions)db=x;}catch(_){}
  if(!adminToken){const f=path.join(directory,'admin-token.txt');try{adminToken=(await readFile(f,'utf8')).trim();}catch(_){adminToken=crypto.randomBytes(24).toString('hex');await writeFile(f,adminToken,{mode:0o600});}}
 }
 const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));};
 const save=()=>{const bytes=JSON.stringify(db);saveQueue=saveQueue.catch(()=>{}).then(async()=>{await writeFile(filename+'.tmp',bytes,{mode:0o600});await rename(filename+'.tmp',filename);});return saveQueue;};
 const id=v=>typeof v==='string'&&/^[a-zA-Z0-9_-]{6,100}$/.test(v);
 const limits=new Map();
 async function handle(req,res){
  const pathname=new URL(req.url,'http://localhost').pathname;if(!pathname.startsWith('/api/'))return false;
  if(pathname==='/api/info'&&req.method==='GET'){json(res,200,{enabled,version:1});return true;}
  if(!enabled){json(res,404,{error:'Analytics disabled'});return true;}
  if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`&&req.headers.origin!==`https://${req.headers.host}`){json(res,403,{error:'Cross-origin access rejected'});return true;}
  if(pathname==='/api/admin/stats'&&req.method==='GET'){
   const incoming=Buffer.from((req.headers.authorization||'').replace(/^Bearer /,'')),expected=Buffer.from(adminToken||'');
   if(incoming.length!==expected.length||!crypto.timingSafeEqual(incoming,expected)){json(res,401,{error:'Admin token required'});return true;}
   const now=Date.now(),rows=Object.values(db.sessions).sort((a,b)=>b.started-a.started);
   json(res,200,{scope:'Consenting browser profiles on this server; not verified people',profiles:Object.keys(db.visitors).length,sessions:rows.length,active:rows.filter(s=>!s.ended&&now-s.lastSeen<60000).length,playSeconds:rows.reduce((a,s)=>a+s.seconds,0),history:rows.slice(0,150).map(({id,visitorId,...r})=>({...r,session:id.slice(0,8)})),retention:'30 days; maximum 10000 sessions',generatedAt:now});return true;
  }
  if(pathname==='/api/event'&&req.method==='POST'){
   if(!String(req.headers['content-type']||'').startsWith('application/json')){json(res,415,{error:'JSON required'});return true;}
   let bytes='';try{for await(const chunk of req){bytes+=chunk;if(bytes.length>2048){json(res,413,{error:'Body too large'});return true;}}let x;try{x=JSON.parse(bytes);}catch(_){json(res,400,{error:'Invalid JSON'});return true;}
    if(!id(x.sessionId)||!id(x.visitorId)||!['start','pulse','end'].includes(x.type)||!['touch','desktop'].includes(x.device)||!['story','free'].includes(x.mode)||!Number.isInteger(x.seconds)||x.seconds<0||x.seconds>86400*30){json(res,400,{error:'Invalid event'});return true;}
    const now=Date.now(),bucket=Math.floor(now/60000),limit=limits.get(x.visitorId);if(limit?.bucket===bucket&&limit.count>=12){json(res,429,{error:'Too many updates'});return true;}limits.set(x.visitorId,{bucket,count:limit?.bucket===bucket?limit.count+1:1});if(limits.size>12000)limits.clear();
    // Bound disk usage and retention; never store request IP or User-Agent.
    for(const [key,row]of Object.entries(db.sessions))if(now-row.lastSeen>30*86400000)delete db.sessions[key];
    if(!db.sessions[x.sessionId]&&Object.keys(db.sessions).length>=10000){const oldest=Object.values(db.sessions).sort((a,b)=>a.lastSeen-b.lastSeen)[0];delete db.sessions[oldest.id];}
    const prior=db.sessions[x.sessionId];if(prior&&prior.visitorId!==x.visitorId){json(res,409,{error:'Session does not belong to this profile'});return true;}
    const row=prior||{id:x.sessionId,visitorId:x.visitorId,started:now,seconds:0};Object.assign(row,{lastSeen:now,device:x.device,mode:x.mode,seconds:Math.max(row.seconds,x.seconds),ended:x.type==='end'});db.sessions[x.sessionId]=row;
    db.visitors=Object.fromEntries(Object.values(db.sessions).map(r=>[r.visitorId,true]));await save();json(res,200,{ok:true});return true;
   }catch(_){json(res,503,{error:'Statistics unavailable; gameplay is unaffected'});return true;}
  }
  json(res,404,{error:'Not found'});return true;
 }
 return {handle,adminToken,enabled,flush:()=>saveQueue};
}
