/** Read-only static server. Localhost by default. --lan explicitly enables LAN. */
import http from 'node:http';
import {readFile, stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {createAnalytics} from './analytics.mjs';
import {createCoop} from './coop.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const lan = process.argv.includes('--lan');
const port = Number(process.env.PORT || 8080);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('PORT must be an integer from 1024 to 65535.');
const analytics = await createAnalytics({enabled:process.argv.includes('--analytics') || process.env.MZ_ANALYTICS==='1',directory:process.env.MZ_ANALYTICS_DIR||path.join(root,'.private'),adminToken:process.env.MZ_ADMIN_TOKEN});
const coop = await createCoop({enabled:process.argv.includes('--coop'),directory:process.env.MZ_COOP_DIR||path.join(root,'.private')});
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.svg':'image/svg+xml','.png':'image/png'};
http.createServer(async (req, res) => {
  if(await coop.handle(req,res))return;
  if(await analytics.handle(req,res))return;
  if (!['GET','HEAD'].includes(req.method)) {res.writeHead(405, {'Allow':'GET, HEAD'});res.end();return;}
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if(pathname.split('/').some(p=>p.startsWith('.')&&p!=='.') || /^\/(tools|tests|test-results|test-results-v5)\//.test(pathname)){res.writeHead(403);res.end('Private path');return;}
    const file = path.resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
    if (!file.startsWith(root + path.sep) || !mime[path.extname(file)]) {res.writeHead(403);res.end('Not served');return;}
    const info = await stat(file);if (!info.isFile()) throw new Error('Not a file');
    const data = req.method === 'HEAD' ? null : await readFile(file);
    res.writeHead(200, {'Content-Type':mime[path.extname(file)],'Content-Length':info.size,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(data);
  } catch (_) {res.writeHead(404, {'Content-Type':'text/plain'});res.end('Not found');}
}).listen(port, lan ? '0.0.0.0' : '127.0.0.1', () => {
  const url=`http://127.0.0.1:${port}`;
  console.log(`Desktop: ${url}`);
  if(coop.enabled)console.log("Co-op enabled: two-player rooms. Open Play with a friend in the game. Internet play requires hosting this server behind HTTPS.");
  if(analytics.enabled){console.log('Anonymous player counts: OPT-IN ONLY / this server.');console.log('SERVER ADMIN TOKEN (keep private): '+analytics.adminToken);console.log('This token is different from the local gameplay developer code.');}
  console.log('Use this same address next time to find your saved progress.');
  if(process.argv.includes('--open')){
    const command=process.platform==='win32'?'cmd':process.platform==='darwin'?'open':'xdg-open';
    const args=process.platform==='win32'?['/c','start','',url]:[url];
    const opener=spawn(command,args,{stdio:'ignore',detached:true});
    opener.on('error',()=>console.log('Open the Desktop address above in your browser.'));
    opener.unref();
  }
  if (lan) {
    for (const interfaces of Object.values(os.networkInterfaces())) for (const item of interfaces || [])
      if (item.family === 'IPv4' && !item.internal) console.log(`Phone on the same trusted Wi-Fi: http://${item.address}:${port}`);
    console.log('LAN access is enabled. Stop the server with Ctrl+C after testing.');
  }
}).on('error', e => {console.error('Server error: '+e.message);process.exitCode=1;});
