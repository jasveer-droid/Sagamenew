@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js before starting the game server.
 pause
 exit /b 1
)
node tools/server.mjs --lan --coop
pause
